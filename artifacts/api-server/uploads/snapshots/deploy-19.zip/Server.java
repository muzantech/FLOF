import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;

public class Server {
    public static void main(String[] args) throws Exception {
        String portEnv = System.getenv("SERVER_PORT");
        if (portEnv == null) portEnv = System.getenv("PORT");
        if (portEnv == null) portEnv = "8080";
        int port = Integer.parseInt(portEnv.trim());
        
        HttpServer server = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);
        server.createContext("/", exchange -> {
            String response = "<!DOCTYPE html><html><head><style>" +
                "body{font-family:sans-serif;background:#09090B;color:#FAFAFA;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}" +
                "h1{color:#FACC15}.card{text-align:center;padding:2rem;border:1px solid rgba(250,204,21,.2);border-radius:12px}" +
                "</style></head><body><div class='card'>" +
                "<h1>FlyHost Java OK</h1>" +
                "<p>Runtime: Java " + System.getProperty("java.version") + "</p>" +
                "<p>Port: " + port + "</p>" +
                "</div></body></html>";
            exchange.getResponseHeaders().add("Content-Type", "text/html; charset=utf-8");
            byte[] bytes = response.getBytes("UTF-8");
            exchange.sendResponseHeaders(200, bytes.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(bytes);
            }
        });
        server.start();
        System.out.println("Java HTTP Server started on port " + port);
    }
}