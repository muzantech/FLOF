const http = require("http");
const port = parseInt(process.env.PORT || "3017", 10);

const html = `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>App Test FlyHost</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: system-ui, sans-serif; 
      background: #09090b; color: #fafafa;
      display: flex; align-items: center; justify-content: center;
      min-height: 100vh; flex-direction: column; gap: 1rem;
    }
    h1 { color: #facc15; font-size: 2rem; }
    p { color: #a1a1aa; }
    .badge { 
      background: #18181b; border: 1px solid #27272a;
      padding: .4rem 1rem; border-radius: 999px; font-size: .85rem; color: #71717a;
    }
  </style>
</head>
<body>
  <h1>⚡ FlyHost</h1>
  <p>Mon application tourne correctement !</p>
  <div class="badge">Hébergé sur <strong style="color:#facc15">flihost.site</strong></div>
  <div class="badge">Port ${port} · ${new Date().toISOString()}</div>
</body>
</html>`;

http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
  res.end(html.replace("${port}", port).replace("${new Date().toISOString()}", new Date().toISOString()));
}).listen(port, "0.0.0.0", () => {
  console.log("App running on port", port);
});
