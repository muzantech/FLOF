const http = require('http');
const port = process.env.SERVER_PORT || process.env.PORT || 3000;
const server = http.createServer((req, res) => {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end('Hello from Node.js! Port: ' + port);
});
server.listen(port, '0.0.0.0', () => console.log('Node.js server running on port ' + port));
