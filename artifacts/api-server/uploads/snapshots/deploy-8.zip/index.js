const http = require('http');
const PORT = process.env.PORT || 3000;

const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('Hello from FlyHost! Deployed successfully.\n');
});

server.listen(PORT, () => {
  console.log(`FlyHost test app running on port ${PORT}`);
  console.log(`Started at: ${new Date().toISOString()}`);
});
