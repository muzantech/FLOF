import * as http from 'http';

const port: number = parseInt(process.env.SERVER_PORT || process.env.PORT || '3000');

const server = http.createServer((req: http.IncomingMessage, res: http.ServerResponse) => {
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ runtime: 'TypeScript', port, message: 'Hello from TypeScript!' }));
});

server.listen(port, '0.0.0.0', () => {
  console.log(`TypeScript server running on port ${port}`);
});
