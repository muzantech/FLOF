<?php
$port = getenv('SERVER_PORT') ?: getenv('PORT') ?: 3000;
header('Content-Type: text/html');
echo '<!DOCTYPE html><html><head><title>FlyHost PHP</title></head><body>';
echo '<h1 style="color:green">✅ PHP fonctionne !</h1>';
echo '<p>Version PHP : ' . PHP_VERSION . '</p>';
echo '<p>Port : ' . $port . '</p>';
echo '<p>Runtime détecté automatiquement par FlyHost</p>';
echo '</body></html>';
?>