import http.server
import os

port = int(os.environ.get('SERVER_PORT', os.environ.get('PORT', 3000)))

class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(f'Hello from Python! Port: {port}'.encode())
    def log_message(self, fmt, *args): pass

print(f'Python server on port {port}')
http.server.HTTPServer(('0.0.0.0', port), Handler).serve_forever()
