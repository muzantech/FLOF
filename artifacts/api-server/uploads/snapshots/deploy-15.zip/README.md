# SIGMA MDX Bot v3.0 - Standalone Deploy

Bot WhatsApp complet avec toutes les commandes bug (Squichy Enhanced).

## 🚀 Déploiement Rapide

### Prérequis
- Node.js >= 18.0.0
- NPM

### Installation

```bash
# 1. Extraire le zip
cd deployable-bot

# 2. Installer les dépendances
npm install

# 3. Démarrer le bot
npm start
```

### Ou en une ligne :
```bash
cd deployable-bot && npm install && npm start
```

## 📱 Configuration

### Préfixe par défaut
Le préfixe par défaut est le **point** (`.`)

Pour changer :
```bash
export PREFIXE=!
npm start
```

### Commandes Disponibles

| Commande | Description |
|----------|-------------|
| `.menu` | Menu principal |
| `.bugmenu` | Menu des bugs |
| `.travas 237xxx` | Android bug |
| `.pending 237xxx` | Pending message |
| `.ghost 237xxx` | iOS ghost |
| `.brutal 237xxx` | Combined mode |
| `.memek 237xxx` | Force Close [2026] 💎 |
| `.ping` | Test |
| `.owner` | Contact owner |

## 🔧 Commandes Bug (Squichy Enhanced)

Toutes les fonctions bug sont optimisées avec les versions Squichy :
- **autosync** - Écran 99999x99999
- **InVsSwIphone** - JustFcDelete
- **InVisDelayLoc** - inTers2
- **memekcici** - Force Close WhatsApp Business [2026]

## 🖥️ Déploiement sur Panel

### Via Render/Railway/Koyeb :

1. Upload le dossier `deployable-bot/`
2. Build Command: `npm install`
3. Start Command: `npm start`

### Via VPS (PM2) :

```bash
npm install -g pm2
pm2 start bot.js --name "sigma-mdx"
pm2 save
```

## 📁 Structure

```
deployable-bot/
├── bot.js          # Bot principal (tout en un)
├── start.js        # Script de démarrage
├── package.json    # Dépendances
├── README.md       # Ce fichier
└── session/        # Session WhatsApp (auto-créé)
```

## ⚠️ Note

- Le bot demande un numéro WhatsApp au premier démarrage
- Un code d'appairage est généré
- Scannez le code avec WhatsApp → Appareils liés

## 👨‍💻 Owner

**MUZAN SIGMA**
📞 +32 491 942 744

---
*Powered by SIGMA MDX v3.0*
