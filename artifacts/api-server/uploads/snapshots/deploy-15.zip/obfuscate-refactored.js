import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const sourceDir = path.join(__dirname, 'commands-refactored');
const targetDir = path.join(__dirname, 'commands');
const backupDir = path.join(__dirname, 'commands-backup');

// Vérifier que le dossier source existe
if (!fs.existsSync(sourceDir)) {
  console.error('❌ Dossier commands-refactored/ introuvable !');
  console.log('💡 Exécute d\'abord: node refactor-text.js');
  process.exit(1);
}

// Créer backup des originaux si pas déjà fait
if (!fs.existsSync(backupDir)) {
  fs.mkdirSync(backupDir, { recursive: true });
  const originalFiles = fs.readdirSync(targetDir).filter(f => f.endsWith('.js'));
  for (const file of originalFiles) {
    fs.copyFileSync(path.join(targetDir, file), path.join(backupDir, file));
  }
  console.log(`📁 Backup créé: ${originalFiles.length} fichiers`);
}

const files = fs.readdirSync(sourceDir).filter(f => f.endsWith('.js'));

console.log(`🔐 Offuscation de ${files.length} fichiers refactorisés...\n`);

let obfuscated = 0;

for (const file of files) {
  try {
    const filePath = path.join(sourceDir, file);
    const targetPath = path.join(targetDir, file);
    
    let content = fs.readFileSync(filePath, 'utf8');
    
    // 1. Sauvegarder le nom de la commande
    const nameMatch = content.match(/export\s+const\s+name\s*=\s*["']([^"']+)["']/);
    const realName = nameMatch ? nameMatch[1] : file.replace('.js', '');
    
    // 2. Minifier les espaces (sauf dans les strings)
    content = content.replace(/\n\s*\n+/g, '\n');
    
    // 3. Renommer les variables internes (pas les exports/imports)
    const protectedWords = new Set([
      'import', 'export', 'from', 'async', 'await', 'function', 'const', 'let', 'var',
      'return', 'if', 'else', 'try', 'catch', 'throw', 'new', 'this', 'true', 'false',
      'null', 'undefined', 'default', 'typeof', 'name', 'execute', 'sock', 'msg', 'args', 
      'from', 'console', 'log', 'error', 'JSON', 'Object', 'Array', 'String', 'Number',
      'Date', 'Math', 'Promise', 'axios', 'fs', 'path', 'fetch', 'getContextInfo',
      realName, 'require', 'module', 'exports', 'process', 'Buffer', '__dirname', 
      '__filename', '__s', '__d' // Protéger les fonctions de décodage
    ]);
    
    // Générer noms d'obfuscation
    const varMap = new Map();
    let counter = 0;
    const generateName = () => {
      const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      let result = '';
      let n = counter++;
      do {
        result = chars[n % 26] + result;
        n = Math.floor(n / 26);
      } while (n > 0);
      return '_' + result;
    };
    
    // Trouver les déclarations const/let/var
    const declRegex = /\b(const|let|var)\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\b/g;
    let m;
    
    while ((m = declRegex.exec(content)) !== null) {
      const varName = m[2];
      if (!protectedWords.has(varName) && !varName.startsWith('_')) {
        if (!varMap.has(varName)) {
          varMap.set(varName, generateName());
        }
      }
    }
    
    // Remplacer les variables
    const sortedVars = Array.from(varMap.entries()).sort((a, b) => b[0].length - a[0].length);
    for (const [oldName, newName] of sortedVars) {
      const regex = new RegExp(`\\b${oldName}\\b`, 'g');
      content = content.replace(regex, newName);
    }
    
    // 4. Ajouter header
    const obfuscatedContent = `// SIGMA MDX - Protected\n${content.trim()}`;
    
    fs.writeFileSync(targetPath, obfuscatedContent, 'utf8');
    console.log(`🔒 ${file} - Offuscé (${varMap.size} vars)`);
    obfuscated++;
    
  } catch (err) {
    console.error(`❌ Erreur ${file}:`, err.message);
  }
}

console.log(`\n✅ ${obfuscated}/${files.length} fichiers offuscés !`);
console.log(`🚀 Test: npm start puis .ping .menu .song`);
