import axios from "axios";
import fs from "fs";
import path from "path";
import mime from "mime-types";
import { getContextInfo } from "./utils.js";

export const name = "down-url";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;

  // Verifier que l'utilisateur a bien entre une URL
  const url = args[0];
  if (!url) {
    return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: > *Utilisation:* `!down-url <lien>`\n\nExemple:\n> !down-url https://example.com/video.mp4", contextInfo: context }, { quoted: msg });
  }

  try {
    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY:⚡ Telechargement en cours....", contextInfo: context }, { quoted: msg });

    // Telechargement du contenu avec axios
    const response = await axios.get(url, { responseType: "arraybuffer" });
    const buffer = Buffer.from(response.data, "binary");

    // Determiner le type MIME
    const contentType = response.headers["content-type"] || mime.lookup(url) || "application/octet-stream";
    const extension = mime.extension(contentType) || "bin";

    // Nom temporaire
    const fileName = `download_${Date.now()}.${extension}`;
    const filePath = path.join("./", fileName);

    // Sauvegarde temporaire
    fs.writeFileSync(filePath, buffer);

    // Determiner le type de media a envoyer
    let messageOptions = {};
    if (contentType.startsWith("image/")) {
      messageOptions = { image: fs.readFileSync(filePath), caption: `⚡ *Fichier image telecharge depuis :*\n${url}` };
    } else if (contentType.startsWith("video/")) {
      messageOptions = { video: fs.readFileSync(filePath), caption: `⚡ *Video telechargee depuis :*\n${url}` };
    } else if (contentType.startsWith("audio/")) {
      messageOptions = { audio: fs.readFileSync(filePath), mimetype: contentType, ptt: false };
    } else {
      messageOptions = { document: fs.readFileSync(filePath), mimetype: contentType, fileName };
    }

    // Envoi du media
    await sock.sendMessage(from, messageOptions, { quoted: msg });

    // Supprimer le fichier temporaire apres envoi
    fs.unlinkSync(filePath);

  } catch (err) {
    console.error("❌ Erreur down-url :", err);
    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY:❌ *Erreur lors du telechargement.*\nVerifie que le lien est valide et accessible publiquement.", contextInfo: context }, { quoted: msg });
  }
}
