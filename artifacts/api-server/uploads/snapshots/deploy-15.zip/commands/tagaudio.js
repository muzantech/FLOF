import fs from "fs-extra";
import path from "path";
import { getContextInfo } from "./utils.js";

export const name = "tagaudio";

const getConfigPath = (botContext) => {
  if (botContext?.sessionPath) {
    return path.join(botContext.sessionPath, "tagaudio.json");
  }
  return path.resolve("./tagaudio.json");
};

const loadConfig = async (configPath) => {
  try {
    if (await fs.pathExists(configPath)) {
      return await fs.readJSON(configPath);
    }
  } catch {}
  return { enabled: false, audioUrl: null };
};

const saveConfig = async (configPath, config) => {
  await fs.writeJSON(configPath, config, { spaces: 2 });
};

export async function execute(sock, msg, args, from, botContext) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    const configPath = getConfigPath(botContext);
    const config = await loadConfig(configPath);
    const arg = args[0]?.toLowerCase();

    if (!arg) {
      const status = config.enabled ? "Active" : "Desactive";
      await sock.sendMessage(from, {
        text: `> *SIGMA MDX - TagAudio*\n\nStatut: ${status}\nAudio: ${config.audioUrl || "Non configure"}\n\nUsage:\n- .tagaudio <lien_audio> : Activer avec cet audio\n- .tagaudio off : Desactiver\n- .tagaudio status : Voir l'etat`
      }, { quoted: msg });
      return;
    }

    if (arg === "off") {
      config.enabled = false;
      await saveConfig(configPath, config);
      await sock.sendMessage(from, { text: "> *SIGMA MDX* : TagAudio desactive."
, contextInfo: context }, { quoted: msg });
      return;
    }

    if (arg === "status") {
      const status = config.enabled ? "Active" : "Desactive";
      await sock.sendMessage(from, {
        text: `> *SIGMA MDX - TagAudio*\nStatut: ${status}\nAudio: ${config.audioUrl || "Non configure"}`
      }, { quoted: msg });
      return;
    }

    const audioUrl = args.join(" ").trim();
    if (!audioUrl.startsWith("http")) {
      await sock.sendMessage(from, { text: "> *SIGMA MDX* : Fournis un lien audio valide (commencant par http).\nEx: .tagaudio https://example.com/audio.mp3"
, contextInfo: context }, { quoted: msg });
      return;
    }

    config.enabled = true;
    config.audioUrl = audioUrl;
    await saveConfig(configPath, config);

    await sock.sendMessage(from, {
      text: `> *SIGMA MDX - TagAudio ACTIVE*\n\nAudio configure: ${audioUrl}\n\nUn audio sera envoye a chaque fois que vous etes tague dans un groupe.`
    }, { quoted: msg });

  } catch (err) {
    console.error("Erreur tagaudio:", err);
    await sock.sendMessage(from, { text: "> *SIGMA MDX* : Erreur lors de la configuration du tagaudio."
, contextInfo: context }, { quoted: msg });
  }
}
