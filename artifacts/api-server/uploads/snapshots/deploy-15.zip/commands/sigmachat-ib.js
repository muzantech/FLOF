import { getContextInfo } from "./utils.js";

export default {
  name: "sigmachat-ib",
  description: "Activer/desactiver SigmaChat en DM (IB)",
  cooldown: 3,
  isOwner: true,

  async execute(sock, msg, args) {
    const from = msg.key.remoteJid;
    const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
    const context = getContextInfo(senderJid);

    if (!global.sigmaChatIB) global.sigmaChatIB = { enabled: true };

    if (!args[0]) {
      const status = global.sigmaChatIB.enabled ? "Active" : "Desactive";
      await sock.sendMessage(from, {
        text: `> *SIGMA MDX - SigmaChat DM (IB)*\n\nStatut : ${status}\n\nUtilisation :\n- .sigmachat-ib on : Activer\n- .sigmachat-ib off : Desactiver\n- .sigmachat-ib status : Voir l'etat`
      }, { quoted: msg });
      return;
    }

    const action = args[0].toLowerCase();

    if (action === "on") {
      global.sigmaChatIB.enabled = true;
      await sock.sendMessage(from, { text: "> *SIGMA MDX* : SigmaChat en DM (IB) active !"
, contextInfo: context }, { quoted: msg });
    } else if (action === "off") {
      global.sigmaChatIB.enabled = false;
      await sock.sendMessage(from, { text: "> *SIGMA MDX* : SigmaChat en DM (IB) desactive !"
, contextInfo: context }, { quoted: msg });
    } else if (action === "status") {
      const status = global.sigmaChatIB.enabled ? "Active" : "Desactive";
      await sock.sendMessage(from, {
        text: `> *SIGMA MDX - SigmaChat DM* : ${status}`
      }, { quoted: msg });
    } else {
      await sock.sendMessage(from, { text: "> *SIGMA MDX* : Commande inconnue. Utilise on, off ou status."
, contextInfo: context }, { quoted: msg });
    }
  }
};
