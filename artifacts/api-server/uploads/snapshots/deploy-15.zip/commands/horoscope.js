export const name = "horoscope";
import { getContextInfo } from "./utils.js";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;

  try {
    const sign = args[0]?.toLowerCase() || "taurus";
    
    // API Aztro (gratuit)
    const url = `https://aztro.sameerkumar.website/?sign=${sign}&day=today`;
    
    const response = await fetch(url, {
      method: 'POST'
    });
    
    const data = await response.json();
    
    const signs = {
      "aries": "♈ Belier",
      "taurus": "♉ Taureau",
      "gemini": "♊ Gemeaux",
      "cancer": "♋ Cancer",
      "leo": "♌ Lion",
      "virgo": "♍ Vierge",
      "libra": "♎ Balance",
      "scorpio": "♏ Scorpion",
      "sagittarius": "♐ Sagittaire",
      "capricorn": "♑ Capricorne",
      "aquarius": "♒ Verseau",
      "pisces": "♓ Poissons"
    };
    
    const reply = `> > SIGMA MDX DEPLOY : ${signs[sign] || sign}
> > > > > >
> Date: ${data.current_date}
> Couleur: ${data.color}
> Compatibilite: ${data.compatibility}
> Humeur: ${data.mood}
✅ Chance: ${data.lucky_number}
🕐 Heure: ${data.lucky_time}
> Prediction: ${data.description}`;
    
    await sock.sendMessage(from, { text: reply , contextInfo: context }, { quoted: msg });
    
  } catch (err) {
    console.error("Erreur horoscope :", err);
    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Service horoscope indisponible." , contextInfo: context }, { quoted: msg });
  }
}