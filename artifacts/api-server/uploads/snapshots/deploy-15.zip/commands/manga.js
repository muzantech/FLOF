import { getContextInfo } from "./utils.js";

export const name = "manga";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;

  try {
    if (!args.length) {
      await sock.sendMessage(from, { text: "> > SIGMA MDX DEPLOY : Usage: .manga <nom>\nEx: .manga Naruto" , contextInfo: context }, { quoted: msg });
      return;
    }
    
    const search = args.join(" ");
    
    // API Jikan (MyAnimeList)
    const url = `https://api.jikan.moe/v4/manga?q=${encodeURIComponent(search)}&limit=1`;
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (!data.data || data.data.length === 0) {
      await sock.sendMessage(from, { text: "> ❌ SIGMA MDX DEPLOY : manga non trouve." , contextInfo: context }, { quoted: msg });
      return;
    }
    
    const manga = data.data[0];
    
    const reply = `> > SIGMA MDX DEPLOY : ${manga.title}
> > > > > >
> Type: ${manga.type}
> Sortie: ${manga.published?.from?.substring(0, 4) || "N/A"}
✅ Score: ${manga.score || "N/A"}
> Chapitres: ${manga.chapters || "En cours"}
> Synopsis: ${manga.synopsis?.substring(0, 150) || "N/A"}...
> ${manga.url}`;
    
    await sock.sendMessage(from, { text: reply , contextInfo: context }, { quoted: msg });
    
  } catch (err) {
    console.error("Erreur manga :", err);
    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Service manga indisponible." , contextInfo: context }, { quoted: msg });
  }
}