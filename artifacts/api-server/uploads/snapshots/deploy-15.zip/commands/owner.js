import { getContextInfo } from "./utils.js";

export const name = "owner";

export async function execute(sock, msg, args) {
  try {
    const from = msg.key.remoteJid;
    const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
    const context = getContextInfo(senderJid);

    const text = `
> *SIGMA MDX DEPLOY*

╭─────────────────────╮
│                      │
│    MUZAN SIGMA       │
│    Createur & Dev    │
│                      │
╰─────────────────────╯

╭── CONTACT ──────────╮
│                      │
│  Tel: +32 491 942 744│
│                      │
╰─────────────────────╯

╭── CANAL OFFICIEL ───╮
│                      │
│  https://whatsapp.com│
│  /channel/0029VbBIAP │
│  58KMqoJluW8r06      │
│                      │
╰─────────────────────╯

╭── GROUPE OFFICIEL ──╮
│                      │
│  https://chat.whats  │
│  app.com/HMpjwftNbIm │
│  7BLyd6Gf2wM         │
│                      │
╰─────────────────────╯

╭── COMMUNAUTE ───────╮
│                      │
│  Mises a jour        │
│  Bots exclusifs      │
│  Scripts premium     │
│                      │
╰─────────────────────╯

> _Powered by SIGMA MDX_`.trim();

    await sock.sendMessage(from, {
      image: { url: "https://files.catbox.moe/gif51b.jpg" },
      caption: text,
      contextInfo: context
    }, { quoted: msg });

    await sock.sendMessage(from, {
      audio: { url: "https://files.catbox.moe/59g6u8.mp3" },
      mimetype: "audio/mpeg",
      ptt: true,
      contextInfo: context
    }, { quoted: msg });

  } catch (err) {
    console.error("Erreur commande owner :", err);
    await sock.sendMessage(
      msg.key.remoteJid,
      { text: "> SIGMA MDX : Impossible d'afficher les informations du proprietaire.", contextInfo: context },
      { quoted: msg }
    );
  }
}
