import axios from "axios";
import { getContextInfo } from "./utils.js";

export const name = "lyrics";

const LYRICS_APIS = [
  {
    name: "lyricsapi",
    search: async (q) => {
      const res = await axios.get(`https://lyricsapi.fly.dev/api/lyrics?q=${encodeURIComponent(q)}`, { timeout: 15000 });
      return res.data?.result?.lyrics || null;
    }
  },
  {
    name: "gifted",
    search: async (q) => {
      const res = await axios.get(`https://api.giftedtech.co.ke/api/search/lyrics?apikey=gifted&query=${encodeURIComponent(q)}`, { timeout: 15000 });
      return res.data?.result?.lyrics || null;
    }
  },
  {
    name: "bk9",
    search: async (q) => {
      const res = await axios.get(`https://bk9.fun/search/lyrics?q=${encodeURIComponent(q)}`, { timeout: 15000 });
      return res.data?.BK9?.lyrics || null;
    }
  }
];

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    const from = msg.key.remoteJid;
    const songTitle = args.join(" ").trim();

    if (!songTitle) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Entrez le nom de la chanson.\nEx: .lyrics Shape of You", contextInfo: context }, { quoted: msg });
    }

    await sock.sendMessage(from, {
      text: `> *SIGMA MDX* : Recherche des paroles de "${songTitle}"...`
    }, { quoted: msg });

    let lyrics = null;
    for (const api of LYRICS_APIS) {
      try {
        lyrics = await api.search(songTitle);
        if (lyrics) break;
      } catch { continue; }
    }

    if (!lyrics) {
      return await sock.sendMessage(from, {
        text: `> *SIGMA MDX* : Aucune parole trouvee pour "${songTitle}".`
      }, { quoted: msg });
    }

    const maxChars = 4096;
    const output = lyrics.length > maxChars ? lyrics.slice(0, maxChars - 3) + "..." : lyrics;

    await sock.sendMessage(from, {
      text: `> *SIGMA MDX - Lyrics*\nChanson: ${songTitle}\n\n${output}`
    }, { quoted: msg });

  } catch (error) {
    console.error("Erreur lyrics:", error);
    await sock.sendMessage(msg.key.remoteJid, { text: `> *SIGMA MDX* : Erreur lors de la recherche des paroles.`, contextInfo: context }, { quoted: msg });
  }
}
