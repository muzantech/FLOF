import axios from "axios";
import { getContextInfo } from "./utils.js";

export const name = "imagine";
export const description = "Genere une image a partir d'un prompt via AI";
export const category = "AI";

const IMAGE_APIS = [
  {
    name: "Flux-Siputzx",
    call: async (prompt) => {
      const response = await axios.get(`https://api.siputzx.my.id/api/ai/flux`, {
        params: { prompt },
        responseType: "arraybuffer",
        timeout: 30000
      });
      return Buffer.from(response.data);
    }
  },
  {
    name: "StableDiffusion-Siputzx",
    call: async (prompt) => {
      const response = await axios.get(`https://api.siputzx.my.id/api/ai/stable-diffusion`, {
        params: { prompt },
        responseType: "arraybuffer",
        timeout: 30000
      });
      return Buffer.from(response.data);
    }
  },
  {
    name: "ShizoAPI",
    call: async (prompt) => {
      const response = await axios.get(`https://shizoapi.onrender.com/api/ai/imagine`, {
        params: { apikey: "shizo", query: prompt },
        responseType: "arraybuffer",
        headers: { "User-Agent": "SIGMA-MDX/3.0" },
        timeout: 30000
      });
      return Buffer.from(response.data);
    }
  },
  {
    name: "BK9",
    call: async (prompt) => {
      const response = await axios.get(`https://bk9.fun/ai/magicstudio`, {
        params: { q: prompt },
        responseType: "arraybuffer",
        timeout: 30000
      });
      return Buffer.from(response.data);
    }
  }
];

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;

  try {
    const rawText = args.join(" ").trim() || 
                    msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.conversation?.trim() ||
                    '';

    if (!rawText) {
      await sock.sendMessage(from, { text: `> *SIGMA MDX* : Exemple : .imagine un coucher de soleil sur les montagnes`, contextInfo: context }, { quoted: msg });
      return;
    }

    await sock.sendMessage(from, { text: "> *SIGMA MDX* - Generation de l'image en cours..." , contextInfo: context }, { quoted: msg });

    const prompt = enhancePrompt(rawText);
    let imageBuffer = null;
    let usedApi = "";

    for (const api of IMAGE_APIS) {
      try {
        imageBuffer = await api.call(prompt);
        if (imageBuffer && imageBuffer.length > 1000) {
          usedApi = api.name;
          break;
        }
        imageBuffer = null;
      } catch {
        continue;
      }
    }

    if (!imageBuffer) {
      return await sock.sendMessage(from, { text: `> *SIGMA MDX* : Impossible de generer l'image. Reessayez plus tard.`, contextInfo: context }, { quoted: msg });
    }

    await sock.sendMessage(from, {
      image: imageBuffer,
      caption: `> *SIGMA MDX - Imagine*\n> Prompt : ${rawText}`
    }, { quoted: msg });

  } catch (error) {
    console.error("Erreur Imagine:", error);
    await sock.sendMessage(from, { text: `> *SIGMA MDX* : Erreur lors de la generation de l'image. Reessayez plus tard.`, contextInfo: context }, { quoted: msg });
  }
}

function enhancePrompt(prompt) {
  const qualityEnhancers = [
    "high quality", "detailed", "masterpiece", "best quality",
    "ultra realistic", "4k", "highly detailed",
    "professional photography", "cinematic lighting", "sharp focus"
  ];

  const numEnhancers = Math.floor(Math.random() * 2) + 3;
  const selectedEnhancers = qualityEnhancers
    .sort(() => Math.random() - 0.5)
    .slice(0, numEnhancers);

  return `${prompt}, ${selectedEnhancers.join(", ")}`;
}
