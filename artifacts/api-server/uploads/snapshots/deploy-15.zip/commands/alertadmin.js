import fs from "fs";
import path from "path";
import { getGroupProtections, setGroupProtection } from "../groupManager.js";
import { loadSudo } from "../../index.js";
import { getContextInfo } from "./utils.js";

const GROUP_FILE = path.resolve("./group.json");

export const name = "alertadmin";
export const aliases = ["aa", "adminalert", "promotealert"];

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    const from = msg.key.remoteJid;
    
    if (!from.endsWith("@g.us")) {
      await sock.sendMessage(from, { text: "> *SIGMA MDX* : Cette commande est reservee aux groupes." , contextInfo: context }, { quoted: msg });
      return;
    }

    const sender = msg.key.participant || from;
    const senderNum = sender.split("@")[0].replace(/[^0-9]/g, "");

    const owners = (global.owners || []).map(n => n.replace(/[^0-9]/g, ""));
    const sudoList = loadSudo().map(n => n.replace(/[^0-9]/g, ""));
    const isOwner = owners.includes(senderNum);
    const isSudo = sudoList.includes(senderNum);
    const isAdmin = await isGroupAdmin(sock, from, sender);

    if (!isOwner && !isSudo && !isAdmin) {
      await sock.sendMessage(from, { text: "> *SIGMA MDX* : Acces refuse. Admin, owner ou sudo requis." , contextInfo: context }, { quoted: msg });
      return;
    }

    const arg = args[0]?.toLowerCase();
    
    if (!arg || !["on", "off", "status", "info", "help"].includes(arg)) {
      const groupProtections = getGroupProtections(from);
      const current = groupProtections?.alertAdmin ? "Active" : "Desactive";
      
      await sock.sendMessage(from, { 
        text: `> *SIGMA MDX - AlertAdmin* : ${current}`
      }, { quoted: msg });
      return;
    }

    if (arg === "on") {
      setGroupProtection(from, "alertAdmin", true);
      
      await sock.sendMessage(from, { text: `> *SIGMA MDX - AlertAdmin ACTIVE*

Alertes detaillees activees pour les changements d'administrateurs.`, contextInfo: context }, { quoted: msg });
      
    } else if (arg === "off") {
      setGroupProtection(from, "alertAdmin", false);
      
      await sock.sendMessage(from, { text: `> *SIGMA MDX - AlertAdmin DESACTIVE*

Les alertes de promotion/revocation sont desactivees.`, contextInfo: context }, { quoted: msg });
      
    } else if (arg === "status" || arg === "info") {
      const groupProtections = getGroupProtections(from);
      const current = groupProtections?.alertAdmin ? "Active" : "Desactive";
      
      await sock.sendMessage(from, {
        text: `> *SIGMA MDX - AlertAdmin Configuration*

Etat : ${current}
Alertes : Groupe + Proprietaire + Mentions admin
Types : Promote (admin) et Demote (membre)

Commandes :
- .alertadmin on : Active
- .alertadmin off : Desactive
- .alertadmin status : Cette info

Alias : .aa, .adminalert, .promotealert`
      }, { quoted: msg });
      
    } else if (arg === "help") {
      await sock.sendMessage(from, { text: `> *SIGMA MDX - Aide AlertAdmin*

AlertAdmin est un systeme de notification avance pour les changements d'administrateurs.

Fonctionnalites :
1. Detecte les promotions et revocations
2. Envoie une alerte detaillee dans le groupe
3. Mentionne la personne affectee
4. Avertit le proprietaire du bot en prive

Le bot doit etre administrateur pour envoyer les alertes dans le groupe.`, contextInfo: context }, { quoted: msg });
    }

  } catch (err) {
    console.error("Erreur commande alertadmin:", err);
    await sock.sendMessage(msg.key.remoteJid, { 
      text: `> *SIGMA MDX* : Erreur - ${err.message || "Erreur inconnue"}` 
    }, { quoted: msg });
  }
}

async function isGroupAdmin(sock, groupJid, userJid) {
  try {
    const metadata = await sock.groupMetadata(groupJid);
    return metadata.participants.some(p => p.id === userJid && p.admin);
  } catch {
    return false;
  }
}
