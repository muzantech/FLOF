import { downloadContentFromMessage } from "@whiskeysockets/baileys";
import { getContextInfo } from "./utils.js";

export const name = "setppg";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;

  // V�rifie que la commande est lanc�e dans un groupe

  if (!from.endsWith("@g.us")) {

    return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: ?? Cette commande doit �tre utilis�e dans un groupe."
, contextInfo: context }, { quoted: msg });

  }

  // V�rifie si on a bien r�pondu � une image

  const ctxInfo = msg.message?.extendedTextMessage?.contextInfo;

  if (!ctxInfo || !ctxInfo.quotedMessage?.imageMessage) {

    return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: ?? R�ponds � une image pour changer la photo de profil du groupe."
, contextInfo: context }, { quoted: msg });

  }

  try {

    const quoted = ctxInfo.quotedMessage.imageMessage;

    // T�l�charger l'image

    const stream = await downloadContentFromMessage(quoted, "image");

    let buffer = Buffer.from([]);

    for await (const chunk of stream) {

      buffer = Buffer.concat([buffer, chunk]);

    }

    // Mettre � jour la photo de profil du groupe

    await sock.updateProfilePicture(from, buffer);

    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: ? La photo de profil du groupe a �t� mise � jour avec succ�s !"
, contextInfo: context }, { quoted: msg });

  } catch (err) {

    console.error("? Erreur setppgc :", err);

    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: ? Impossible de changer la photo de profil du groupe."
, contextInfo: context }, { quoted: msg });

  }

}