import dotenv from "dotenv";
import { getContextInfo } from "./utils.js";
dotenv.config();

export const name = "demoteall";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;

  // Verifie si la commande est utilisee dans un groupe
  if (!from.endsWith("@g.us")) {
    return await sock.sendMessage(from, { text: "*Commande reservee aux groupes seulement.*", contextInfo: context }, { quoted: msg });
  }

  try {
    const groupMetadata = await sock.groupMetadata(from);
    const participants = groupMetadata.participants || [];

    // --- Identifiants essentiels ---
    const botJid =
      (sock?.user?.id?.split?.(":")?.[0] || sock?.user?.jid?.split?.(":")?.[0] || "") +
      "@s.whatsapp.net";

    const OWNER_NUMBER = process.env.NUMBER?.replace(/\D/g, ""); // nettoie le numero
    const OWNER_JID = OWNER_NUMBER ? `${OWNER_NUMBER}@s.whatsapp.net` : null;

    const sender = msg.key.participant || msg.participant || from;

    // Verification .env
    if (!OWNER_JID) {
      console.error("Le numero du proprietaire (NUMBER) n'est pas defini dans .env !");
      return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: Le numero du proprietaire n'est pas configure.", contextInfo: context }, { quoted: msg });
    }

    // --- Fonction utilitaire pour detecter les admins ---
    const isAdmin = p => {
      const adminFlag = p?.admin || p?.isAdmin || p?.isSuperAdmin;
      return adminFlag === true || adminFlag === "admin" || adminFlag === "superadmin";
    };

    // --- Liste des admins a retrograder (exclure bot, owner, auteur) ---
    const toDemote = participants
      .filter(p => {
        const jid = p?.id || p?.jid || p?.participant;
        if (!jid) return false;
        return isAdmin(p) && jid !== botJid && jid !== OWNER_JID && jid !== sender;
      })
      .map(p => p.id);

    if (toDemote.length === 0) {
      return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: Aucun admin a retrograder", contextInfo: context }, { quoted: msg });
    }

    // --- Execution du demote ---
    await sock.groupParticipantsUpdate(from, toDemote, "demote");

    // --- Confirmation ---
    await sock.sendMessage(from, {
      text: `> SIGMA MDX DEPLOY: *${toDemote.length} admin(s) retrograde(s).* (Bot, proprietaire et auteur exclus)`,
      mentions: toDemote
    }, { quoted: msg });

  } catch (err) {
    console.error("Erreur demoteall :", err);
    await sock.sendMessage(from, { text: "*Erreur lors de l'execution de demoteall.* Verifie mes permissions ou reessaye.", contextInfo: context }, { quoted: msg });
  }
}
