import axios from "axios";
import { getContextInfo } from "./utils.js";

export const name = "muscu";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;
  try {
    const muscle = args.join(" ") || "biceps";
    const url = `https://wger.de/api/v2/exercise/search/?term=${encodeURIComponent(muscle)}&language=2&format=json`;
    const { data } = await axios.get(url, { timeout: 15000 });
    if (!data.suggestions?.length) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Exercice non trouve.\nEx: .muscu biceps, chest, legs, abs" , contextInfo: context }, { quoted: msg });
    }
    const exercises = data.suggestions.slice(0, 5);
    let reply = `> *SIGMA MDX - Musculation*\n\nRecherche: ${muscle}\n\n`;
    exercises.forEach((ex, i) => {
      reply += `${i+1}. ${ex.data?.name || ex.name || "N/A"}\n`;
    });
    await sock.sendMessage(from, { text: reply , contextInfo: context }, { quoted: msg });
  } catch (err) {
    console.error("Erreur muscu:", err);
    await sock.sendMessage(from, { text: "> *SIGMA MDX* : Service exercices indisponible." , contextInfo: context }, { quoted: msg });
  }
}
