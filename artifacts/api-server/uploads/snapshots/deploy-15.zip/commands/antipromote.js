import fs from "fs";
import path from "path";
import { getGroupProtections, setGroupProtection } from "../groupManager.js";
import { loadSudo } from "../../index.js";
import { getContextInfo } from "./utils.js";

const GROUP_FILE = path.resolve("./group.json");

export const name = "antipromote";

export async function execute(sock, msg, args, from) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  try {
    if (!from.endsWith("@g.us")) {
      await sock.sendMessage(from, { text: "Groupe uniquement." , contextInfo: context }, { quoted: msg });
      return;
    }
  } catch (error) {
    console.error(error);
  }

  const sender = msg.key.participant || from;
  const senderNum = getBareNumber(sender);

  const owners = (global.owners || []).map(n => n.replace(/[^0-9]/g, ""));
  const sudo = loadSudo().map(n => n.replace(/[^0-9]/g, ""));
  const isAdmin = await isGroupAdmin(sock, from, sender);

  if (!owners.includes(senderNum) && !sudo.includes(senderNum) && !isAdmin) 
    return sock.sendMessage(from, { text: "Admin / owner / sudo requis." }, { quoted: msg });

  const arg = args[0]?.toLowerCase();
  const current = getGroupProtections(from).antipromote1;

  if (!arg || !["on", "off"].includes(arg)) {
    return sock.sendMessage(from, { 
      text: `Anti-Promote : ${current ? "ON" : "OFF"}\n\n!antipromote on | off` 
    }, { quoted: msg });
  }

  const newState = arg === "on";
  setGroupProtection(from, "antipromote1", newState);

  sock.sendMessage(from, { 
    text: `Anti-Promote ${newState ? "activé 🔒" : "désactivé 🔓"}` 
  }, { quoted: msg });
}

async function isGroupAdmin(sock, groupJid, userJid) {
  try {
    const meta = await sock.groupMetadata(groupJid);
    return meta.participants.some(p => p.id === userJid && p.admin);
  } catch { return false; }
}

function getBareNumber(jid) {
  return String(jid).split("@")[0].replace(/[^0-9]/g, "");
}