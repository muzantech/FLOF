import { downloadMediaMessage } from '@whiskeysockets/baileys';
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import { getContextInfo } from "./utils.js";

export const name = 'tomp4';

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;
  const quotedContext = msg.message?.extendedTextMessage?.contextInfo;
  
  if (!quotedContext?.quotedMessage?.stickerMessage) {
    return await sock.sendMessage(from, { text: '> *SIGMA MDX* : Reponds a un sticker avec .tomp4'
, contextInfo: context }, { quoted: msg });
  }

  try {
    await sock.sendMessage(from, { text: '> *SIGMA MDX* : Conversion en cours...' , contextInfo: context }, { quoted: msg });

    const quotedMsg = {
      key: { remoteJid: from, id: quotedContext.stanzaId, participant: quotedContext.participant, fromMe: false },
      message: quotedContext.quotedMessage
    };

    const buffer = await downloadMediaMessage(quotedMsg, 'buffer', {}, { reuploadRequest: sock.updateMediaMessage });
    if (!buffer || buffer.length === 0) throw new Error('Echec telechargement sticker.');

    const tempDir = './temp';
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);

    const inputPath = path.join(tempDir, `tomp4_in_${Date.now()}.webp`);
    const outputPath = path.join(tempDir, `tomp4_out_${Date.now()}.mp4`);
    fs.writeFileSync(inputPath, buffer);

    const ffmpegCmd = `ffmpeg -y -i "${inputPath}" -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=black" -c:v libx264 -pix_fmt yuv420p -t 10 "${outputPath}"`;

    await new Promise((resolve, reject) => {
      exec(ffmpegCmd, (err) => (err ? reject(err) : resolve()));
    });

    if (!fs.existsSync(outputPath)) throw new Error('Echec conversion MP4.');

    const videoBuffer = fs.readFileSync(outputPath);
    await sock.sendMessage(from, { video: videoBuffer, caption: '> *SIGMA MDX* : Sticker converti en MP4' }, { quoted: msg });

    fs.unlinkSync(inputPath);
    fs.unlinkSync(outputPath);
  } catch (err) {
    console.error('Erreur tomp4:', err);
    await sock.sendMessage(from, { text: `> *SIGMA MDX* : Erreur conversion: ${err.message}` }, { quoted: msg });
  }
}
