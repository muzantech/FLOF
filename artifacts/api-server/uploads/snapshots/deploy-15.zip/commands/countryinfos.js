import { getContextInfo } from "./utils.js";

export const name = "country";
export const description = "Affiche les informations detaillees d'un pays.";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;

  try {
    const countryName = args.join(" ").trim();

    // === Verifie si un pays est specifie ===
    if (!countryName) {
      return await sock.sendMessage(
        from,
        {
          text: "> SIGMA MDX MD Fournis le nom d'un pays.\nExemple : *.countryinfos Pakistan*",
        },
        { quoted: msg }
      );
    }

    // === Message de progression ===
    await sock.sendMessage(
      from,
      {
        text: `> SIGMA MDX DEPLOY: Recuperation des informations pour *${countryName}*...`,
      },
      { quoted: msg }
    );

    // === Requete vers l'API ===
    const apiUrl = `https://api.siputzx.my.id/api/tools/countryInfo?name=${encodeURIComponent(
      countryName
    )}`;
    const res = await fetch(apiUrl);
    const data = await res.json();

    // === Verifie la validite de la reponse ===
    if (!data || !data.status || !data.data) {
      return await sock.sendMessage(
        from,
        {
          text: `> SIGMA MDX DEPLOY: Aucune information trouvee pour *${countryName}*.\nVerifie le nom et reessaie.`,
        },
        { quoted: msg }
      );
    }

    const info = data.data;

    // === Formatage des donnees ===
    const neighborsText =
      info.neighbors?.length > 0
        ? info.neighbors.map((n) => `${n.name}`).join(", ")
        : "Aucun pays voisin trouve.";

    const caption = `> SIGMA MDX DEPLOY *Informations sur ${info.name.common || countryName}*\n
*Capitale :* ${info.capital || "Inconnue"}
*Continent :* ${info.continent.name || "Inconnu"} ${info.continent.emoji || ""}
*Indicatif :* ${info.phoneCode || "N/A"}
*Superficie :* ${info.area.squareKilometers} km2 (${info.area.squareMiles} mi2)
*Cote de conduite :* ${info.drivingSide || "N/A"}
*Monnaie :* ${info.currency || "N/A"}
*Langues :* ${info.languages?.native?.join(", ") || "N/A"}
*Connu pour :* ${info.famousFor || "N/A"}
*Codes ISO :* ${info.isoCode.alpha2.toUpperCase()}, ${info.isoCode.alpha3.toUpperCase()}
*Domaine internet :* ${info.internetTLD || "N/A"}

*Pays voisins :* ${neighborsText}

> Dev by SIGMA MDX`;

    // === Envoi de la reponse avec drapeau ===
    await sock.sendMessage(
      from,
      {
        image: { url: info.flag },
        caption,
      },
      { quoted: msg }
    );

    console.log(`[SIGMA MDX MD] Informations pays envoyees pour : ${countryName}`);

  } catch (err) {
    console.error("[SIGMA MDX MD] Erreur countryinfos :", err);
    await sock.sendMessage(
      from,
      {
        text: `> SIGMA MDX DEPLOY Une erreur est survenue lors de la recuperation des informations.\nDetails : ${err.message}`,
      },
      { quoted: msg }
    );
  }
}