export const name = "kick";

import { getContextInfo } from "./utils.js";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  try {

    const from = msg.key.remoteJid;

    if (!from.endsWith("@g.us")) {

      return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY:Commande de groupe ."

, contextInfo: context }, { quoted: msg });

    }

    const groupMetadata = await sock.groupMetadata(from);

    // Recuperer les JID des membres a expulser

    let targets = [];

    // 1️⃣ Si mention

    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;

    if (mentioned && mentioned.length > 0) targets.push(...mentioned);

    // 2 Si reponse a un message

    const replied = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

    if (replied) {

      const sender = msg.message.extendedTextMessage.contextInfo.participant;

      if (sender) targets.push(sender);

    }

    if (targets.length === 0) {

      return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: Mentionnez ou repondez au message du membre a supprimer !"

, contextInfo: context }, { quoted: msg });

    }

    // Filtrer les doublons

    targets = [...new Set(targets)];

    // Expulser chaque membre

    await sock.groupParticipantsUpdate(from, targets, "remove");

    // Actualiser les infos du groupe apres expulsion

    const updatedGroup = await sock.groupMetadata(from);

    const remainingCount = updatedGroup.participants.length;

    // Message de confirmation stylise

    const mentionsText = targets.map(jid => `👤 @${jid.split("@")[0]} ✅`).join("\n");

    const confirmationText = `> SIGMA MDX DEPLOY:
> 🚫 Membres expulses :${mentionsText}
> 👥 Membres restants : ${remainingCount}`;

    await sock.sendMessage(from, { 

      text: confirmationText,

      mentions: targets

    });

  } catch (err) {

    console.error("_⚡SIGMA MDX MDX⚡:_ Erreur kick :", err);

    await sock.sendMessage(msg.key.remoteJid, { text: "> SIGMA MDX DEPLOY: Suppression Impossible."

, contextInfo: context }, { quoted: msg });

  }

}