export const name = "time";
import { getContextInfo } from "./utils.js";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;

  try {
    const city = args.join(" ") || "";

    if (!city) {
      const now = new Date();
      const reply = `> *SIGMA MDX - Heure*\n\nHeure UTC: ${now.toUTCString()}\nHeure locale serveur: ${now.toLocaleString("fr-FR")}\n\nUsage: .time <ville>\nEx: .time Paris`;
      return await sock.sendMessage(from, { text: reply , contextInfo: context }, { quoted: msg });
    }

    const url = `https://worldtimeapi.org/api/timezone`;
    const res = await fetch(url);
    const zones = await res.json();

    const match = zones.find(z => z.toLowerCase().includes(city.toLowerCase()));

    if (!match) {
      return await sock.sendMessage(from, {
        text: `> *SIGMA MDX* : Ville "${city}" non trouvee.\nEssayez avec le nom anglais (Paris, London, Tokyo...)`
      }, { quoted: msg });
    }

    const timeRes = await fetch(`https://worldtimeapi.org/api/timezone/${match}`);
    const data = await timeRes.json();

    const dt = new Date(data.datetime);
    const reply = `> *SIGMA MDX - Heure*\n\nZone: ${match}\nHeure: ${dt.toLocaleString("fr-FR")}\nJour: ${data.day_of_week}\nUTC offset: ${data.utc_offset}`;

    await sock.sendMessage(from, { text: reply , contextInfo: context }, { quoted: msg });

  } catch (err) {
    console.error("Erreur time:", err);
    await sock.sendMessage(from, { text: "> *SIGMA MDX* : Service heure indisponible." , contextInfo: context }, { quoted: msg });
  }
}
