import fs from "fs";
import path from "path";
import { getGroupProtections, setGroupProtection } from "../groupManager.js";
import { loadSudo } from "../../index.js";
import { getContextInfo } from "./utils.js";

const GROUP_FILE = path.resolve("./group.json");

export const name = "autoreact";

export async function execute(sock, msg, args, from) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    // V�rifie que c'est un groupe
    if (!from.endsWith("@g.us")) {
      await sock.sendMessage(from, { text: "Cette commande est r�serv�e aux groupes." , contextInfo: context }, { quoted: msg });
      return;
    }

    const sender = msg.key.participant || from;
    const senderNum = sender.split("@")[0].replace(/[^0-9]/g, "");

    const owners = (global.owners || []).map(n => n.replace(/[^0-9]/g, ""));
    const sudoList = loadSudo().map(n => n.replace(/[^0-9]/g, ""));
    const isOwner = owners.includes(senderNum);
    const isSudo = sudoList.includes(senderNum);
    const isAdmin = await isGroupAdmin(sock, from, sender);

    // V�rification des permissions
    if (!isOwner && !isSudo && !isAdmin) {
      await sock.sendMessage(from, { text: "Acc�s refus�. Admin, owner ou sudo requis." , contextInfo: context }, { quoted: msg });
      return;
    }

    const arg = args[0]?.toLowerCase();

    // Afficher l'�tat actuel si pas d'argument ou argument invalide
    if (!arg || !["on", "off"].includes(arg)) {
      const current = getGroupProtections(from).autoReact ? "activ�" : "d�sactiv�";
      await sock.sendMessage(from, { 
        text: `> SIGMA MDX DEPLOY: Auto-React\n\n�tat : ${current}\n\nUtilisation : \`!autoreact on\` ou \`!autoreact off\``
      }, { quoted: msg });
      return;
    }

    const newState = arg === "on";
    setGroupProtection(from, "autoReact", newState);

    await sock.sendMessage(from, { 
      text: `> SIGMA MDX DEPLOY: Auto-React ${newState ? "activ�" : "d�sactiv�"} dans ce groupe.`
    }, { quoted: msg });

  } catch (err) {
    console.error("Erreur autoreact:", err);
    await sock.sendMessage(from, { text: "Une erreur est survenue." , contextInfo: context }, { quoted: msg });
  }
}

// Fonction pour v�rifier si l'utilisateur est admin du groupe
async function isGroupAdmin(sock, groupJid, userJid) {
  try {
    const metadata = await sock.groupMetadata(groupJid);
    return metadata.participants.some(p => p.id === userJid && p.admin);
  } catch {
    return false;
  }
}