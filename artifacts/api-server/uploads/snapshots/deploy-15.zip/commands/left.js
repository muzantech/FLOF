import { getContextInfo } from "./utils.js";

export const name = "left";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    await sock.sendMessage(msg.key.remoteJid, { text: "> SIGMA MDX DEPLOY: Good bye" });
    await sock.groupLeave(msg.key.remoteJid);
  } catch (err) {
    console.error("Erreur leave :", err);
  }
}