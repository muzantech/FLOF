export const name = "translate";
import { getContextInfo } from "./utils.js";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;

  try {
    if (args.length < 2) {
      await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Usage: !translate <langue_cible> <texte>\nEx: !translate es Hello world" 
, contextInfo: context }, { quoted: msg });
      return;
    }
    
    const targetLang = args[0];
    const text = args.slice(1).join(" ");
    
    // API MyMemory (gratuit, sans cle)
    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=en|${targetLang}`;
    
    const response = await fetch(url);
    const data = await response.json();
    
    const reply = `> SIGMA MDX DEPLOY : Traduction
🎨🎨🎨🎨🎨🎨
> Original (EN): ${text}
> Traduit (${targetLang.toUpperCase()}): ${data.responseData.translatedText}
> Match: ${data.responseData.match}%`;
    
    await sock.sendMessage(from, { text: reply , contextInfo: context }, { quoted: msg });
    
  } catch (err) {
    console.error("Erreur translate :", err);
    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Service traduction indisponible." , contextInfo: context }, { quoted: msg });
  }
}