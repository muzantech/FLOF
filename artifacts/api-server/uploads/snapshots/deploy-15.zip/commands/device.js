import { getDevice } from "@whiskeysockets/baileys";
import { getContextInfo } from "./utils.js";

export const name = "device";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;

  // V�rifier si la commande est utilis�e en r�ponse � un message

  const quoted = msg.message?.extendedTextMessage?.contextInfo;

  if (!quoted?.stanzaId) {

    await sock.sendMessage(

      from,

      { text: "> SIGMA MDX DEPLOY : R�ponds � un message pour d�tecter l�appareil utilis�." },

      { quoted: msg }

    );

    return;

  }

  try {

    // R�cup�rer l�appareil de l�auteur du message cit�

    const device = getDevice(quoted.stanzaId);

    await sock.sendMessage(

      from,

      { text: `> SIGMA MDX DEPLOY : L�utilisateur vis� utilise ${device ?? "un appareil inconnu"}.` },

      { quoted: msg }

    );

  } catch (err) {

    console.error("Erreur device :", err);

    await sock.sendMessage(

      from,

      { text: "> SIGMA MDX DEPLOY : Impossible de d�tecter l�appareil. V�rifie que tu as bien r�pondu � un message." },

      { quoted: msg }

    );

  }

}