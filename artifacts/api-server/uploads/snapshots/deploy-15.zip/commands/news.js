import axios from "axios";
import { getContextInfo } from "./utils.js";

export const name = "news";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    const from = msg.key.remoteJid;
    const apiKey = "dcd720a6f1914e2d9dba9790c188c08c"; // ta cl� NewsAPI

    // Recuperation des actualites principales
    const { data } = await axios.get(
      `https://newsapi.org/v2/top-headlines?country=fr&apiKey=${apiKey}`
    );

    const articles = data.articles?.slice(0, 5) || [];
    if (articles.length === 0) throw new Error("Aucune actualite disponible.");

    // Message formate avec cadre
    let message = `> SIGMA MDX DEPLOY: 
    +---- 📰 ACTUALITES DU JOUR ----+\n`;
    articles.forEach((a, i) => {
      message += `> ❌ *${i + 1}. ${a.title || "Sans titre"}*\n`;
      if (a.description) message += `>    ${a.description}\n`;
      if (a.url) message += `>    > ${a.url}\n`;
      message += `>\n`;
    });
    message += `> +----------------------------+`;

    // Envoi du message
    await sock.sendMessage(from, { text: message , contextInfo: context }, { quoted: msg });

  } catch (err) {
    console.error("❌ Erreur News:", err);
    await sock.sendMessage(
      msg.key.remoteJid,
      {
        text: "> > SIGMA MDX DEPLOY: Impossible de recuperer les actualites pour le moment.",
      },
      { quoted: msg }
    );
  }
}