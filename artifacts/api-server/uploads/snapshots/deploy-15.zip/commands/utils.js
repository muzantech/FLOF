export const getContextInfo = (sender) => ({
    mentionedJid: [sender],
    forwardingScore: 999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363422898149393@newsletter',
        newsletterName: 'SIGMA MD',
        serverMessageId: 999
    }
});
