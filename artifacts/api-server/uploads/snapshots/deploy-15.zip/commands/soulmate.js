import { getContextInfo } from "./utils.js";

export const name = "soulmate";
export const description = "Find your soulmate in the group";
export const category = "Fun";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;
  const sender = msg.key.participant || msg.key.remoteJid;
  
  // Verifier si c'est un groupe
  if (!from.endsWith('@g.us')) {
    return await sock.sendMessage(from, { text: "*SIGMA MDX DEPLOY*: This command only works in groups", contextInfo: context }, { quoted: msg });
  }

  try {
    // Obtenir les membres du groupe
    const groupMetadata = await sock.groupMetadata(from);
    const participants = groupMetadata.participants.map(p => p.id);
    
    if (participants.length < 2) {
      return await sock.sendMessage(from, { text: "*SIGMA MDX DEPLOY*: Need at least 2 members in the group", contextInfo: context }, { quoted: msg });
    }

    // Filtrer pour ne pas se choisir soi-meme
    const otherParticipants = participants.filter(id => id !== sender);
    
    if (otherParticipants.length === 0) {
      return await sock.sendMessage(from, { text: "*SIGMA MDX DEPLOY*: You're alone in this group", contextInfo: context }, { quoted: msg });
    }

    // Choisir un "soulmate" aleatoire
    const soulmate = otherParticipants[Math.floor(Math.random() * otherParticipants.length)];
    
    // Creer le message avec mentions
    const message = `* *SIGMA MDX DEPLOY - Soulmate Match* \n\n` +
                    `@${sender.split('@')[0]} @${soulmate.split('@')[0]}\n\n` +
                    `A match made in heaven!`;
    
    // Mentions pour les deux utilisateurs
    const mentions = [sender, soulmate];
    
    await sock.sendMessage(from, { text: message,
      mentions: mentions, contextInfo: context }, { quoted: msg });

  } catch (err) {
    console.error("Mysoulmate Error:", err);
    await sock.sendMessage(from, { text: "*SIGMA MDX DEPLOY*: Error finding soulmate\n" +
            "Please try again later", contextInfo: context }, { quoted: msg });
  }
}