// audiorespons.js - Commande pour contrôler le système de mention audio
import { getContextInfo } from "./utils.js";

export const name = "arespons";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;
  const action = args[0]?.toLowerCase().trim();

  try {
    // Si pas d'action, afficher le statut
    if (!action) {
      const status = global.responsSystem?.status ? global.responsSystem.status() : { active: false };
      return await sock.sendMessage(from, {
        text: `> 📊 AUDIORESPONS STATUT\n` +
              `• Système: ${status.active ? '🟢 ACTIF' : '🔴 INACTIF'}\n` +
              `• Owner Lid: ${status.ownerLid || 'Non configuré'}\n` +
              `• Fichier audio: ${status.audioFile || 'Non trouvé'}\n\n` +
              `Usage: .audiorespons on/off`
      }, { quoted: msg });
    }

    // Vérifier si l'action est valide
    if (action !== "on" && action !== "off") {
      return await sock.sendMessage(from, {
        text: `> ⚠️ AUDIORESPONS : Commande incorrecte.\nUsage: .audiorespons on/off\n\n` +
              `Statut actuel: ${global.responsSystem?.status?.().active ? '🟢 ACTIF' : '🔴 INACTIF'}`
      }, { quoted: msg });
    }

    // Vérifier si le système est initialisé
    if (!global.responsSystem || typeof global.responsSystem.toggle !== 'function') {
      return await sock.sendMessage(from, { text: "> ⚠️ AUDIORESPONS : Système de protection non initialisé.\n" +
              "Le bot doit être redémarré ou le module protections2.js n'est pas chargé.", contextInfo: context }, { quoted: msg });
    }

    // Forcer l'état souhaité (on/off)
    const currentStatus = global.responsSystem.status().active;
    const desiredStatus = (action === 'on');
    
    // Si l'état actuel n'est pas celui souhaité, on bascule
    if (currentStatus !== desiredStatus) {
      const newStatus = global.responsSystem.toggle();
      
      await sock.sendMessage(from, {
        text: `> ✅ AUDIORESPONS : Système ${desiredStatus ? 'activé' : 'désactivé'}.\n` +
              `Statut: ${newStatus ? '🟢 ACTIF' : '🔴 INACTIF'}`
      }, { quoted: msg });
    } else {
      // Déjà dans l'état souhaité
      await sock.sendMessage(from, {
        text: `> ℹ️ AUDIORESPONS : Le système est déjà ${desiredStatus ? 'activé' : 'désactivé'}.\n` +
              `Statut: ${currentStatus ? '🟢 ACTIF' : '🔴 INACTIF'}`
      }, { quoted: msg });
    }

  } catch (err) {
    console.error("❌ Erreur commande audiorespons:", err);
    await sock.sendMessage(from, {
      text: `> ⚠️ AUDIORESPONS : Erreur lors de l'exécution de la commande.\nDétails: ${err.message}`
    }, { quoted: msg });
  }
}