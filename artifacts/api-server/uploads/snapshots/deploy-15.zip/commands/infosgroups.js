// commands/infosgroups.js

import { getContextInfo } from "./utils.js";

export const name = "glist";
export const description = "Affiche les informations d'un groupe WhatsApp.";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;

  if (!from.endsWith("@g.us")) {
    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY Cette commande ne fonctionne que dans un groupe !" });
    return;
  }

  try {
    const metadata = await sock.groupMetadata(from);
    const groupName = metadata.subject;
    const participants = metadata.participants;
    const creationDate = metadata.creation;
    const owner = metadata.owner || null;

    // Administrateurs
    const admins = participants.filter(p => p.admin);
    const adminMentions = admins.map(a => `@${a.id.split("@")[0]} (Admin)`);

    // Nombre de membres
    const totalMembers = participants.length;

    // Membre le plus actif
    let mostActive = "Aucune donnee";
    let activeUser = null;
    const recentMsgs = sock.msgs?.[from] || [];
    if (recentMsgs.length > 0) {
      const activityCount = {};
      for (const m of recentMsgs) {
        const sender = m.key.participant || m.key.remoteJid;
        if (!activityCount[sender]) activityCount[sender] = 0;
        activityCount[sender]++;
      }
      const mostActiveId = Object.keys(activityCount).reduce((a, b) =>
        activityCount[a] > activityCount[b] ? a : b
      );
      mostActive = `@${mostActiveId.split("@")[0]} (${activityCount[mostActiveId]} msgs)`;
      activeUser = mostActiveId;
    }

    // Createur
    let creatorText;
    if (owner) {
      const creatorInGroup = participants.find(p => p.id === owner);
      creatorText = creatorInGroup ? `@${owner.split("@")[0]}` : "> SIGMA MDX DEPLOY Createur absent";
    } else {
      creatorText = "Non disponible";
    }

    // === Construction du message au style SIGMA MDX MD avec '>' devant chaque ligne ===
    let infoText = 
`> SIGMA MDX DEPLOY: Infos du groupe

> Nom du groupe       : ${groupName}
> Createur            : ${creatorText}

> Administrateurs     : ${adminMentions.join(", ")}

> Membres presents    : ${totalMembers}
> Date de creation    : ${new Date(creationDate * 1000).toLocaleString()}

> Dev by SIGMA MDX`;

    // Mentions des admins + membre actif + createur
    const mentions = [
      ...admins.map(a => a.id),
      ...(activeUser ? [activeUser] : []),
      ...(owner ? [owner] : [])
    ];

    await sock.sendMessage(from, { text: infoText, mentions });

  } catch (e) {
    console.error("Erreur infosgroups:", e);
    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: Impossible de recuperer les informations du groupe." });
  }
}