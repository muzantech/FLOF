import axios from "axios";
import { getContextInfo } from "./utils.js";

export const name = "song";
export const description = "Generate AI song from text prompt";
export const category = "AI";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;
  
  const prompt = args.join(" ").trim();
  if (!prompt) {
    return await sock.sendMessage(from, { 
      text: "> *SIGMA MDX* : Donne une description pour la chanson.\nEx: .song A love song about the stars", 
      contextInfo: context 
    }, { quoted: msg });
  }

  try {
    await sock.sendMessage(from, { 
      text: "> *SIGMA MDX* : Génération de la chanson en cours... 🎵", 
      contextInfo: context 
    }, { quoted: msg });

    const apiUrl = `https://api.giftedtech.co.ke/api/tools/songgenerator?apikey=gifted&prompt=${encodeURIComponent(prompt)}`;
    const response = await axios.get(apiUrl, { timeout: 180000 });
    
    if (response.data?.result?.audio) {
      const audioUrl = response.data.result.audio;
      await sock.sendMessage(from, { 
        audio: { url: audioUrl }, 
        mimetype: "audio/mpeg",
        contextInfo: context 
      }, { quoted: msg });
    } else {
      await sock.sendMessage(from, { 
        text: "> *SIGMA MDX* : Impossible de générer la chanson. Réessaie plus tard.", 
        contextInfo: context 
      }, { quoted: msg });
    }
  } catch (err) {
    console.error("Erreur song:", err);
    let errorMsg = "> *SIGMA MDX* : ";
    if (err.response?.status === 504) {
      errorMsg += "L'API de génération est temporairement surchargée. Réessaie plus tard.";
    } else if (err.code === 'ECONNABORTED') {
      errorMsg += "La génération prend trop de temps (3 min max). Réessaie avec un prompt plus simple.";
    } else {
      errorMsg += "Erreur lors de la génération: " + err.message;
    }
    await sock.sendMessage(from, { 
      text: errorMsg, 
      contextInfo: context 
    }, { quoted: msg });
  }
}
