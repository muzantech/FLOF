// =================== COMMANDE AUTO-SIGMA-CHAT ===================
// Fichier : commandes/autosigmachat.js

import fs from "fs";
import path from "path";
import { getGroupProtections, setGroupProtection } from "../groupManager.js";
import { loadSudo } from "../../index.js";
import { getContextInfo } from "./utils.js";

const GROUP_FILE = path.resolve("./group.json");

export const name = "sigmachat";
export const aliases = ["akc", "autosigma", "autoai"];

export async function execute(sock, msg, args, from) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  try {
    if (!from.endsWith("@g.us")) {
      await sock.sendMessage(from, { text: "Cette commande est reservee aux groupes." , contextInfo: context }, { quoted: msg });
      return;
    }

    const sender = msg.key.participant || from;
    const senderNum = sender.split("@")[0].replace(/[^0-9]/g, "");

    const owners = (global.owners || []).map(n => n.replace(/[^0-9]/g, ""));
    const sudoList = loadSudo().map(n => n.replace(/[^0-9]/g, ""));
    const isOwner = owners.includes(senderNum);
    const isSudo = sudoList.includes(senderNum);
    const isAdmin = await isGroupAdmin(sock, from, sender);

    if (!isOwner && !isSudo && !isAdmin) {
      await sock.sendMessage(from, { text: "Acces refuse. Admin, owner ou sudo requis." , contextInfo: context }, { quoted: msg });
      return;
    }

    const arg = args[0]?.toLowerCase();
    if (!arg || !["on", "off", "etat", "status"].includes(arg)) {
      const current = getGroupProtections(from).autoSigmaChat ? "Active" : "Desactive";
      await sock.sendMessage(from, { 
        text: `> SIGMA MDX DEPLOY: Auto-Sigma-Chat\n\nEtat : ${current}\n\nUtilisation : \`!sigmachat on\` ou \`!sigmachat off\`\nAlias: !akc, !autosigma, !autoai`
      }, { quoted: msg });
      return;
    }

    if (arg === "on" || arg === "off") {
      const newState = arg === "on";
      setGroupProtection(from, "autoSigmaChat", newState);

      await sock.sendMessage(from, { 
        text: `> SIGMA MDX DEPLOY: Auto-Sigma-Chat ${newState ? "active" : "desactive"} dans ce groupe.\n\n${newState ? "Le bot repondra automatiquement a tous les messages." : "Le bot ne repondra plus automatiquement."}`
      }, { quoted: msg });
    } else if (arg === "etat" || arg === "status") {
      const currentStatus = getGroupProtections(from).autoSigmaChat ? "Active" : "Desactive";
      const configInfo = `Cooldown : 5 secondes\nLongueur min : 3 caracteres\nIgnore les commandes\nAPI : Gemini`;
      
      await sock.sendMessage(from, {
        text: `> SIGMA MDX DEPLOY - Auto-Sigma-Chat\n\nEtat : ${currentStatus}\n\nConfiguration :\n${configInfo}\n\nUsage : !sigmachat on/off`
      }, { quoted: msg });
    }

  } catch (err) {
    console.error("Erreur sigmachat:", err);
    await sock.sendMessage(from, { text: "Une erreur est survenue." , contextInfo: context }, { quoted: msg });
  }
}

async function isGroupAdmin(sock, groupJid, userJid) {
  try {
    const metadata = await sock.groupMetadata(groupJid);
    return metadata.participants.some(p => p.id === userJid && p.admin);
  } catch {
    return false;
  }
}