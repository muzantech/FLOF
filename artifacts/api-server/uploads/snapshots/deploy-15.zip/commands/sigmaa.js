import fs from "fs";
import path from "path";
import { getGroupProtections, setGroupProtection } from "../groupManager.js";
import { loadSudo } from "../../index.js";
import { getContextInfo } from "./utils.js";

const GROUP_FILE = path.resolve("./group.json");

export const name = "sigmavoice";

export async function execute(sock, msg, args, from) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  try {
    // Verifie que c'est dans un groupe
    if (!from.endsWith("@g.us")) {
      await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Cette commande est reservee aux groupes uniquement." , contextInfo: context }, { quoted: msg });
      return;
    }

    const sender = msg.key.participant || from;
    const senderNum = sender.split("@")[0].replace(/[^0-9]/g, "");

    // Recuperation des owners et sudo
    const owners = (global.owners || []).map(n => n.replace(/[^0-9]/g, ""));
    const sudoList = loadSudo().map(n => n.replace(/[^0-9]/g, ""));

    const isOwner = owners.includes(senderNum);
    const isSudo = sudoList.includes(senderNum);
    const isAdmin = await isGroupAdmin(sock, from, sender);

    // Verification des permissions
    if (!isOwner && !isSudo && !isAdmin) {
      await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Acces refuse.\nSeuls les admins, owners ou sudo peuvent utiliser cette commande." 
, contextInfo: context }, { quoted: msg });
      return;
    }

    const arg = args[0]?.toLowerCase();

    // Affichage de l'etat actuel si pas d'argument ou argument invalide
    if (!arg || !["on", "off"].includes(arg)) {
      const current = getGroupProtections(from).sigmaVoice ? "active" : "desactive";
      await sock.sendMessage(from, { 
        text: `> SIGMA MDX DEPLOY : Mode SIGMA VOICE (IA Vocale Auto)\n\nEtat actuel : *${current}*\n\nUtilisation :\n\`!sigmavoice on\` Activer les reponses vocales automatiques\n\`!sigmavoice off\` Desactiver`
      }, { quoted: msg });
      return;
    }

    // Activation / Desactivation
    const newState = arg === "on";
    setGroupProtection(from, "sigmaVoice", newState);

    await sock.sendMessage(from, { 
      text: `> SIGMA MDX DEPLOY : SIGMA VOICE (IA Vocale) a ete *${newState ? "active" : "desactive"}* dans ce groupe.`
    }, { quoted: msg });

  } catch (err) {
    console.error("Erreur commande sigmavoice :", err);
    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Une erreur est survenue lors du traitement de la commande." 
, contextInfo: context }, { quoted: msg });
  }
}

// Fonction pour verifier si l'utilisateur est admin du groupe
async function isGroupAdmin(sock, groupJid, userJid) {
  try {
    const metadata = await sock.groupMetadata(groupJid);
    return metadata.participants.some(p => p.id === userJid && p.admin);
  } catch {
    return false;
  }
}