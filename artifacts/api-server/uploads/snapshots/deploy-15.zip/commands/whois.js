export const name = "whois";
import { getContextInfo } from "./utils.js";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;

  try {

    // Determiner la cible : mention, reponse ou numero fourni

    let targetJid;

    if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length) {

      targetJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];

    } else if (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {

      targetJid = msg.message.extendedTextMessage.contextInfo.participant;

    } else if (args.length) {

      targetJid = args[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    } else {

      targetJid = msg.key.participant || from;

    }

    // Recuperer les infos du contact

    const contact = await sock.onWhatsApp(targetJid);

    const profileUrl = await sock.profilePictureUrl(targetJid, "image").catch(() => null);

    // Numero enregistre sur WhatsApp

    const userNumber = contact[0]?.jid?.split("@")[0] || targetJid.split("@")[0];

    // Numero complet pour mention

    const number = targetJid.split("@")[0];

    // Texte SIGMA MDX MDX V2

    let whoisText = `> SIGMA MDX DEPLOY :
> Numero enregistre : +${userNumber}
> Numero JID : +${number}

> by SIGMA MDX
`;

    // Si pas de photo de profil

    if (!profileUrl) {

      whoisText += "\nAucune photo de profil detectee.";

      await sock.sendMessage(from, { text: `\n${whoisText}` }, { quoted: msg });

      return;

    }

    // Sinon, envoyer la photo + legende

    await sock.sendMessage(from, { 
      image: { url: profileUrl }, 
      caption: whoisText,
      contextInfo: context 
    }, { quoted: msg });

  } catch (err) {

    console.error("> SIGMA MDX MD : Erreur whois :", err);

    await sock.sendMessage(from, { text: "> SIGMA MDX MD : Erreur whois." , contextInfo: context }, { quoted: msg });

  }

}