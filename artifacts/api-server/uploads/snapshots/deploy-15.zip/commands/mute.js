import { getContextInfo } from "./utils.js";

export const name = "mute";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;

  // V�rifier si c'est un groupe
  if (!from.endsWith("@g.us")) {
    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Commande utilis�e pour les groupes." , contextInfo: context }, { quoted: msg });
    return;
  }

  try {
    // Mettre le groupe en mode admin uniquement (ferm�)
    await sock.groupSettingUpdate(from, "announcement"); // "announcement" = seuls les admins peuvent envoyer des messages
    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Groupe ferm�!" , contextInfo: context }, { quoted: msg });
  } catch (err) {
    console.error("Erreur lors de la fermeture du groupe :", err);
    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Impossible de fermer le groupe. Assurez-vous que vous �tes admin." , contextInfo: context }, { quoted: msg });
  }
}