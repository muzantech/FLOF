import moment from "moment-timezone";
import { getContextInfo } from "./utils.js";

let groupSchedules = {}; // stockage des horaires par groupe

export const name = "settimeg";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;

  try {

    // V�rifie si on est bien dans un groupe

    if (!from.endsWith("@g.us")) {

      return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY :?? Cette commande fonctionne uniquement dans un groupe.", contextInfo: context }, { quoted: msg });

    }

    // V�rifie si la commande est bien form�e

    const input = args.join(" ");

    if (!input.includes("/")) {

      return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY ?? Format invalide.\nExemple : `!settimeg 08:00/22:00`", contextInfo: context }, { quoted: msg });

    }

    const [openTime, closeTime] = input.split("/");

    // Validation format HH:mm

    if (!/^\d{2}:\d{2}$/.test(openTime) || !/^\d{2}:\d{2}$/.test(closeTime)) {

      return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY :?? Utilise le format HH:mm (exemple : 08:00/22:00).", contextInfo: context }, { quoted: msg });

    }

    // Stocke la config

    groupSchedules[from] = { open: openTime, close: closeTime };

    await sock.sendMessage(from, {
      text: `> SIGMA MDX DEPLOY ? Horaires configurés avec succès :\n\n?? Ouverture : ${openTime}\n?? Fermeture : ${closeTime}`,
      contextInfo: context
    }, { quoted: msg });

  } catch (err) {

    console.error("? Erreur settimeg :", err);

    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: ? Une erreur est survenue lors de la configuration des horaires.", contextInfo: context }, { quoted: msg });

  }

}

// Fonction pour v�rifier automatiquement les horaires

export function autoGroupScheduler(sock) {

  setInterval(async () => {

    const now = moment().tz("fuseau").format("HH:mm"); // ? adapte le fuseau horaire

    for (const groupId in groupSchedules) {

      const schedule = groupSchedules[groupId];

      try {

        if (now === schedule.open) {

          await sock.groupSettingUpdate(groupId, "not_announcement"); // ouvre le groupe

          await sock.sendMessage(groupId, { text: "> SIGMA MDX DEPLOY :?? Le groupe est maintenant *ouvert* !" });

        }

        if (now === schedule.close) {

          await sock.groupSettingUpdate(groupId, "announcement"); // ferme le groupe

          await sock.sendMessage(groupId, { text: "> SIGMA MDX DEPLOY :?? Le groupe est maintenant *ferm�* !" });

        }

      } catch (e) {

        console.error("Erreur autoGroupScheduler :", e);

      }

    }

  }, 60 * 1000); // v�rifie toutes les minutes

}