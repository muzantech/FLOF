export const name = "textmaker";
export const description = "Genere des images de texte stylisees";
export const category = "Creation";
import { getContextInfo } from "./utils.js";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  try {
    const from = msg.key.remoteJid;
    
    if (!args || args.length < 2) {
      await sock.sendMessage(from, { text: "+-- *AIDE* -\n" +
              "- *Usage*: .textmaker <type> <texte>\n" +
              "- *Exemple*: .textmaker metallic SIGMA MDX DEPLOY\n" +
              "- \n" +
              "- *Types disponibles*:\n" +
              "- - metallic - ice - snow - impressive\n" +
              "- - matrix - light - neon - devil\n" +
              "- - purple - thunder - leaves - 1917\n" +
              "- - arena - hacker - sand - blackpink\n" +
              "- - glitch - fire\n" +
              "+-----------------"
, contextInfo: context }, { quoted: msg });
      return;
    }

    const type = args[0].toLowerCase();
    const text = args.slice(1).join(' ');

    // Message d'attente
    const sentMsg = await sock.sendMessage(from, { text: "* *SIGMA MDX DEPLOY* - Generation de l'image en cours..." 
, contextInfo: context }, { quoted: msg });

    let imageUrl;
    
    // Mapping des types de texte
    switch(type) {
      case 'metallic':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/impressive-decorative-3d-metal-text-effect-798.html", text);
        break;
      case 'ice':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/ice-text-effect-online-101.html", text);
        break;
      case 'snow':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/create-a-snow-3d-text-effect-free-online-621.html", text);
        break;
      case 'impressive':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/create-3d-colorful-paint-text-effect-online-801.html", text);
        break;
      case 'matrix':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/matrix-text-effect-154.html", text);
        break;
      case 'light':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/light-text-effect-futuristic-technology-style-648.html", text);
        break;
      case 'neon':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/create-colorful-neon-light-text-effects-online-797.html", text);
        break;
      case 'devil':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/neon-devil-wings-text-effect-online-683.html", text);
        break;
      case 'purple':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/purple-text-effect-online-100.html", text);
        break;
      case 'thunder':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/thunder-text-effect-online-97.html", text);
        break;
      case 'leaves':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/green-brush-text-effect-typography-maker-online-153.html", text);
        break;
      case '1917':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/1917-style-text-effect-523.html", text);
        break;
      case 'arena':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/create-cover-arena-of-valor-by-mastering-360.html", text);
        break;
      case 'hacker':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/create-anonymous-hacker-avatars-cyan-neon-677.html", text);
        break;
      case 'sand':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/write-names-and-messages-on-the-sand-online-582.html", text);
        break;
      case 'blackpink':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/create-a-blackpink-style-logo-with-members-signatures-810.html", text);
        break;
      case 'glitch':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html", text);
        break;
      case 'fire':
        imageUrl = await mumaker.ephoto("https://en.ephoto360.com/flame-lettering-effect-372.html", text);
        break;
      default:
        await sock.sendMessage(from, { text: "+-- *ERREUR* -\n" +
                "- *SIGMA MDX DEPLOY*: Type non reconnu\n" +
                "- Utilise .textmaker sans arguments\n" +
                "- pour voir les types disponibles\n" +
                "+-----------------"
, contextInfo: context }, { quoted: sentMsg });
        return;
    }

    // Envoi de l'image generee
    await sock.sendMessage(from, { 
      image: { url: imageUrl.image }, 
      caption: `+-- *SIGMA MDX DEPLOY* -\n` +
               `- *Type*: ${type}\n` +
               `- *Texte*: ${text}\n` +
               `- \n` +
               `- Image generee avec succes\n` +
               `+-----------------`,
      contextInfo: context
    }, { quoted: sentMsg });

  } catch (err) {
    console.error("Erreur textmaker :", err);
    await sock.sendMessage(msg.key.remoteJid, { text: "+-- *ERREUR* -\n" +
            "- *SIGMA MDX DEPLOY*: Impossible de generer l'image\n" +
            "- Verifie la connexion ou reessaie plus tard\n" +
            "+-----------------"
, contextInfo: context }, { quoted: msg });
  }
}