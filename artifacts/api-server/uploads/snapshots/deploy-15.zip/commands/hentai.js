import axios from "axios";
import { getContextInfo } from "./utils.js";

export const name = 'hentai';
export const aliases = ['hneko'];
export const description = 'Get NSFW neko images with next button';
export const category = 'NSFW';

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
    const from = msg.key.remoteJid;
    
    // Verification groupe
    if (!from.endsWith('@g.us')) {
        return await sock.sendMessage(from, { text: '*SIGMA MDX DEPLOY*: This command only works in groups', contextInfo: context }, { quoted: msg });
    }

    try {
        // Message d'attente
        const sentMsg = await sock.sendMessage(from, { text: '⚡ *SIGMA MDX DEPLOY* - Fetching hentai neko...', contextInfo: context }, { quoted: msg });

        // Fetch de l'API
        const response = await axios.get('https://waifu.pics/api/nsfw/neko');
        
        if (!response.data || !response.data.url) {
            throw new Error('No image URL received from API');
        }

        // Envoyer l'image avec caption
        await sock.sendMessage(from, { image: { url: response.data.url }, caption: '⚡ *Hentai Neko* - SIGMA MDX DEPLOY\n\nUse .hneko for another image'
        , contextInfo: context }, { quoted: sentMsg });

    } catch (err) {
        console.error('Hentai-neko error:', err);
        
        let errorMessage = '*SIGMA MDX DEPLOY*: Failed to fetch image';
        if (err.code === 'ECONNREFUSED' || err.message.includes('network')) {
            errorMessage += '\nAPI might be temporarily down';
        }

        await sock.sendMessage(from, { text: errorMessage, contextInfo: context }, { quoted: msg });
    }
}
