import fs from "fs";
import path from "path";
import { getContextInfo } from "./utils.js";

export const name = "prefix";

/**
 * Commande pour basculer ou afficher le mode prefixe du bot.
 * @param {import('@whiskeysockets/baileys').WASocket} sock
 * @param {import('@whiskeysockets/baileys').WAMessage} msg
 * @param {string[]} args
 */

const getModePrefixFile = (botContext) => {
  const sessionPath = botContext?.sessionPath;
  return sessionPath ? path.join(sessionPath, "modeprefix.json") : "./modeprefix.json";
};

const getPrefixFile = (botContext) => {
  const sessionPath = botContext?.sessionPath;
  return sessionPath ? path.join(sessionPath, "prefix.json") : "./prefix.json";
};

const loadModePrefix = (file) => {
  if (!fs.existsSync(file)) return true;
  try {
    const data = JSON.parse(fs.readFileSync(file, "utf-8"));
    return data?.modeprefix ?? true;
  } catch {
    return true;
  }
};

const saveModePrefix = (file, state) => {
  fs.writeFileSync(file, JSON.stringify({ modeprefix: !!state }, null, 2));
};

const loadPrefix = (file) => {
  if (!fs.existsSync(file)) return "!";
  try {
    const data = JSON.parse(fs.readFileSync(file, "utf-8"));
    return (data?.prefix ?? "!") || "!";
  } catch {
    return "!";
  }
};

export async function execute(sock, msg, args, from, botContext) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const chat = from || msg.key.remoteJid;

  const modePrefixFile = getModePrefixFile(botContext);
  const prefixFile = getPrefixFile(botContext);
  const currentMode = loadModePrefix(modePrefixFile);
  const currentPrefix = loadPrefix(prefixFile);
  const usagePrefix = currentMode ? currentPrefix : "";

  if (!args?.length) {
    const statusText = currentMode
      ? `> Mode commande: *AVEC PRÉFIXE*\n> Exemple: ${usagePrefix}menu`
      : `> Mode commande: *SANS PRÉFIXE*\n> Exemple: menu`;
    await sock.sendMessage(chat, {
      text: `${statusText}\n\n> Pour changer: ${usagePrefix}prefix on | ${usagePrefix}prefix off`
    }, { quoted: msg });
    return;
  }

  const arg = String(args[0] || "").toLowerCase();
  let newState;
  if (arg === "true" || arg === "on") newState = true;
  else if (arg === "false" || arg === "off") newState = false;
  else {
    await sock.sendMessage(chat, {
      text: `> Argument invalide. Utilise: ${usagePrefix}prefix on | ${usagePrefix}prefix off`
    }, { quoted: msg });
    return;
  }

  if (newState === currentMode) {
    await sock.sendMessage(chat, {
      text: `> Le mode est déjà sur *${newState ? "AVEC PRÉFIXE" : "SANS PRÉFIXE"}*.`
    }, { quoted: msg });
    return;
  }

  try {
    saveModePrefix(modePrefixFile, newState);
    if (!botContext?.sessionPath) {
      global.isPrefixMode = newState;
      if (typeof global.saveModePrefix === "function") {
        try { global.saveModePrefix(newState); } catch {}
      }
    }
    const nextUsagePrefix = newState ? currentPrefix : "";
    await sock.sendMessage(chat, {
      text: `> ✅ Mode commande mis à jour: *${newState ? "AVEC PRÉFIXE" : "SANS PRÉFIXE"}*\n> Exemple: ${newState ? `${nextUsagePrefix}menu` : "menu"}`
    }, { quoted: msg });
  } catch (err) {
    console.error("Erreur lors du changement de mode prefixe :", err);
    await sock.sendMessage(chat, { text: "> ❌ Echec de la mise a jour du mode prefixe." , contextInfo: context }, { quoted: msg });
  }
}