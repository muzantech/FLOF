import { getContextInfo } from "./utils.js";

export const name = "lyrics2";
export const description = "Get song lyrics by artist and title";

export async function execute(sock, m, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    const jid = m.key.remoteJid;

    if (!args.length || !args.join(" ").includes("|")) {
      return sock.sendMessage(
        jid,
        { text: "> *SIGMA MDX* : Usage: .lyrics2 artiste | chanson" },
        { quoted: m }
      );
    }

    const [artist, title] = args.join(" ").split("|").map(v => v.trim());

    const url = `https://lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`;
    const res = await fetch(url);
    const data = await res.json();

    if (!data.lyrics) {
      return sock.sendMessage(
        jid,
        { text: "> *SIGMA MDX* : Paroles non trouvees." },
        { quoted: m }
      );
    }

    const lyrics = data.lyrics.length > 3500
      ? data.lyrics.slice(0, 3500) + "\n\n[...tronque]"
      : data.lyrics;

    await sock.sendMessage(
      jid,
      { text: `> *SIGMA MDX - Lyrics*\n\nArtiste: ${artist}\nChanson: ${title}\n\n${lyrics}` },
      { quoted: m }
    );

  } catch (e) {
    await sock.sendMessage(
      m.key.remoteJid,
      { text: `> *SIGMA MDX* : Erreur lyrics: ${e.message}` },
      { quoted: m }
    );
  }
}
