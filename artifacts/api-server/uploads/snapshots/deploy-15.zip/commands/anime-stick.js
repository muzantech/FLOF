import axios from "axios";
import { getContextInfo } from "./utils.js";

export const name = "attp";
export const description = "Generate animated text sticker";
export const category = "Sticker";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;
  
  if (!args || args.length === 0) {
    return await sock.sendMessage(from, { text: "* SIGMA MDX - ATTP*\n\n" +
            "Usage: .anime-stick <text>\n" +
            "Example: .anime-stick Hello World\n\n" +
            "Generates animated sticker from text", contextInfo: context }, { quoted: msg });
  }

  const rawText = args.join(' ');
  
  if (rawText.length > 100) {
    return await sock.sendMessage(from, { text: "> *SIGMA MDX*: Texte trop long\nMaximum 100 caracteres", contextInfo: context }, { quoted: msg });
  }

  const text = encodeURIComponent(rawText);

  try {
    await sock.sendMessage(from, { text: "> *SIGMA MDX* - Creation du sticker anime en cours..." , contextInfo: context }, { quoted: msg });

    const apis = [
      `https://api.siputzx.my.id/api/m/attp?text=${text}`,
      `https://api.erdwpe.com/api/maker/attp?text=${text}`,
      `https://api-fix.onrender.com/api/maker/attp?text=${text}`
    ];

    let stickerBuffer = null;

    for (const url of apis) {
      try {
        const res = await axios.get(url, { responseType: "arraybuffer", timeout: 15000 });
        if (res.data && res.data.byteLength > 500) {
          stickerBuffer = Buffer.from(res.data);
          break;
        }
      } catch {
        continue;
      }
    }

    if (!stickerBuffer) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX*: Impossible de generer le sticker\nLes APIs sont temporairement indisponibles", contextInfo: context }, { quoted: msg });
    }

    await sock.sendMessage(from, {
      sticker: stickerBuffer
    }, { quoted: msg });

  } catch (err) {
    console.error("ATTP Error:", err);
    await sock.sendMessage(from, { text: "> *SIGMA MDX*: Erreur lors de la generation du sticker", contextInfo: context }, { quoted: msg });
  }
}
