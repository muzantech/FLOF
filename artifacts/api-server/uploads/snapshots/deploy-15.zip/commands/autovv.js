import fs from "fs";
import path from "path";
import { getGroupProtections, setGroupProtection } from "../groupManager.js";
import { loadSudo } from "../../index.js";
import { getContextInfo } from "./utils.js";

const GROUP_FILE = path.resolve("./group.json");

export const name = "autovv";
export const aliases = ["avv2", "autoviewonce2", "vv2"];

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    const from = msg.key.remoteJid;
    
    if (!from.endsWith("@g.us")) {
      await sock.sendMessage(from, { text: "> *SIGMA MDX* : Cette commande est reservee aux groupes." , contextInfo: context }, { quoted: msg });
      return;
    }

    const sender = msg.key.participant || from;
    const senderNum = sender.split("@")[0].replace(/[^0-9]/g, "");

    const owners = (global.owners || []).map(n => n.replace(/[^0-9]/g, ""));
    const sudoList = loadSudo().map(n => n.replace(/[^0-9]/g, ""));
    const isOwner = owners.includes(senderNum);
    const isSudo = sudoList.includes(senderNum);
    const isAdmin = await isGroupAdmin(sock, from, sender);

    if (!isOwner && !isSudo && !isAdmin) {
      await sock.sendMessage(from, { text: "> *SIGMA MDX* : Acces refuse. Admin, owner ou sudo requis." , contextInfo: context }, { quoted: msg });
      return;
    }

    const arg = args[0]?.toLowerCase();
    
    if (!arg || !["on", "off", "config", "status", "help"].includes(arg)) {
      const groupProtections = getGroupProtections(from);
      const current = groupProtections?.autoVV2 ? "Active" : "Desactive";
      
      await sock.sendMessage(from, { 
        text: `> *SIGMA MDX - Auto-VV 2.0*

Etat : ${current}

Utilisation :
- .autovv on  : Active la recuperation des vues uniques
- .autovv off : Desactive la recuperation
- .autovv config : Affiche la configuration
- .autovv status : Affiche l'etat detaille

Alias : .avv2, .autoviewonce2, .vv2

Version 2.0 : Supporte images, videos, audios, stickers, documents`
      }, { quoted: msg });
      return;
    }

    if (arg === "on") {
      setGroupProtection(from, "autoVV2", true);
      
      await sock.sendMessage(from, { text: `> *SIGMA MDX - Auto-VV 2.0 ACTIVE*

SIGMA MDX recuperera automatiquement les messages en vue unique.

Support etendu : Images, Videos, Audios, Stickers, Documents

Utilisez .autovv off pour desactiver`, contextInfo: context }, { quoted: msg });
      
    } else if (arg === "off") {
      setGroupProtection(from, "autoVV2", false);
      
      await sock.sendMessage(from, { text: `> *SIGMA MDX - Auto-VV 2.0 DESACTIVE*

SIGMA MDX ne recuperera plus les messages en vue unique.`, contextInfo: context }, { quoted: msg });
      
    } else if (arg === "config" || arg === "status") {
      const groupProtections = getGroupProtections(from);
      const current = groupProtections?.autoVV2 ? "Active" : "Desactive";
      
      await sock.sendMessage(from, {
        text: `> *SIGMA MDX - Auto-VV 2.0 Configuration*

Etat : ${current}

Commandes :
- .autovv on : Active dans ce groupe
- .autovv off : Desactive dans ce groupe

Alias : .avv2, .autoviewonce2, .vv2`
      }, { quoted: msg });
      
    } else if (arg === "help") {
      await sock.sendMessage(from, { text: `> *SIGMA MDX - Aide Auto-VV 2.0*

Auto-VV 2.0 recupere automatiquement les messages envoyes en "vue unique" et les rend visibles a tous.

Fonctionnalites :
- Recupere images, videos, audios, stickers et documents
- Mentionne l'expediteur original
- Reactions automatiques

Cette fonction peut etre desactivee a tout moment avec .autovv off`, contextInfo: context }, { quoted: msg });
    }

  } catch (err) {
    console.error("Erreur commande autovv:", err);
    await sock.sendMessage(msg.key.remoteJid, { 
      text: `> *SIGMA MDX* : Erreur - ${err.message || "Erreur inconnue"}` 
    }, { quoted: msg });
  }
}

async function isGroupAdmin(sock, groupJid, userJid) {
  try {
    const metadata = await sock.groupMetadata(groupJid);
    return metadata.participants.some(p => p.id === userJid && p.admin);
  } catch {
    return false;
  }
}
