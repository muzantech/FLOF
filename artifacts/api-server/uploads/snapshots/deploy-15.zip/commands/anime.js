export const name = 'anime';
export const description = 'Get random anime images';
export const category = 'Anime';
import { getContextInfo } from "./utils.js";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;
  const botname = 'SIGMA MDX';

  try {
    await sock.sendMessage(from, { text: '> *SIGMA MDX* - Preparation des images...', contextInfo: context }, { quoted: msg });

    const imageUrls = [];
    const apiUrl = 'https://api.waifu.pics/sfw/waifu';

    for (let i = 0; i < 3; i++) {
      try {
        const response = await fetch(apiUrl);
        const data = await response.json();
        if (data && data.url) {
          imageUrls.push(data.url);
        }
        await new Promise(resolve => setTimeout(resolve, 100));
      } catch (fetchErr) {
        console.error(`Erreur recuperation image ${i+1}:`, fetchErr.message);
      }
    }

    if (imageUrls.length === 0) {
      throw new Error('Impossible de recuperer les images.');
    }

    for (let i = 0; i < imageUrls.length; i++) {
      try {
        await sock.sendMessage(from, { 
          image: { url: imageUrls[i] }, 
          caption: `> *${botname}* - Image ${i+1}/${imageUrls.length}`,
          contextInfo: context 
        });
        if (i < imageUrls.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 1500));
        }
      } catch (sendErr) {
        console.error(`Echec envoi image ${i+1}:`, sendErr);
      }
    }

    await sock.sendMessage(from, {
      text: `> *${botname}* : ${imageUrls.length} images envoyees !`,
      contextInfo: context
    }, { quoted: msg });

  } catch (err) {
    console.error('Erreur anime:', err);
    await sock.sendMessage(from, { 
      text: '> *SIGMA MDX* : Erreur lors de la recuperation des images.',
      contextInfo: context
    }, { quoted: msg });
  }
}
