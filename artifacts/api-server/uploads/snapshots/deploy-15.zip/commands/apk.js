import { getContextInfo } from "./utils.js";

export default {
  name: 'apk',
  description: 'Recherche des APK sur differents stores',
  category: 'Telechargement',

  async execute(sock, msg, args) {
    const from = msg.key.remoteJid;
    const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
    const context = getContextInfo(senderJid);

    try {
      if (!args || args.length === 0) {
        return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Usage: .apk <nom de l'application>\n\nExemple: .apk WhatsApp", contextInfo: context }, { quoted: msg });
      }

      const query = args.join(' ');

      const playStoreUrl = `https://play.google.com/store/search?q=${encodeURIComponent(query)}&c=apps`;
      const apkpureUrl = `https://apkpure.com/search?q=${encodeURIComponent(query)}`;
      const apkmirrorUrl = `https://www.apkmirror.com/?s=${encodeURIComponent(query)}`;
      const uptodownUrl = `https://en.uptodown.com/android/search/${encodeURIComponent(query)}`;

      const reply = `> *SIGMA MDX - APK Search*
> Requete: ${query}
>
> *Play Store:*
> ${playStoreUrl}
>
> *APKPure:*
> ${apkpureUrl}
>
> *APKMirror:*
> ${apkmirrorUrl}
>
> *Uptodown:*
> ${uptodownUrl}`;

      await sock.sendMessage(from, { text: reply, contextInfo: context }, { quoted: msg });

    } catch (error) {
      console.error('Erreur APK:', error);
      await sock.sendMessage(from, { text: "> *SIGMA MDX* : Impossible de generer les liens de recherche.", contextInfo: context }, { quoted: msg });
    }
  },
};
