import { getContextInfo } from "./utils.js";

export const name = "definition";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;

  try {
    if (!args.length) {
      await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Usage: !definition <mot>\nEx: !definition algorithm" , contextInfo: context }, { quoted: msg });
      return;
    }
    
    const mot = args[0];
    
    // API DictionaryAPI
    const url = `https://api.dictionaryapi.dev/api/v2/entries/en/${mot}`;
    const response = await fetch(url);
    const data = await response.json();
    
    if (data[0]) {
      const entry = data[0];
      let reply = `> SIGMA MDX DEPLOY : ${entry.word}\n----------\n`;
      
      entry.meanings.slice(0, 2).forEach((meaning, i) => {
        reply += `${meaning.partOfSpeech}\n`;
        meaning.definitions.slice(0, 2).forEach((def, j) => {
          reply += `  ${j+1}. ${def.definition}\n`;
          if (def.example) reply += `    Ex: "${def.example}"\n`;
        });
        reply += `----------\n`;
      });
      
      if (entry.phonetic) {
        reply += `Phonetique: ${entry.phonetic}\n`;
      }
      
      await sock.sendMessage(from, { text: reply , contextInfo: context }, { quoted: msg });
    } else {
      await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Mot non trouve." , contextInfo: context }, { quoted: msg });
    }
    
  } catch (err) {
    console.error("Erreur definition :", err);
    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Service dictionnaire indisponible." , contextInfo: context }, { quoted: msg });
  }
}