import axios from "axios";
import { getContextInfo } from "./utils.js";

export const name = "youtube";

const DOWNLOAD_APIS = [
  {
    name: "siputzx-mp4",
    download: async (url, format) => {
      const endpoint = format === "mp3" ? "ytmp3" : "ytmp4";
      const res = await axios.get(`https://api.siputzx.my.id/api/d/${endpoint}?url=${encodeURIComponent(url)}`, { timeout: 30000 });
      const d = res.data?.data;
      if (!d) return null;
      return { title: d.title, dl: d.dl || d.download, duration: d.duration };
    }
  },
  {
    name: "bk9",
    download: async (url, format) => {
      const endpoint = format === "mp3" ? "ytmp3" : "ytmp4";
      const res = await axios.get(`https://bk9.fun/download/${endpoint}?url=${encodeURIComponent(url)}`, { timeout: 30000 });
      const d = res.data?.BK9;
      if (!d) return null;
      return { title: d.title, dl: d.downloadUrl || d.url, duration: d.duration };
    }
  },
  {
    name: "gifted",
    download: async (url, format) => {
      const endpoint = format === "mp3" ? "ytaudio" : "ytvideo";
      const res = await axios.get(`https://api.giftedtech.co.ke/api/download/${endpoint}?apikey=gifted&url=${encodeURIComponent(url)}`, { timeout: 30000 });
      const d = res.data?.result;
      if (!d) return null;
      return { title: d.title, dl: d.download_url, duration: d.duration };
    }
  }
];

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;

  try {
    if (!args.length) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Usage: .youtube <URL>\nFormat: .youtube <URL> mp3\n\nEx: .youtube https://youtu.be/dQw4w9WgXcQ"
, contextInfo: context }, { quoted: msg });
    }

    const youtubeUrl = args[0];
    const format = args[1]?.toLowerCase() === "mp3" ? "mp3" : "mp4";

    if (!youtubeUrl.includes("youtu")) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Lien YouTube invalide."
, contextInfo: context }, { quoted: msg });
    }

    await sock.sendMessage(from, {
      text: `> *SIGMA MDX* : Telechargement ${format.toUpperCase()} en cours...`
    }, { quoted: msg });

    let result = null;
    for (const api of DOWNLOAD_APIS) {
      try {
        result = await api.download(youtubeUrl, format);
        if (result?.dl) break;
        result = null;
      } catch (e) {
        console.log(`YouTube ${api.name} failed:`, e.message);
      }
    }

    if (!result?.dl) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Echec du telechargement. APIs indisponibles."
, contextInfo: context }, { quoted: msg });
    }

    const caption = `> *SIGMA MDX - YouTube ${format.toUpperCase()}*\n\nTitre: ${result.title || "N/A"}\nDuree: ${result.duration || "N/A"}\nFormat: ${format.toUpperCase()}`;

    if (format === "mp3") {
      await sock.sendMessage(from, { text: caption , contextInfo: context }, { quoted: msg });
      await sock.sendMessage(from, {
        audio: { url: result.dl },
        mimetype: "audio/mpeg"
      }, { quoted: msg });
    } else {
      await sock.sendMessage(from, {
        video: { url: result.dl },
        caption
      }, { quoted: msg });
    }

  } catch (err) {
    console.error("Erreur YouTube:", err);
    await sock.sendMessage(from, { text: "> *SIGMA MDX* : Service YouTube indisponible."
, contextInfo: context }, { quoted: msg });
  }
}
