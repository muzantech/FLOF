import { downloadContentFromMessage } from "@whiskeysockets/baileys";
import { getContextInfo } from "./utils.js";

export const name = "setpp";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;

  // Vérifier si on a bien répondu à un message

  const ctxInfo = msg.message?.extendedTextMessage?.contextInfo;

  if (!ctxInfo || !ctxInfo.quotedMessage?.imageMessage) {

    return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: Reponds a une image pour changer la photo de profil du bot."

, contextInfo: context }, { quoted: msg });

  }

  try {

    const quoted = ctxInfo.quotedMessage.imageMessage;

    // Télécharger l'image via Baileys

    const stream = await downloadContentFromMessage(quoted, "image");

    let buffer = Buffer.from([]);

    for await (const chunk of stream) {

      buffer = Buffer.concat([buffer, chunk]);

    }

    // Définir la photo de profil du bot

    await sock.updateProfilePicture(sock.user.id, buffer);

    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: La photo de profil du bot a ete mise a jour avec succes !"

, contextInfo: context }, { quoted: msg });

  } catch (err) {

    console.error("Erreur setpp :", err);

    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: Impossible de changer la photo de profil."

, contextInfo: context }, { quoted: msg });

  }

}