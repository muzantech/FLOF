import { getGroupProtections } from "../groupManager.js";
import { loadSudo } from "../../index.js";
import { getContextInfo } from "./utils.js";

export const name = "pstate";

export async function execute(sock, msg, args, from) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    // Verifie que c'est dans un groupe
    if (!from.endsWith("@g.us")) {
      await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Cette commande est reservee aux groupes uniquement." , contextInfo: context }, { quoted: msg });
      return;
    }

    const sender = msg.key.participant || from;
    const senderNum = sender.split("@")[0].replace(/[^0-9]/g, "");

    // Recuperation des owners et sudo
    const owners = (global.owners || []).map(n => n.replace(/[^0-9]/g, ""));
    const sudoList = loadSudo().map(n => n.replace(/[^0-9]/g, ""));

    const isOwner = owners.includes(senderNum);
    const isSudo = sudoList.includes(senderNum);
    const isAdmin = await isGroupAdmin(sock, from, sender);

    // Permission : admin, owner ou sudo requis
    if (!isOwner && !isSudo && !isAdmin) {
      await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Acces refuse.\nSeuls les admins, owners ou sudo peuvent voir l'etat des protections." , contextInfo: context }, { quoted: msg });
      return;
    }

    // Recuperation des protections du groupe
    const protections = getGroupProtections(from);

    // Liste des protections a afficher (ajoute ou retire selon tes besoins)
    const protectionList = [
      { key: "antiMessage",   label: "⚡ Anti-Message (texte)",        emoji: protections.antiMessage ? "✅" : "❌" },
      { key: "antiLink",      label: "⚡ Anti-Link",                  emoji: protections.antiLink ? "✅" : "❌" },
      { key: "antiBot",       label: "⚡ Anti-Bot",                   emoji: protections.antiBot ? "✅" : "❌" },
      { key: "antiSticker",   label: "⚡ Anti-Sticker",              emoji: protections.antiSticker ? "✅" : "❌" },
      { key: "antiVoice",     label: "⚡ Anti-Vocal",                 emoji: protections.antiVoice ? "✅" : "❌" },
      { key: "antiVideo",     label: "⚡ Anti-Video",                 emoji: protections.antiVideo ? "✅" : "❌" },
      { key: "antiSpam",      label: "⚡ Anti-Spam",                  emoji: protections.antiSpam ? "✅" : "❌" },
      { key: "autoReact",     label: "⚡ Auto-Reaction",              emoji: protections.autoReact ? "✅" : "❌" },
      { key: "autoVV",        label: "⚡ Auto-VV (Vue Unique)",     emoji: protections.autoVV ? "✅" : "❌" },
      { key: "antipromote1",  label: "⚡ Anti-Promote",               emoji: protections.antipromote1 ? "✅" : "❌" },
      { key: "welcome",       label: "👋 Welcome Message",            emoji: protections.welcome ? "✅" : "❌" },
      { key: "goodbye",       label: "👋 Goodbye Message",             emoji: protections.goodbye ? "✅" : "❌" },
      { key: "autoSigmaChat",  label: "⚡ Auto-Chat (Texte)",          emoji: protections.autoSigmaChat ? "✅" : "❌" },
      { key: "sigmaVoice",         label: "⚡ Sigma Voice (IA Vocale Auto)",    emoji: protections.sigmaVoice ? "✅" : "❌" }
    ];

    // Construction du message
    const groupMetadata = await sock.groupMetadata(from);
    const groupName = groupMetadata.subject || "Groupe inconnu";

    let statusText = `> *ETAT DES PROTECTIONS*\n`;
    statusText += `> 👥 Groupe : *${groupName}*\n\n`;

    protectionList.forEach(prot => {
      statusText += `\( {prot.emoji} \){prot.label}\n`;
    });

    statusText += `\n> > Utilise les commandes comme \`!antilink on/off\`, \`!sigmavoice on/off\`, etc. pour modifier.`;

    await sock.sendMessage(from, { text: statusText , contextInfo: context }, { quoted: msg });

  } catch (err) {
    console.error("Erreur commande protectionstate :", err);
    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : > Une erreur est survenue lors de la recuperation des protections." , contextInfo: context }, { quoted: msg });
  }
}

// Fonction pour verifier si l'utilisateur est admin
async function isGroupAdmin(sock, groupJid, userJid) {
  try {
    const metadata = await sock.groupMetadata(groupJid);
    return metadata.participants.some(p => p.id === userJid && p.admin);
  } catch {
    return false;
  }
}