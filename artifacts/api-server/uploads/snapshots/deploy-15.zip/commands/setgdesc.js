export const name = "setgdesc";

import { getContextInfo } from "./utils.js";

export async function execute(sock, msg, args, from) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  if (!from.endsWith("@g.us")) {
    return await sock.sendMessage(from, { text: "❌ Cette commande ne fonctionne que dans un groupe." , contextInfo: context }, { quoted: msg });
  }
  const desc = args.join(" ").trim();
  if (!desc) {
    return await sock.sendMessage(from, { text: "❌ Donne la nouvelle description.\nExemple : !setgdesc Ma description" , contextInfo: context }, { quoted: msg });
  }
  try {
    const meta = await sock.groupMetadata(from);
    const sender = msg.key.participant || from;
    const isAdmin = meta.participants.find(p => p.id === sender)?.admin;
    if (!isAdmin) {
      return await sock.sendMessage(from, { text: "❌ Seuls les admins peuvent modifier la description." , contextInfo: context }, { quoted: msg });
    }
    await sock.groupUpdateDescription(from, desc);
    await sock.sendMessage(from, { text: "✅ Description du groupe mise à jour." , contextInfo: context }, { quoted: msg });
  } catch (e) {
    console.error("Erreur setgdesc:", e);
    await sock.sendMessage(from, { text: "❌ Impossible de modifier la description." , contextInfo: context }, { quoted: msg });
  }
}
