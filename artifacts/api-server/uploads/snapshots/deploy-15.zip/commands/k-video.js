import axios from "axios";
import { getContextInfo } from "./utils.js";

export const name = "k-video";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;

  try {
    // Recuperation du texte envoye ou cite
    const textMsg =
      msg.message?.conversation?.trim() ||
      msg.message?.extendedTextMessage?.text?.trim() ||
      msg.message?.imageMessage?.caption?.trim() ||
      msg.message?.videoMessage?.caption?.trim() ||
      "";

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const quotedText = quoted?.conversation || quoted?.extendedTextMessage?.text || "";

    // Determination du prompt a utiliser
    const used = (textMsg.split(/\s+/)[0] || ".sora");
    const prompt = textMsg.slice(used.length).trim() || quotedText;

    if (!prompt) {
      await sock.sendMessage(from, { text: `> SIGMA MDX DEPLOY : Fournis une description pour generer la video.\n\n> Exemple : . k-video anime girl with short blue hair`, contextInfo: context }, { quoted: msg });
      return;
    }

    // Message initial
    await sock.sendMessage(from, {
      text: `> +----SIGMA MDX DEPLOY----+
> Generation de la video...
> Objectif  : ${prompt}
> +---------------+`
    }, { quoted: msg });

    // Requete vers l'API Sora
    const apiUrl = `https://okatsu-rolezapiiz.vercel.app/ai/txt2video?text=${encodeURIComponent(prompt)}`;
    const { data } = await axios.get(apiUrl, {
      timeout: 120000,
      headers: { "User-Agent": "Mozilla/5.0 (SIGMA MDDEPLOY)" }
    });

    // Verification du resultat
    const videoUrl = data?.videoUrl || data?.result || data?.data?.videoUrl;
    if (!videoUrl) throw new Error("Aucune video trouvee dans la reponse de l'API.");

    // Envoi du resultat
    await sock.sendMessage(from, {
      video: { url: videoUrl },
      mimetype: "video/mp4",
      caption: `> **Video generee par SIGMA MDX DEPLOY*\n> Objectif : ${prompt}`
    }, { quoted: msg });

  } catch (err) {
    console.error("Erreur K12 :", err?.message || err);
    await sock.sendMessage(from, { text: `> SIGMA MDX DEPLOY: Echec de la generation video.\n> Reessaie avec un autre prompt.`, contextInfo: context }, { quoted: msg });
  }
}