import { getContextInfo } from "./utils.js";

export const name = "lyrictts";
export const description = "Convert song lyrics to voice (TTS)";

export async function execute(sock, m, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    const jid = m.key.remoteJid;

    if (!args.length || !args.join(" ").includes("|")) {
      return sock.sendMessage(
        jid,
        { text: "> *SIGMA MDX* : Usage: .lyrictts artiste | chanson" },
        { quoted: m }
      );
    }

    const [artist, title] = args.join(" ").split("|").map(v => v.trim());

    const lyricsURL = `https://lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`;
    const lyricsRes = await fetch(lyricsURL);
    const lyricsData = await lyricsRes.json();

    if (!lyricsData.lyrics) {
      return sock.sendMessage(
        jid,
        { text: "> *SIGMA MDX* : Paroles non trouvees." },
        { quoted: m }
      );
    }

    const text = lyricsData.lyrics
      .replace(/\n+/g, ". ")
      .slice(0, 1800);

    const ttsURL =
      "https://translate.google.com/translate_tts" +
      `?ie=UTF-8&client=tw-ob&tl=en&q=${encodeURIComponent(text)}`;

    const audioRes = await fetch(ttsURL);
    const audioBuffer = Buffer.from(await audioRes.arrayBuffer());

    await sock.sendMessage(
      jid,
      {
        audio: audioBuffer,
        mimetype: "audio/mpeg",
        ptt: true
      },
      { quoted: m }
    );

  } catch (err) {
    await sock.sendMessage(
      m.key.remoteJid,
      { text: `> *SIGMA MDX* : Erreur TTS lyrics: ${err.message}` },
      { quoted: m }
    );
  }
}
