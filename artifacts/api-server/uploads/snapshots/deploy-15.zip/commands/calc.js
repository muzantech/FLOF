import { getContextInfo } from "./utils.js";

export const name = "calc";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    const from = msg.key.remoteJid;
    
    if (!args.length) {
      return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: Veuillez fournir une expression.\nExemple: `!calc 2+2*5` ou `!calc sin(45)`" , contextInfo: context }, { quoted: msg });
    }

    const expression = args.join(" ");
    
    // Message de traitement
    const processingMsg = await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: Calcul en cours..." , contextInfo: context }, { quoted: msg });

    // Nettoyer et evaluer l'expression mathematique
    const result = safeEvaluate(expression);
    
    if (result.error) {
      await sock.sendMessage(from, { 
        text: `> ❌ SIGMA MDX DEPLOY: Erreur de calcul\nExpression: ${expression}\nErreur: ${result.message}` 
      }, { quoted: processingMsg });
      return;
    }

    // Reponse stylisee
    const reply = `> SIGMA MDX DEPLOY: Calculatrice\n----------\nExpression: ${expression}\nResultat: ${result.value}\n----------\nFormat: ${result.format}`;
    
    await sock.sendMessage(from, { text: reply , contextInfo: context }, { quoted: processingMsg });

  } catch (err) {
    console.error("Erreur calc :", err);
    await sock.sendMessage(msg.key.remoteJid, { text: "> SIGMA MDX DEPLOY: Erreur lors du calcul.", contextInfo: context }, { quoted: msg });
  }
};

// Fonction d'evaluation securisee
function safeEvaluate(expression) {
  try {
    // Nettoyer l'expression (securite)
    let cleanExpr = expression
      .replace(/[^0-9+\-*/().,%pv^!&|<>=\s]/g, '')
      .replace(/p/g, 'Math.PI')
      .replace(/v/g, 'Math.sqrt')
      .replace(/sin/g, 'Math.sin')
      .replace(/cos/g, 'Math.cos')
      .replace(/tan/g, 'Math.tan')
      .replace(/log/g, 'Math.log10')
      .replace(/ln/g, 'Math.log')
      .replace(/\^/g, '**');
    
    // Verifier les expressions dangereuses
    const dangerousPatterns = [
      /process\./i,
      /require\(/i,
      /eval\(/i,
      /Function\(/i,
      /while\(/i,
      /for\(/i,
      /import\(/i,
      /exports\./i,
      /module\./i
    ];
    
    for (const pattern of dangerousPatterns) {
      if (pattern.test(cleanExpr)) {
        return { error: true, message: "Expression non autorisee" };
      }
    }
    
    // Evaluer l'expression
    let value = eval(cleanExpr);
    
    // Formater le resultat
    let format = "Nombre decimal";
    
    // Verifier si c'est un entier
    if (Number.isInteger(value)) {
      format = "Entier";
    }
    
    // Verifier si c'est un nombre scientifique
    if (Math.abs(value) >= 1e6 || (Math.abs(value) <= 1e-6 && value !== 0)) {
      value = value.toExponential(4);
      format = "Notation scientifique";
    } else {
      // Arrondir a 6 decimales max
      value = Math.round(value * 1e6) / 1e6;
    }
    
    // Formater avec separateurs de milliers
    if (!isNaN(value) && Math.abs(value) >= 1000 && format !== "Notation scientifique") {
      value = value.toLocaleString('fr-FR');
      format = "Nombre formate";
    }
    
    // Conversions supplementaires
    let conversions = "";
    if (!isNaN(value) && value > 0) {
      const binary = Math.round(value).toString(2);
      const hex = Math.round(value).toString(16).toUpperCase();
      if (binary.length <= 16) {
        conversions = `\nBinaire: ${binary}\nHexadecimal: ${hex}`;
      }
    }
    
    return { 
      error: false, 
      value: value,
      format: format + conversions
    };
    
  } catch (err) {
    return { 
      error: true, 
      message: "Expression mathematique invalide" 
    };
  }
}