import { getContextInfo } from "./utils.js";

export const name = "infos";
export const description = "Affiche les informations du bot et de son syst�me.";

export async function execute(sock, msg, args, options = {}) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const { botNumber = "" } = options;
  const from = msg?.key?.remoteJid || (msg?.key?.participant || "");

  // === Uptime ===
  const uptime = process.uptime(); // sec
  const h = Math.floor(uptime / 3600);
  const m = Math.floor((uptime % 3600) / 60);
  const s = Math.floor(uptime % 60);
  const uptimeStr = `${h}h ${m}m ${s}s`;

  // === M�moire & platform ===
  let usedMemMB = (process.memoryUsage().rss / 1024 / 1024).toFixed(2);
  let totalMemGB = "N/A";
  let platform = "N/A";
  try {
    const os = await import("os");
    totalMemGB = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
    platform = `${os.platform()} ${os.release()}`;
  } catch (e) {
    console.warn("Impossible d'importer 'os' dynamiquement :", e?.message || e);
  }

  // === Latence ===
  const start = Date.now();
  await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: ? V�rification des performances..." , contextInfo: context }, { quoted: msg }).catch(() => {});
  const latency = Date.now() - start;

  // === Num�ro du bot ===
  const botJid = botNumber || (sock?.user?.id || sock?.user?.jid || "").split?.(":")?.[0] || "Inconnu";

  // === Message format� avec '>' devant chaque ligne ===
  const text = 
`> SIGMA MDX DEPLOY ? Informations du bot
 
> ?? Num�ro     : ${botJid}
> ?? Uptime     : ${uptimeStr}
> ?? Latence    : ${latency} ms
> ?? M�moire    : ${usedMemMB} MB / ${totalMemGB} GB
> ?? Platforme  : ${platform}

> Dev by SIGMA MDX`;

  await sock.sendMessage(from, { text }, { quoted: msg }).catch(err => console.error("infos sendMessage:", err));
}