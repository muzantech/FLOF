import axios from "axios";
import fs from "fs";
import path from "path";
import { getContextInfo } from "./utils.js";

export const name = "podcast";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;

  try {
    if (!args.length) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Usage: .podcast <sujet>\nEx: .podcast intelligence artificielle", contextInfo: context }, { quoted: msg });
    }

    const topic = args.join(" ");

    await sock.sendMessage(from, {
      text: `> *SIGMA MDX* : Generation du podcast sur "${topic}"...`
    }, { quoted: msg });

    const aiApis = [
      { url: `https://api.giftedtech.co.ke/api/ai/ai?apikey=gifted&q=${encodeURIComponent("Fais un court podcast de 3 paragraphes sur: " + topic)}` },
      { url: `https://bk9.fun/ai/GPT4o?q=${encodeURIComponent("Fais un court podcast de 3 paragraphes sur: " + topic)}` }
    ];

    let podcastText = null;
    for (const api of aiApis) {
      try {
        const { data } = await axios.get(api.url, { timeout: 20000 });
        podcastText = data?.result || data?.BK9 || data?.message || data?.answer;
        if (podcastText) break;
      } catch { continue; }
    }

    if (!podcastText) {
      podcastText = `Bienvenue dans ce podcast sur ${topic}. C'est un sujet passionnant qui merite notre attention. Restez a l'ecoute pour en savoir plus.`;
    }

    const ttsText = podcastText.substring(0, 1800);
    const ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(ttsText)}&tl=fr&client=tw-ob`;

    const res = await axios.get(ttsUrl, {
      responseType: "arraybuffer",
      headers: { "User-Agent": "Mozilla/5.0" },
      timeout: 15000
    });

    await sock.sendMessage(from, { text: `> *SIGMA MDX - Podcast*\nSujet: ${topic}\n\n${ttsText.substring(0, 500)}...` }, { quoted: msg });

    await sock.sendMessage(from, {
      audio: Buffer.from(res.data),
      mimetype: "audio/mpeg",
      ptt: true
    }, { quoted: msg });

  } catch (err) {
    console.error("Erreur podcast:", err);
    await sock.sendMessage(from, { text: "> *SIGMA MDX* : Service podcast indisponible.", contextInfo: context }, { quoted: msg });
  }
}
