export const name = "setgname";

import { getContextInfo } from "./utils.js";

export async function execute(sock, msg, args, from) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  if (!from.endsWith("@g.us")) {
    return await sock.sendMessage(from, { text: "❌ Cette commande ne fonctionne que dans un groupe." , contextInfo: context }, { quoted: msg });
  }
  const newName = args.join(" ").trim();
  if (!newName) {
    return await sock.sendMessage(from, { text: "❌ Donne le nouveau nom du groupe.\nExemple : !setgname Mon Groupe" , contextInfo: context }, { quoted: msg });
  }
  try {
    const meta = await sock.groupMetadata(from);
    const sender = msg.key.participant || from;
    const isAdmin = meta.participants.find(p => p.id === sender)?.admin;
    if (!isAdmin) {
      return await sock.sendMessage(from, { text: "❌ Seuls les admins peuvent modifier le nom." , contextInfo: context }, { quoted: msg });
    }
    await sock.groupUpdateSubject(from, newName);
    await sock.sendMessage(from, { text: `✅ Nom du groupe mis à jour : *${newName}*` }, { quoted: msg });
  } catch (e) {
    console.error("Erreur setgname:", e);
    await sock.sendMessage(from, { text: "❌ Impossible de modifier le nom." , contextInfo: context }, { quoted: msg });
  }
}
