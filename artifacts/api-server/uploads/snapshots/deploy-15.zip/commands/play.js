import axios from "axios";
import yts from "yt-search";
import { getContextInfo } from "./utils.js";

export const name = "play";
export const description = "Download music from YouTube";
export const category = "Download";

const DOWNLOAD_APIS = [
  {
    name: "api-gifted-dlmp4",
    getAudio: async (url) => {
      const res = await axios.get(`https://api.giftedtech.co.ke/api/download/dlmp4?apikey=gifted&url=${encodeURIComponent(url)}`, { timeout: 25000 });
      return res.data?.result?.audio || res.data?.result?.download_url || null;
    }
  },
  {
    name: "api-gifted-ytaudio",
    getAudio: async (url) => {
      const res = await axios.get(`https://api.giftedtech.co.ke/api/download/ytaudio?apikey=gifted&url=${encodeURIComponent(url)}`, { timeout: 25000 });
      return res.data?.result?.download_url || null;
    }
  },
  {
    name: "api-siputzx",
    getAudio: async (url) => {
      const res = await axios.get(`https://api.siputzx.my.id/api/d/ytmp3?url=${encodeURIComponent(url)}`, { timeout: 25000 });
      return res.data?.data?.dl || res.data?.data?.download || null;
    }
  },
  {
    name: "api-vreden",
    getAudio: async (url) => {
      const res = await axios.get(`https://api.vreden.my.id/api/ytmp3?url=${encodeURIComponent(url)}`, { timeout: 25000 });
      return res.data?.result?.download?.url || res.data?.result?.audio || null;
    }
  },
  {
    name: "api-bk9",
    getAudio: async (url) => {
      const res = await axios.get(`https://bk9.fun/download/ytmp3?url=${encodeURIComponent(url)}`, { timeout: 25000 });
      return res.data?.BK9?.downloadUrl || res.data?.BK9?.url || null;
    }
  }
];

export async function execute(sock, msg, args, from) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const title = args.join(" ").trim();
  if (!title) {
    return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Donne un titre ou artiste.\nEx: .play Faded Alan Walker", contextInfo: context }, { quoted: msg });
  }

  try {
    await sock.sendMessage(from, {
      text: `> *SIGMA MDX* : Recherche de *${title}*...`,
      contextInfo: context
    }, { quoted: msg });

    const search = await yts(title);
    const video = search.videos?.[0];

    if (!video?.url) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Aucun resultat trouve.", contextInfo: context }, { quoted: msg });
    }

    let audioUrl = null;
    for (const api of DOWNLOAD_APIS) {
      try {
        audioUrl = await api.getAudio(video.url);
        if (audioUrl) break;
      } catch (e) {
        console.log(`Play ${api.name} failed:`, e.message);
      }
    }

    if (!audioUrl) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Impossible de telecharger l'audio. APIs indisponibles.", contextInfo: context }, { quoted: msg });
    }

    const caption = `> *SIGMA MDX - Music*\n\nTitre: ${video.title}\nDuree: ${video.timestamp || "N/A"}\nChaine: ${video.author?.name || "N/A"}`;

    if (video.thumbnail) {
      try {
        await sock.sendMessage(from, { image: { url: video.thumbnail }, caption, contextInfo: context }, { quoted: msg });
      } catch {
        await sock.sendMessage(from, { text: caption, contextInfo: context }, { quoted: msg });
      }
    } else {
      await sock.sendMessage(from, { text: caption, contextInfo: context }, { quoted: msg });
    }

    await sock.sendMessage(from, { audio: { url: audioUrl }, mimetype: "audio/mpeg", ptt: false, contextInfo: context }, { quoted: msg });

  } catch (err) {
    console.error("Erreur play:", err);
    await sock.sendMessage(from, {
      text: `> *SIGMA MDX* : Echec du telechargement.\n${err?.message || err}`,
      contextInfo: context
    }, { quoted: msg });
  }
}
