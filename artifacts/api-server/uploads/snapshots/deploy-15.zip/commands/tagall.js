export const name = "tagall";

export async function execute(sock, msg, args) {
  try {
    const from = msg.key.remoteJid;

    // Vérifier si c'est un groupe
    if (!from.endsWith("@g.us")) {
      return await sock.sendMessage(from, { text: "❌ Cette commande fonctionne seulement dans un groupe." }, { quoted: msg });
    }

    // Récupérer les participants
    const groupMetadata = await sock.groupMetadata(from);
    const participants = groupMetadata.participants;

    // Construire le message avec mentions
    const mentions = participants.map(p => p.id);
    let text = "📢 Attention tout le monde !\n\n";
    text += mentions.map(id => `@${id.split("@")[0]}`).join(" ") + "\n\nby SIGMA MDX";

    // Envoyer le message avec mentions
    await sock.sendMessage(from, { text, mentions }, { quoted: msg });

  } catch (err) {
    console.error("❌ Erreur tagall :", err);
    await sock.sendMessage(msg.key.remoteJid, {
      text: "Impossible de taguer tous les membres. Vérifie que le bot est admin.\n\nby SIGMA MDX"
    }, { quoted: msg });
  }
}