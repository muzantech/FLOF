import { getContextInfo } from "./utils.js";

export const name = "itunes";
export const description = "Search music on iTunes";

export async function execute(sock, m, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    const jid = m.key.remoteJid;

    if (!args.length) {
      return sock.sendMessage(
        jid,
        { text: "> *SIGMA MDX* : Usage: .itunes <artiste ou chanson>" },
        { quoted: m }
      );
    }

    const query = args.join(" ");
    const url = `https://itunes.apple.com/search?term=${encodeURIComponent(query)}&entity=song&limit=5`;

    const res = await fetch(url);
    const data = await res.json();

    if (!data.results || data.results.length === 0) {
      return sock.sendMessage(
        jid,
        { text: "> *SIGMA MDX* : Aucun resultat trouve." },
        { quoted: m }
      );
    }

    let text = `> *SIGMA MDX - iTunes*\n\n`;

    data.results.forEach((song, i) => {
      text += `${i + 1}. *${song.trackName}*\n`;
      text += `   Artiste: ${song.artistName}\n`;
      text += `   Album: ${song.collectionName}\n`;
      text += `   Duree: ${(song.trackTimeMillis / 60000).toFixed(2)} min\n`;
      text += `   Lien: ${song.trackViewUrl}\n\n`;
    });

    await sock.sendMessage(
      jid,
      { text: text.trim() },
      { quoted: m }
    );

  } catch (e) {
    await sock.sendMessage(
      m.key.remoteJid,
      { text: `> *SIGMA MDX* : Erreur iTunes: ${e.message}` },
      { quoted: m }
    );
  }
}
