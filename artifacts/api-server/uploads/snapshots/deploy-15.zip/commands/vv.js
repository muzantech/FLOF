import { downloadContentFromMessage } from "@whiskeysockets/baileys";
import { getContextInfo } from "./utils.js";

export const name = "vv";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const quoted = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;
  
  if (!quoted) {
    await sock.sendMessage(
      msg.key.remoteJid,
      { text: "> SIGMA MDX DEPLOY : Répondez à une photo, vidéo ou audio vue unique." },
      { quoted: msg }
    );
    return;
  }

  // Extraction du vrai message (vue unique)
  const innerMsg =
    quoted.viewOnceMessageV2?.message ||
    quoted.viewOnceMessageV2Extension?.message ||
    quoted;

  // --- Image vue unique ---
  if (innerMsg.imageMessage) {
    const stream = await downloadContentFromMessage(innerMsg.imageMessage, "image");
    let buffer = Buffer.from([]);
    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

    await sock.sendMessage(
      msg.key.remoteJid,
      { image: buffer, caption: "> SIGMA MDX DEPLOY : 📸 Vue unique récupérée" },
      { quoted: msg }
    );
    return;
  }

  // --- Vidéo vue unique ---
  if (innerMsg.videoMessage) {
    const stream = await downloadContentFromMessage(innerMsg.videoMessage, "video");
    let buffer = Buffer.from([]);
    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

    await sock.sendMessage(
      msg.key.remoteJid,
      { video: buffer, caption: "> SIGMA MDX DEPLOY : 📹 Vue unique récupérée" },
      { quoted: msg }
    );
    return;
  }

  // --- Audio vue unique ---
  if (innerMsg.audioMessage) {
    const stream = await downloadContentFromMessage(innerMsg.audioMessage, "audio");
    let buffer = Buffer.from([]);
    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

    await sock.sendMessage(
      msg.key.remoteJid,
      { audio: buffer, mimetype: "audio/mpeg" },
      { quoted: msg }
    );
    return;
  }

  await sock.sendMessage(
    msg.key.remoteJid,
    { text: "> SIGMA MDX DEPLOY: ❌ Pas une photo, vidéo ou audio vue unique." },
    { quoted: msg }
  );
}
