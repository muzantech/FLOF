export const name = "unlockgc";
import { getContextInfo } from "./utils.js";

export async function execute(sock, msg, args, from) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  if (!from.endsWith("@g.us")) {
    return await sock.sendMessage(from, { text: "❌ Cette commande ne fonctionne que dans un groupe." , contextInfo: context }, { quoted: msg });
  }
  try {
    const meta = await sock.groupMetadata(from);
    const sender = msg.key.participant || from;
    const isAdmin = meta.participants.find(p => p.id === sender)?.admin;
    if (!isAdmin) {
      return await sock.sendMessage(from, { text: "❌ Seuls les admins peuvent déverrouiller le groupe." , contextInfo: context }, { quoted: msg });
    }
    await sock.groupSettingUpdate(from, "unlocked");
    await sock.sendMessage(from, { text: "🔓 Groupe déverrouillé. Les nouveaux membres peuvent rejoindre." , contextInfo: context }, { quoted: msg });
  } catch (e) {
    console.error("Erreur unlockgc:", e);
    await sock.sendMessage(from, { text: "❌ Impossible de déverrouiller." , contextInfo: context }, { quoted: msg });
  }
}
