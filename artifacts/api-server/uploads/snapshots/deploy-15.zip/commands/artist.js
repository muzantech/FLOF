import { getContextInfo } from "./utils.js";

export const name = "artist";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;
  try {
    if (!args.length) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Usage: .artist <nom>\nEx: .artist Ed Sheeran" , contextInfo: context }, { quoted: msg });
    }
    const artist = args.join(" ");
    const url = `https://itunes.apple.com/search?term=${encodeURIComponent(artist)}&entity=musicArtist&limit=1`;
    const res = await fetch(url);
    const data = await res.json();
    if (!data.results?.length) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Artiste non trouve." , contextInfo: context }, { quoted: msg });
    }
    const a = data.results[0];
    const songsRes = await fetch(`https://itunes.apple.com/lookup?id=${a.artistId}&entity=song&limit=5`);
    const songsData = await songsRes.json();
    const songs = songsData.results?.filter(r => r.wrapperType === "track").slice(0, 5);
    let reply = `> *SIGMA MDX - Artist*\n\nNom: ${a.artistName}\nGenre: ${a.primaryGenreName || "N/A"}\nLien: ${a.artistLinkUrl || "N/A"}`;
    if (songs?.length) {
      reply += `\n\nTop chansons:\n` + songs.map((s, i) => `${i+1}. ${s.trackName} (${s.collectionName})`).join("\n");
    }
    await sock.sendMessage(from, { text: reply , contextInfo: context }, { quoted: msg });
  } catch (err) {
    console.error("Erreur artist:", err);
    await sock.sendMessage(from, { text: "> *SIGMA MDX* : Service artistes indisponible." , contextInfo: context }, { quoted: msg });
  }
}
