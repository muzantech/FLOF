import axios from "axios";
import { getContextInfo } from "./utils.js";

export const name = "ttp";
export const description = "Generate text sticker (static)";
export const category = "Sticker";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;
  
  if (!args || args.length === 0) {
    return await sock.sendMessage(from, { text: "* SIGMA MDX - TTP*\n\n" +
            "Usage: .static-stick <text>\n" +
            "Example: .static-stick Hello World\n\n" +
            "Creates a text sticker (static image)", contextInfo: context }, { quoted: msg });
  }

  const rawText = args.join(' ');
  
  if (rawText.length > 50) {
    return await sock.sendMessage(from, { text: "> *SIGMA MDX*: Texte trop long\nMaximum 50 caracteres pour de meilleurs resultats", contextInfo: context }, { quoted: msg });
  }

  const text = encodeURIComponent(rawText);

  try {
    await sock.sendMessage(from, { text: "> *SIGMA MDX* - Creation du sticker texte en cours..." , contextInfo: context }, { quoted: msg });

    const apis = [
      `https://api.siputzx.my.id/api/m/ttp?text=${text}`,
      `https://api.erdwpe.com/api/maker/texttopng?text=${text}`,
      `https://api-fix.onrender.com/api/maker/ttp?text=${text}`
    ];

    let stickerBuffer = null;

    for (const url of apis) {
      try {
        const res = await axios.get(url, { responseType: "arraybuffer", timeout: 15000 });
        if (res.data && res.data.byteLength > 500) {
          stickerBuffer = Buffer.from(res.data);
          break;
        }
      } catch {
        continue;
      }
    }

    if (!stickerBuffer) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX*: Impossible de generer le sticker texte\nReessayez avec un texte plus court", contextInfo: context }, { quoted: msg });
    }

    await sock.sendMessage(from, {
      sticker: stickerBuffer
    }, { quoted: msg });

  } catch (err) {
    console.error("TTP Error:", err);
    await sock.sendMessage(from, { text: "> *SIGMA MDX*: Erreur lors de la generation du sticker texte", contextInfo: context }, { quoted: msg });
  }
}
