export const name = "aquote";
export const description = "Get a random anime quote";
import { getContextInfo } from "./utils.js";

export async function execute(sock, m, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    const jid = m.key.remoteJid;

    let url = "https://animechan.vercel.app/api/random";

    if (args.length) {
      const anime = args.join(" ");
      url = `https://animechan.vercel.app/api/random/anime?title=${encodeURIComponent(anime)}`;
    }

    let res = await fetch(url);

    if (res.status === 404) {
      res = await fetch("https://animechan.vercel.app/api/random");
    }

    if (!res.ok) throw new Error(`HTTP Error ${res.status}`);

    let data;
    try {
      data = await res.json();
    } catch {
      throw new Error("Reponse non JSON recue");
    }

    if (!data || !data.quote) {
      return await sock.sendMessage(
        jid,
        { text: "> *SIGMA MDX* : Impossible de recuperer la citation." },
        { quoted: m }
      );
    }

    await sock.sendMessage(
      jid,
      {
        text: `> *SIGMA MDX - Anime Quote*\n\n"${data.quote}"\n-- ${data.character} (${data.anime})`
      },
      { quoted: m }
    );

  } catch (err) {
    await sock.sendMessage(
      m.key.remoteJid,
      { text: `> *SIGMA MDX* : Erreur AnimeQuote: ${err.message}` },
      { quoted: m }
    );
  }
}
