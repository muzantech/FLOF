import { igdl } from "ruhend-scraper";
import { getContextInfo } from "./utils.js";

// Stockage des messages deja traites pour eviter les doublons
const processedMessages = new Set();

export const name = "instagram";
export const description = "Telecharge des posts, reels ou videos Instagram";
export const category = "⚡ Telechargement";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;

  try {
    // Eviter de traiter le meme message plusieurs fois
    if (processedMessages.has(msg.key.id)) return;
    processedMessages.add(msg.key.id);
    setTimeout(() => processedMessages.delete(msg.key.id), 5 * 60 * 1000); // 5 min

    const text = args.join(" ").trim() || msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.conversation || "";

    if (!text) {
      await sock.sendMessage(from, { text: `> SIGMA MDX DEPLOY : Veuillez fournir un lien Instagram
> Exemple : .instagram https://www.instagram.com/p/XXXX`
, contextInfo: context }, { quoted: msg });
      return;
    }

    const instaPatterns = [
      /https?:\/\/(?:www\.)?instagram\.com\//,
      /https?:\/\/(?:www\.)?instagr\.am\//
    ];

    if (!instaPatterns.some(p => p.test(text))) {
      await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: Lien Instagram invalide." , contextInfo: context }, { quoted: msg });
      return;
    }

    await sock.sendMessage(from, { react: { text: "⚡ ", key: msg.key } });

    const downloadData = await igdl(text);
    if (!downloadData?.data?.length) {
      await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: Aucun media trouve ou le post est prive." , contextInfo: context }, { quoted: msg });
      return;
    }

    // Deduplication simple des URLs
    const uniqueMedia = [];
    const seenUrls = new Set();
    for (const media of downloadData.data) {
      if (media.url && !seenUrls.has(media.url)) {
        seenUrls.add(media.url);
        uniqueMedia.push(media);
      }
    }

    const mediaToDownload = uniqueMedia.slice(0, 20);
    if (!mediaToDownload.length) {
      await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: Aucun media valide trouve a telecharger." , contextInfo: context }, { quoted: msg });
      return;
    }

    // Telechargement et envoi
    for (let i = 0; i < mediaToDownload.length; i++) {
      const media = mediaToDownload[i];
      const url = media.url;
      const isVideo = /\.(mp4|mov|avi|mkv|webm)$/i.test(url) || media.type === "video";

      try {
        if (isVideo) {
          await sock.sendMessage(from, {
            video: { url },
            mimetype: "video/mp4",
            caption: "> SIGMA MDX DEPLOY: Telechargement reussi."
          }, { quoted: msg });
        } else {
          await sock.sendMessage(from, { image: { url }, caption: "> SIGMA MDX DEPLOY: Telechargement reussi."
          , contextInfo: context }, { quoted: msg });
        }

        if (i < mediaToDownload.length - 1) await new Promise(r => setTimeout(r, 1000));

      } catch (mediaError) {
        console.error(`Erreur telechargement media ${i + 1}:`, mediaError);
      }
    }

  } catch (error) {
    console.error("Erreur Instagram:", error);
    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: ❌ Erreur\n> Impossible de traiter le lien Instagram. Reessayez plus tard."
, contextInfo: context }, { quoted: msg });
  }
}