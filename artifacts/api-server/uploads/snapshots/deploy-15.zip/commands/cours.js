import { getContextInfo } from "./utils.js";

export const name = "cours";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;

  try {
    const sujet = args.join(" ") || "programmation";
    
    // API Coursera Catalog (gratuit)
    const url = `https://api.coursera.org/api/courses.v1?q=search&query=${encodeURIComponent(sujet)}&limit=3`;
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (!data.elements || data.elements.length === 0) {
      await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Aucun cours trouve." , contextInfo: context }, { quoted: msg });
      return;
    }
    
    let reply = `> SIGMA MDX DEPLOY : Cours ${sujet}\n\n`;
    
    data.elements.slice(0, 3).forEach((cours, i) => {
      reply += `${i+1}. ${cours.name}\n`;
      reply += `Universite: ${cours.partnerNames?.[0] || "Divers"}\n`;
      reply += `Note: ${cours.averageRating || "N/A"}/5\n`;
      reply += `Niveau: ${cours.difficultyLevel || "Debutant"}\n`;
      reply += `https://www.coursera.org/learn/${cours.slug}\n`;
      reply += `\n`;
    });
    
    await sock.sendMessage(from, { text: reply , contextInfo: context }, { quoted: msg });
    
  } catch (err) {
    console.error("Erreur coursera :", err);
    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Service Coursera indisponible." , contextInfo: context }, { quoted: msg });
  }
}