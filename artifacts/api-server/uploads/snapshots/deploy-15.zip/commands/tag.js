import { getContextInfo } from "./utils.js";

export const name = "tag";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;

  // Verifie si c'est un groupe

  if (!from.endsWith("@g.us")) {

    return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Commande reservee aux groupes seulement." , contextInfo: context }, { quoted: msg });

  }

  try {

    const groupMetadata = await sock.groupMetadata(from);

    const participants = groupMetadata.participants;

    let message;

    // Si on repond a un message

    const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

    if (quotedMsg) {

      message =

        quotedMsg.conversation ||

        quotedMsg.extendedTextMessage?.text ||

        quotedMsg.imageMessage?.caption ||

        quotedMsg.videoMessage?.caption ||

        "> 'Default message'....'' ";

    }

    // Si on fournit des arguments

    else if (args.length) {

      message = args.join(" ");

    }

    // Si rien du tout

    else {

      message = "> 'Default message'....'' ";

    }

    await sock.sendMessage(

      from,

      {

        text: message,

        mentions: participants.map(p => p.id)

      },

      { quoted: msg }

    );

  } catch (e) {

    console.error("Erreur commande tag :", e);

    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Erreur lors de l'envoi du tag." , contextInfo: context }, { quoted: msg });

  }

}