import fs from "fs";
import path from "path";
import { downloadMediaMessage } from "@whiskeysockets/baileys";

export const name = "save";

import { getContextInfo } from "./utils.js";

export async function execute(sock, m, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  try {
    const selfJid = sock.user.id; // ton propre JID
    const msg = m.message?.extendedTextMessage
      ? m.message?.extendedTextMessage?.contextInfo?.quotedMessage
      : m.message;

    if (!msg) {
      await sock.sendMessage(m.key.remoteJid, { text: "> SIGMA MDX DEPLOY : R�pondez � un m�dia ou texte pour le sauvegarder" , contextInfo: context }, { quoted: m });
      return;
    }

    const type = Object.keys(msg)[0];

    // === Texte ===
    if (type === "conversation" || type === "extendedTextMessage") {
      const text =
        msg.conversation || msg.extendedTextMessage?.text || "? Message vide";
      await sock.sendMessage(selfJid, { text: `> SIGMA MDX DEPLOY: ?? Sauvegarde:\n\n${text}` });
      await sock.sendMessage(m.key.remoteJid, { text: "> SIGMA MDX DEPLOY : Texte sauvegard�" , contextInfo: context }, { quoted: m });
      return;
    }

    // === M�dias ===
    const buffer = await downloadMediaMessage(
      { message: msg },
      "buffer",
      {},
      { logger: console }
    );

    let fileName = Date.now().toString();
    let sendContent = {};

    if (type === "imageMessage") {
      fileName += ".jpg";
      sendContent = { image: buffer, caption: "> SIGMA MDX DEPLOY : Image sauvegard�" };
    } else if (type === "videoMessage") {
      fileName += ".mp4";
      sendContent = { video: buffer, caption: "> SIGMA MDX DEPLOY : video sauvegard�" };
    } else if (type === "audioMessage") {
      fileName += ".mp3";
      sendContent = { audio: buffer, mimetype: "audio/mpeg", fileName };
    } else if (type === "documentMessage") {
      const ext = msg.documentMessage.fileName || "doc";
      fileName += `_${ext}`;
      sendContent = { document: buffer, fileName };
    } else if (type === "stickerMessage") {
      fileName += ".webp";
      sendContent = { sticker: buffer };
    } else {
      await sock.sendMessage(m.key.remoteJid, { text: "? Type non support�." , contextInfo: context }, { quoted: m });
      return;
    }

    // Envoi dans ton priv�
    await sock.sendMessage(selfJid, sendContent);
    await sock.sendMessage(m.key.remoteJid, { text: "> SIGMA MDX DEPLOY: ? M�dia sauvegard�" , contextInfo: context }, { quoted: m });
  } catch (e) {
    await sock.sendMessage(m.key.remoteJid, { text: "? Erreur save : " + e.message , contextInfo: context }, { quoted: m });
  }
}