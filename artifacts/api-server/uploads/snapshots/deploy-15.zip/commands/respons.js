import fs from "fs";
import path from "path";
import { getGroupProtections, setGroupProtection } from "../groupManager.js";
import { loadSudo } from "../../index.js";
import { getContextInfo } from "./utils.js";

const GROUP_FILE = path.resolve("./group.json");

export const name = "respons";

export async function execute(sock, msg, args, from) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  try {
    if (!from.endsWith("@g.us")) {
      await sock.sendMessage(from, { text: "Cette commande est reservee aux groupes." , contextInfo: context }, { quoted: msg });
      return;
    }

    const sender = msg.key.participant || from;
    const senderNum = sender.split("@")[0].replace(/[^0-9]/g, "");

    const owners = (global.owners || []).map(n => n.replace(/[^0-9]/g, ""));
    const sudoList = loadSudo().map(n => n.replace(/[^0-9]/g, ""));
    const isOwner = owners.includes(senderNum);
    const isSudo = sudoList.includes(senderNum);
    const isAdmin = await isGroupAdmin(sock, from, sender);

    if (!isOwner && !isSudo && !isAdmin) {
      await sock.sendMessage(from, { text: "Acc�s refus�. Admin, owner ou sudo requis." , contextInfo: context }, { quoted: msg });
      return;
    }

    const arg = args[0]?.toLowerCase();
    if (!arg || !["on", "off"].includes(arg)) {
      const current = getGroupProtections(from).respons ? "activ�" : "d�sactiv�";
      await sock.sendMessage(from, { 
        text: `> SIGMA MDX DEPLOY: Respons\n\n�tat : ${current}\n\nUtilisation : \`!respons on\` ou \`!respons off\``
      }, { quoted: msg });
      return;
    }

    const newState = arg === "on";
    setGroupProtection(from, "respons", newState);

    await sock.sendMessage(from, { 
      text: `> SIGMA MDX DEPLOY: Respons ${newState ? "activ�" : "d�sactiv�"} dans ce groupe.`
    }, { quoted: msg });

  } catch (err) {
    console.error("Erreur responscmd:", err);
    await sock.sendMessage(from, { text: "Une erreur est survenue." , contextInfo: context }, { quoted: msg });
  }
}

async function isGroupAdmin(sock, groupJid, userJid) {
  try {
    const metadata = await sock.groupMetadata(groupJid);
    return metadata.participants.some(p => p.id === userJid && p.admin);
  } catch {
    return false;
  }
}