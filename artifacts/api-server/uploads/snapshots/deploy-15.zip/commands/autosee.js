import fs from "fs";
import path from "path";
import { getContextInfo } from "./utils.js";

export const name = "autosee";

const DEFAULT_EMOJIS = ["👀", "✨", "🔥", "🌙", "⚡", "💢", "🟢", "💎", "🫧", "🧿", "🤍", "🖤"];

const getConfigFile = (botContext) => {
  const sessionPath = botContext?.sessionPath;
  return sessionPath ? path.join(sessionPath, "autostatus.json") : "./autostatus.json";
};

const loadConfig = (file) => {
  if (!fs.existsSync(file)) return { autoSee: false, autoLike: false, emojis: DEFAULT_EMOJIS };
  try {
    const data = JSON.parse(fs.readFileSync(file, "utf-8"));
    return {
      autoSee: !!data?.autoSee,
      autoLike: !!data?.autoLike,
      emojis: Array.isArray(data?.emojis) && data.emojis.length ? data.emojis : DEFAULT_EMOJIS
    };
  } catch {
    return { autoSee: false, autoLike: false, emojis: DEFAULT_EMOJIS };
  }
};

const saveConfig = (file, cfg) => {
  const safe = {
    autoSee: !!cfg?.autoSee,
    autoLike: !!cfg?.autoLike,
    emojis: Array.isArray(cfg?.emojis) && cfg.emojis.length ? cfg.emojis : DEFAULT_EMOJIS
  };
  fs.writeFileSync(file, JSON.stringify(safe, null, 2));
};

export async function execute(sock, msg, args, from, botContext) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const chat = from || msg.key.remoteJid;
  const file = getConfigFile(botContext);
  const cfg = loadConfig(file);

  if (!args?.length) {
    const state = cfg.autoSee ? "ON" : "OFF";
    return await sock.sendMessage(chat, {
      text: `> Auto-See Statut: *${state}*\n\n> Usage: ${cfg.autoSee ? "autosee off" : "autosee on"}`
    }, { quoted: msg });
  }

  const arg = String(args[0] || "").toLowerCase();
  if (arg !== "on" && arg !== "off") {
    return await sock.sendMessage(chat, { text: "> Argument invalide. Utilise: autosee on | autosee off", contextInfo: context }, { quoted: msg });
  }

  cfg.autoSee = arg === "on";
  saveConfig(file, cfg);

  return await sock.sendMessage(chat, {
    text: `> ✅ Auto-See Statut: *${cfg.autoSee ? "ON" : "OFF"}*`
  }, { quoted: msg });
}
