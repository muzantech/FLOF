import telegramAuth from '../telegram-auth.js';

export const name = "connect";
export const description = "Connecter ton compte Telegram au bot";
export const category = "Utilitaire";

export async function execute(sock, msg, args, prefix = ".") {
  const senderJid = msg.key?.participant || msg.key?.remoteJid;
  const from = msg.key.remoteJid;

  try {
    // Vérifier si un code est fourni
    if (!args[0]) {
      await sock.sendMessage(from, {
        text: `🔐 *Connexion Telegram*\n\n` +
              `📲 Pour te connecter :\n` +
              `1. Va sur Telegram et cherche @TonBot\n` +
              `2. Envoie /start\n` +
              `3. Copie le code reçu\n` +
              `4. Envoie ici : \`${prefix}connect <code>\`\n\n` +
              `❓ Exemple : \`${prefix}connect ABC123\``
      }, { quoted: msg });
      return;
    }

    const code = args[0].toUpperCase().trim();

    // Vérifier le format du code (6 caractères alphanumériques)
    if (!/^[A-Z0-9]{6}$/.test(code)) {
      await sock.sendMessage(from, {
        text: `❌ *Code invalide*\n\n` +
              `Le code doit faire 6 caractères.\n` +
              `Exemple valide : \`ABC123\``
      }, { quoted: msg });
      return;
    }

    // Vérifier le code
    await sock.sendMessage(from, {
      text: `⏳ *Vérification du code...*`
    }, { quoted: msg });

    const result = telegramAuth.verifyCode(code, senderJid);

    if (result.success) {
      await sock.sendMessage(from, {
        text: `✅ *Connexion réussie !*\n\n` +
              `📱 Ton WhatsApp est maintenant lié à Telegram\n` +
              `👤 Utilisateur : ${result.username}\n\n` +
              `📢 Tu recevras maintenant des notifications sur Telegram !`
      }, { quoted: msg });
    } else {
      await sock.sendMessage(from, {
        text: `❌ *${result.error}*\n\n` +
              `Le code a peut-être expiré.\n` +
              `Demande un nouveau code sur Telegram.`
      }, { quoted: msg });
    }

  } catch (error) {
    console.error('Erreur connect:', error);
    await sock.sendMessage(from, {
      text: `❌ Une erreur s'est produite. Réessaie plus tard.`
    }, { quoted: msg });
  }
}
