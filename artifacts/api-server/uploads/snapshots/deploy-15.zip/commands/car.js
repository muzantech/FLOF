import { getContextInfo } from "./utils.js";

export const name = "car";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;
  try {
    if (!args.length) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Usage: .car <marque> <modele>\nEx: .car Toyota Corolla" , contextInfo: context }, { quoted: msg });
    }
    const query = args.join(" ");
    const url = `https://vpic.nhtsa.dot.gov/api/vehicles/getmodelsformake/${encodeURIComponent(args[0])}?format=json`;
    const res = await fetch(url);
    const data = await res.json();
    if (!data.Results?.length) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Marque non trouvee." , contextInfo: context }, { quoted: msg });
    }
    const models = data.Results.slice(0, 10);
    let reply = `> *SIGMA MDX - Cars*\n\nMarque: ${args[0]}\nModeles disponibles:\n\n`;
    models.forEach((m, i) => { reply += `${i+1}. ${m.Make_Name} ${m.Model_Name}\n`; });
    reply += `\nTotal modeles: ${data.Count}`;
    await sock.sendMessage(from, { text: reply , contextInfo: context }, { quoted: msg });
  } catch (err) {
    console.error("Erreur car:", err);
    await sock.sendMessage(from, { text: "> *SIGMA MDX* : Service voitures indisponible." , contextInfo: context }, { quoted: msg });
  }
}
