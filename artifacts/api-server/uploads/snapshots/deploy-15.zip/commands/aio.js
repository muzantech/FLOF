import axios from "axios";
import { getContextInfo } from "./utils.js";

export const name = "aio";
export const description = "All-in-one download from any platform";
export const category = "Download";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;
  
  const url = args[0]?.trim();
  if (!url) {
    return await sock.sendMessage(from, { 
      text: "> *SIGMA MDX* : Donne un lien vidéo/audio.\nEx: .aio https://www.youtube.com/watch?v=dQw4w9WgXcQ", 
      contextInfo: context 
    }, { quoted: msg });
  }

  try {
    await sock.sendMessage(from, { 
      text: "> *SIGMA MDX* : Analyse du lien... �", 
      contextInfo: context 
    }, { quoted: msg });

    // Utiliser l'API dlmp4 qui fonctionne mieux
    const apiUrl = `https://api.giftedtech.co.ke/api/download/dlmp4?apikey=gifted&url=${encodeURIComponent(url)}`;
    console.log("[AIO] Appel API:", apiUrl);
    
    const response = await axios.get(apiUrl, { 
      timeout: 120000,
      headers: {
        'Accept': 'application/json'
      }
    });
    
    console.log("[AIO] Réponse:", JSON.stringify(response.data, null, 2));
    
    const result = response.data?.result;
    
    if (result?.video || result?.audio || result?.download_url) {
      const title = result.title || "> *SIGMA MDX* - AIO Download";
      
      // Envoyer thumbnail si dispo
      if (result.thumbnail) {
        try {
          await sock.sendMessage(from, { 
            image: { url: result.thumbnail },
            caption: `> *SIGMA MDX - AIO*\n\nTitre: ${title}\nSource: ${url}`,
            contextInfo: context 
          }, { quoted: msg });
        } catch (e) {
          console.log("[AIO] Thumbnail failed:", e.message);
        }
      }
      
      // Send video if available
      if (result.video || result.download_url) {
        await sock.sendMessage(from, { 
          video: { url: result.video || result.download_url },
          caption: title,
          contextInfo: context 
        }, { quoted: msg });
      }
      
      // Send audio if available
      if (result.audio) {
        await sock.sendMessage(from, { 
          audio: { url: result.audio }, 
          mimetype: "audio/mpeg",
          contextInfo: context 
        }, { quoted: msg });
      }
    } else {
      console.log("[AIO] Aucun résultat dans:", response.data);
      await sock.sendMessage(from, { 
        text: "> *SIGMA MDX* : Impossible de télécharger. Format non supporté ou lien invalide.", 
        contextInfo: context 
      }, { quoted: msg });
    }
  } catch (err) {
    console.error("[AIO] Erreur:", err.message);
    console.error("[AIO] Stack:", err.stack);
    await sock.sendMessage(from, { 
      text: "> *SIGMA MDX* : Erreur lors du téléchargement: " + (err.message || "Timeout"), 
      contextInfo: context 
    }, { quoted: msg });
  }
}
