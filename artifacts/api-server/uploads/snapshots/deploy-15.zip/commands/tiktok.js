import axios from "axios";
import { getContextInfo } from "./utils.js";

export const name = "tiktok";

const TIKTOK_APIS = [
  {
    name: "siputzx",
    download: async (url) => {
      const res = await axios.get(`https://api.siputzx.my.id/api/d/tiktok?url=${encodeURIComponent(url)}`, { timeout: 25000 });
      const d = res.data?.data;
      if (!d) return null;
      return { video: d.play || d.dl, title: d.title, author: d.author?.nickname || d.author };
    }
  },
  {
    name: "bk9",
    download: async (url) => {
      const res = await axios.get(`https://bk9.fun/download/tiktok?url=${encodeURIComponent(url)}`, { timeout: 25000 });
      const d = res.data?.BK9;
      if (!d) return null;
      return { video: d.downloadUrl || d.url, title: d.title, author: d.author };
    }
  },
  {
    name: "gifted",
    download: async (url) => {
      const res = await axios.get(`https://api.giftedtech.co.ke/api/download/tiktok?apikey=gifted&url=${encodeURIComponent(url)}`, { timeout: 25000 });
      const d = res.data?.result;
      if (!d) return null;
      return { video: d.download_url || d.video, title: d.title, author: d.author };
    }
  }
];

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;

  try {
    const tiktokUrl = args.join(" ").trim();

    if (!tiktokUrl) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Fournis un lien TikTok.\nEx: .tiktok https://www.tiktok.com/@user/video/123"
, contextInfo: context }, { quoted: msg });
    }

    if (!tiktokUrl.includes("tiktok.com")) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Lien TikTok invalide."
, contextInfo: context }, { quoted: msg });
    }

    await sock.sendMessage(from, { text: "> *SIGMA MDX* : Telechargement TikTok en cours..."
, contextInfo: context }, { quoted: msg });

    let result = null;
    for (const api of TIKTOK_APIS) {
      try {
        result = await api.download(tiktokUrl);
        if (result?.video) break;
        result = null;
      } catch (e) {
        console.log(`TikTok ${api.name} failed:`, e.message);
      }
    }

    if (!result?.video) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Echec du telechargement. APIs indisponibles."
, contextInfo: context }, { quoted: msg });
    }

    const caption = `> *SIGMA MDX - TikTok*\n\nAuteur: ${result.author || "N/A"}\nTitre: ${result.title || "N/A"}`;

    await sock.sendMessage(from, {
      video: { url: result.video },
      caption
    }, { quoted: msg });

  } catch (err) {
    console.error("Erreur TikTok:", err);
    await sock.sendMessage(from, {
      text: `> *SIGMA MDX* : Erreur TikTok.\n${err.message}`
    }, { quoted: msg });
  }
}
