# Dossier Commands

Mettre ici les commandes de base (.js).

Exemple de structure d'une commande:
```javascript
export default {
  name: "ping",
  category: "general",
  execute: async (sock, msg, args, from, botContext) => {
    await sock.sendMessage(from, { text: "Pong!" }, { quoted: msg });
  }
};
```

Les commandes sont chargées automatiquement au démarrage.
