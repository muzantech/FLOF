import { getContextInfo } from "./utils.js";

export const name = "delete";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    if (!msg.message?.extendedTextMessage?.contextInfo?.stanzaId) {
      return await sock.sendMessage(msg.key.remoteJid, { text: "> SIGMA MDX DEPLOY : R�ponds au message � supprimer." , contextInfo: context }, { quoted: msg });
    }

    await sock.sendMessage(msg.key.remoteJid, {
      delete: {
        remoteJid: msg.key.remoteJid,
        fromMe: false,
        id: msg.message.extendedTextMessage.contextInfo.stanzaId,
        participant: msg.message.extendedTextMessage.contextInfo.participant
      }
    });

  } catch (err) {
    console.error(" Erreur delete :", err);
  }
}