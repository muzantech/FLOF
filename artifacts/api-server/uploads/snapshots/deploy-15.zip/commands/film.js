export const name = "film";

import { getContextInfo } from "./utils.js";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;
  try {
    if (!args.length) {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Usage: .film <titre>\nEx: .film Inception" , contextInfo: context }, { quoted: msg });
    }
    const search = args.join(" ");
    const url = `https://www.omdbapi.com/?t=${encodeURIComponent(search)}&apikey=trilogy&plot=short`;
    const response = await fetch(url);
    const data = await response.json();
    if (data.Response === "False") {
      return await sock.sendMessage(from, { text: "> *SIGMA MDX* : Film non trouve." , contextInfo: context }, { quoted: msg });
    }
    const reply = `> *SIGMA MDX - Film*\n\nTitre: ${data.Title}\nAnnee: ${data.Year}\nGenre: ${data.Genre}\nDuree: ${data.Runtime}\nRealisateur: ${data.Director}\nActeurs: ${data.Actors}\nNote: ${data.imdbRating}/10\nSynopsis: ${data.Plot}\n\nhttps://www.imdb.com/title/${data.imdbID}`;
    if (data.Poster && data.Poster !== "N/A") {
      await sock.sendMessage(from, { image: { url: data.Poster }, caption: reply , contextInfo: context }, { quoted: msg });
    } else {
      await sock.sendMessage(from, { text: reply , contextInfo: context }, { quoted: msg });
    }
  } catch (err) {
    console.error("Erreur film:", err);
    await sock.sendMessage(from, { text: "> *SIGMA MDX* : Service films indisponible." , contextInfo: context }, { quoted: msg });
  }
}
