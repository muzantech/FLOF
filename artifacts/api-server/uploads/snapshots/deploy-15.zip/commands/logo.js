export const name = "logo";
export const description = "Generate a company logo";
export const category = "Creation";
import { getContextInfo } from "./utils.js";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    const from = msg.key.remoteJid;
    
    if (!args.length) {
      return await sock.sendMessage(from, { 
        text: `⚡ *SIGMA MDX DEPLOY Logo Generator*\n\n` +
              `Usage: .logo <company_name> <slogan?>\n\n` +
              `Examples:\n` +
              `.logo TechCorp\n` +
              `.logo "Baker DuPont" "Traditional bread"\n` +
              `.logo BlackCoffee "The art of coffee"\n\n` +
              `⚡ Available styles:\n` +
              `- Modern\n` +
              `- Vintage\n` +
              `- Minimalist\n` +
              `- Luxury`,
        contextInfo: context 
      }, { quoted: msg });
    }
    
    const companyName = args[0];
    const slogan = args.slice(1).join(" ") || "Your slogan here";
    
    // Send processing message
    const processingMsg = await sock.sendMessage(from, { 
      text: "⚡ *SIGMA MDX DEPLOY* - Creating logo...",
      contextInfo: context 
    }, { quoted: msg });
    
    // Using placeholder API for logo generation
    const logoUrl = `https://placehold.co/400x200/1a1a1a/ffffff?text=${encodeURIComponent(companyName.toUpperCase())}&font=montserrat`;
    
    // Alternative: DummyImage API
    // const logoUrl = `https://dummyimage.com/400x200/000/fff&text=${encodeURIComponent(companyName)}`;
    
    // Send the generated logo
    await sock.sendMessage(from, { 
      image: { url: logoUrl }, 
      caption: `⚡ *SIGMA MDX DEPLOY Logo Generator*\n\n` +
               `⚡ Company: ${companyName}\n` +
               `⚡ Slogan: ${slogan}\n` +
               `⚡ Style: Modern\n` +
               `⚡ Usage: Commercial\n` +
               `⚡ Dimensions: 400x200px\n` +
               `⚡ Palette: Black & White\n\n` +
               `⚡ Tip: For a custom logo, contact a professional designer.`,
      contextInfo: context
    }, { quoted: processingMsg });
    
  } catch (err) {
    console.error("❌ Logo command error:", err);
    await sock.sendMessage(msg.key.remoteJid, { 
      text: "❌ *SIGMA MDX DEPLOY*: Logo service unavailable\n" +
            "Please try again later",
      contextInfo: context 
    }, { quoted: msg });
  }
}