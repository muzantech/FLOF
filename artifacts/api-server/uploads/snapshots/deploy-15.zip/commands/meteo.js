import axios from "axios";
import { getContextInfo } from "./utils.js";

export const name = "meteo";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    const from = msg.key.remoteJid;
    const city = args.join(" ");

    if (!city) {
      await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY:✅ Utilisation : meteo <ville>" , contextInfo: context }, { quoted: msg });
      return;
    }

    const apiKey = "4902c0f2550f58298ad4146a92b65e10"; // Remplace par ta cl� OpenWeather
    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${apiKey}&units=metric&lang=fr`
    );

    const weather = response.data;
    const weatherText = `> +--------METEO--------+
> > *Meteo a ${weather.name}* >
> -------------------
> > *Conditions* : ${weather.weather[0].description}
> > *Temperature* : ${weather.main.temp}C >
> > *Ressenti* : ${weather.main.feels_like}C >
> > *Humidite* : ${weather.main.humidity}% >
> > *Vent* : ${weather.wind.speed} m/s >
> > *Pression* : ${weather.main.pressure} hPa >
> -------------------
> ❌ Derniere mise a jour : ${new Date(weather.dt * 1000).toLocaleTimeString("fr-FR")}
> +-----------------+`;

    await sock.sendMessage(from, { text: weatherText , contextInfo: context }, { quoted: msg });

  } catch (error) {
    console.error("❌ Erreur meteo :", error);
    await sock.sendMessage(msg.key.remoteJid, { text: "> SIGMA MDX DEPLOY:> Desole, je n'ai pas pu recuperer la meteo pour cette ville." , contextInfo: context }, { quoted: msg });
  }
}