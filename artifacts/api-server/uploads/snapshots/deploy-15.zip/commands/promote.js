import { getContextInfo } from "./utils.js";

export const name = "promote";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  try {

    const from = msg.key.remoteJid;

    // R�cup�re les JID mentionn�s

    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;

    // R�cup�re le JID si la commande est en r�ponse � un message

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.participant;

    // On choisit : mention ou r�ponse

    const target = mentioned && mentioned.length > 0 ? mentioned[0] : quoted;

    if (!target) {

      return await sock.sendMessage(

        from,

        { text: "> SIGMA MDX DEPLOY:_ Mentionne ou r�pond au message de la personne � promouvoir." },

        { quoted: msg }

      );

    }

    // Promotion

    await sock.groupParticipantsUpdate(from, [target], "promote");

    await sock.sendMessage(from, {

      text: `> SIGMA MDX DEPLOY : ? @${target.split("@")[0]} est maintenant admin.`,

      mentions: [target],

    });

  } catch (err) {

    console.error("? Erreur promote :", err);

    await sock.sendMessage(msg.key.remoteJid, { text: "> SIGMA MDX DEPLOY: ? Une erreur est survenue." , contextInfo: context }, { quoted: msg });

  }

}