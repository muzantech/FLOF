// commands/antimessage.js
import fs from "fs";
import path from "path";
import { getGroupProtections, setGroupProtection } from "../groupManager.js";
import { loadSudo } from "../../index.js";
import { getContextInfo } from "./utils.js";

const GROUP_FILE = path.resolve("./group.json");

export const name = "antimessage";

export async function execute(sock, msg, args, from) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  try {
    // === GROUPE UNIQUEMENT ===
    if (!from.endsWith("@g.us")) {
      await sock.sendMessage(from, { text: "Cette commande est r�serv�e aux groupes." , contextInfo: context }, { quoted: msg });
      return;
    }

    // === R�CUP�RER L'EXP�DITEUR ===
    const sender = msg.key.participant || from;
    const senderNum = sender.split("@")[0].replace(/[^0-9]/g, "");

    // === V�RIFICATION DES DROITS ===
    const owners = (global.owners || []).map(n => n.replace(/[^0-9]/g, ""));
    const sudoList = loadSudo().map(n => n.replace(/[^0-9]/g, ""));

    const isOwner = owners.includes(senderNum);
    const isSudo = sudoList.includes(senderNum);
    const isAdmin = await isGroupAdmin(sock, from, sender); // Assure-toi que cette fonction existe

    if (!isOwner && !isSudo && !isAdmin) {
      await sock.sendMessage(from, { text: "Acc�s refus�. Admin, owner ou sudo requis." , contextInfo: context }, { quoted: msg });
      return;
    }

    // === ARGUMENT ===
    const arg = args[0]?.toLowerCase();

    if (!arg || !["on", "off"].includes(arg)) {
      const current = getGroupProtections(from).antiMessage ? "activ�" : "d�sactiv�";
      await sock.sendMessage(from, { 
        text: `> SIGMA MDX DEPLOY: Anti-Message\n\n�tat : ${current}\n\nUtilisation : \`!antimessage on\` ou \`!antimessage off\``
      }, { quoted: msg });
      return;
    }

    // === MISE � JOUR ===
    const newState = arg === "on";
    setGroupProtection(from, "antiMessage", newState);

    await sock.sendMessage(from, { 
      text: `> SIGMA MDX DEPLOY:Anti-Message ${newState ? "activ�" : "d�sactiv�"} dans ce groupe.*`
    }, { quoted: msg });

  } catch (err) {
    console.error("Erreur antimessage:", err);
    await sock.sendMessage(from, { text: "Une erreur est survenue." , contextInfo: context }, { quoted: msg });
  }
}

// === Utilitaire isGroupAdmin (si pas d�j� dans index.js) ===
async function isGroupAdmin(sock, groupJid, userJid) {
  try {
    const metadata = await sock.groupMetadata(groupJid);
    return metadata.participants.some(p => p.id === userJid && p.admin);
  } catch {
    return false;
  }
}