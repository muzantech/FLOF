export const name = "revoke";

import { getContextInfo } from "./utils.js";

export async function execute(sock, msg, args, from) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  if (!from.endsWith("@g.us")) {
    return await sock.sendMessage(from, { text: "❌ Cette commande ne fonctionne que dans un groupe." , contextInfo: context }, { quoted: msg });
  }
  try {
    const meta = await sock.groupMetadata(from);
    const sender = msg.key.participant || from;
    const isAdmin = meta.participants.find(p => p.id === sender)?.admin;
    if (!isAdmin) {
      return await sock.sendMessage(from, { text: "❌ Seuls les admins peuvent révoquer le lien." , contextInfo: context }, { quoted: msg });
    }
    await sock.groupRevokeInvite(from);
    await sock.sendMessage(from, { text: "⛔ Lien d’invitation du groupe révoqué (nouveau lien généré)." , contextInfo: context }, { quoted: msg });
  } catch (e) {
    console.error("Erreur revoke:", e);
    await sock.sendMessage(from, { text: "❌ Impossible de révoquer le lien." , contextInfo: context }, { quoted: msg });
  }
}
