export const name = "add";

export const description = "Ajoute une personne dans le groupe";

export const usage = "!add <numéro>";

import { getContextInfo } from "./utils.js";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;

  try {

    // Vérifie si c'est un groupe

    if (!from.endsWith("@g.us")) {

      await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : ?? Cette commande ne fonctionne que dans un groupe." });

      return;

    }

    // V�rifie si un num�ro est donn�

    if (!args[0]) {

      await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY ?? Utilisation : !add <num�ro>" });

      return;

    }

    // Nettoyage du num�ro

    let number = args[0].replace(/[^0-9]/g, ""); // garde seulement les chiffres

    if (!number) {

      await sock.sendMessage(from, { text: "? Num�ro invalide." });

      return;

    }

    if (!number.endsWith("@s.whatsapp.net")) {

      number = number + "@s.whatsapp.net";

    }

    // Ajout au groupe

    await sock.groupParticipantsUpdate(from, [number], "add");

    await sock.sendMessage(from, {

      text: `> SIGMA MDX DEPLOY: ? L'utilisateur ${args[0]} a �t� ajout� au groupe.`

    });

  } catch (e) {

    console.error("[ADD] Erreur :", e);

    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY:? Impossible d'ajouter ce num�ro. V�rifie que :\n- Le num�ro existe\n- Il a WhatsApp\n- Le bot est admin du groupe" });

  }

}