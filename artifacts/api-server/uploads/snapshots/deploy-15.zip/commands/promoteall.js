import dotenv from "dotenv";
import { getContextInfo } from "./utils.js";
dotenv.config();

export const name = "promoteall";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  const from = msg.key.remoteJid;

  // Verifie si c'est un groupe
  if (!from.endsWith("@g.us")) {
    return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: ⚙️ Commande reservee aux groupes seulement.", contextInfo: context }, { quoted: msg });
  }

  try {
    const groupMetadata = await sock.groupMetadata(from);
    const participants = groupMetadata.participants || [];

    // --- JIDs essentiels ---
    const botJid =
      (sock?.user?.id?.split?.(":")?.[0] || sock?.user?.jid?.split?.(":")?.[0] || "") +
      "@s.whatsapp.net";

    const OWNER_NUMBER = process.env.NUMBER?.replace(/\D/g, "");
    const OWNER_JID = OWNER_NUMBER ? `${OWNER_NUMBER}@s.whatsapp.net` : null;

    const sender = msg.key.participant || msg.participant || from;

    if (!OWNER_JID) {
      console.error("⚡ Le numero du proprietaire (NUMBER) n'est pas defini dans .env !");
      return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: > Le numero du proprietaire n'est pas configure.", contextInfo: context }, { quoted: msg });
    }

    // --- Fonction utilitaire pour verifier si admin ---
    const isAdmin = p => {
      const adminFlag = p?.admin || p?.isAdmin || p?.isSuperAdmin;
      return adminFlag === true || adminFlag === "admin" || adminFlag === "superadmin";
    };

    // --- Liste des membres a promouvoir (exclure bot, owner et auteur deja admin) ---
    const toPromote = participants
      .filter(p => {
        const jid = p?.id || p?.jid || p?.participant;
        if (!jid) return false;
        return !isAdmin(p) && jid !== botJid && jid !== OWNER_JID;
      })
      .map(p => p.id);

    if (toPromote.length === 0) {
      return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: ✅ Tous les membres sont deja administrateurs", contextInfo: context }, { quoted: msg });
    }

    // --- Promotion des membres ---
    await sock.groupParticipantsUpdate(from, toPromote, "promote");

    await sock.sendMessage(from, {
      text: `⚡ *${toPromote.length} membre(s) promu(s) administrateur(s).* (Bot et proprietaire exclus)`,
      mentions: toPromote
    }, { quoted: msg });

  } catch (err) {
    console.error("❌ Erreur promoteall :", err);
    await sock.sendMessage(from, { text: "❌ *Erreur lors de l'execution de promoteall.* Verifie mes permissions ou reessaye.", contextInfo: context }, { quoted: msg });
  }
}
