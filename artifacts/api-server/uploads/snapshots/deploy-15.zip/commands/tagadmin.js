import { getContextInfo } from "./utils.js";

export const name = "tagadmin";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  try {

    const groupMetadata = await sock.groupMetadata(msg.key.remoteJid);

    const admins = groupMetadata.participants.filter(p => p.admin);

    if (admins.length === 0) {

      return await sock.sendMessage(msg.key.remoteJid, { text: "Aucun admin trouve dans ce groupe." });

    }

    const mentions = admins.map(a => a.id);

    const text = admins.map(a => `> @${a.id.split("@")[0]}`).join("\n");

    await sock.sendMessage(msg.key.remoteJid, { image: { url: "https://files.catbox.moe/lhpf7b.jpg" }, caption: "> TAGADMIN\n\n" + text,

      mentions

    , contextInfo: context });

  } catch (err) {

    console.error("Erreur tagadmin :", err);

  }

}