import { getContextInfo } from "./utils.js";

export const name = "gclink";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);
  try {
    const from = msg.key.remoteJid;

    // Verifie que c'est bien un groupe
    if (!from.endsWith("@g.us")) {
      return await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY: Commande pour groupe " , contextInfo: context }, { quoted: msg });
    }

    // Recupere le lien d'invitation
    const groupInviteCode = await sock.groupInviteCode(from);
    const inviteLink = `https://chat.whatsapp.com/${groupInviteCode}`;

    await sock.sendMessage(from, { text: `> SIGMA MDX DEPLOY: 🔗 Lien du groupe :\n${inviteLink}` }, { quoted: msg });

  } catch (err) {
    console.error("Erreur link :", err);
    await sock.sendMessage(msg.key.remoteJid, { text: "> SIGMA MDX DEPLOY: Erreur lors de la recuperation du lien." , contextInfo: context }, { quoted: msg });
  }
}