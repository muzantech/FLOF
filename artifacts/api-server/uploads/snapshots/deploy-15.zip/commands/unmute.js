export const name = "unmute";
import { getContextInfo } from "./utils.js";

export async function execute(sock, msg, args) {
  const senderJid = msg.key?.participant || msg.key?.remoteJid || sock.user?.id;
  const context = getContextInfo(senderJid);

  const from = msg.key.remoteJid;

  // V�rifier si c'est un groupe

  if (!from.endsWith("@g.us")) {

    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Commande utilis�e pour les groupes." , contextInfo: context }, { quoted: msg });

    return;

  }

  try {

    // Mettre le groupe en mode "ouvert" (tout le monde peut envoyer)

    await sock.groupSettingUpdate(from, "not_announcement"); // "not_announcement" = tout le monde peut envoyer

    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Groupe ouvert !" , contextInfo: context }, { quoted: msg });

  } catch (err) {

    console.error("Erreur lors de l'ouverture du groupe :", err);

    await sock.sendMessage(from, { text: "> SIGMA MDX DEPLOY : Impossible d'ouvrir le groupe. Assurez-vous que vous �tes admin." , contextInfo: context }, { quoted: msg });

  }

}