# 🔐 Système de Connexion Telegram pour SIGMA MDX

Les utilisateurs peuvent connecter leur compte WhatsApp au bot via Telegram pour recevoir des notifications et gérer leur compte à distance.

---

## 📱 Comment ça marche

```
┌─────────────────┐      ┌───────────────────┐      ┌─────────────────┐
│   Utilisateur   │─────▶│  Bot Telegram    │─────▶│   Code généré   │
│   (Telegram)    │      │  (/start)        │      │   (6 caractères)│
└─────────────────┘      └───────────────────┘      └─────────────────┘
                                                           │
                                                           ▼
┌─────────────────┐      ┌───────────────────┐      ┌─────────────────┐
│   Connecté !    │◀─────│  Bot WhatsApp    │◀─────│  .connect ABC123│
│  (Notifications)│      │  (Vérification)  │      │   (WhatsApp)    │
└─────────────────┘      └───────────────────┘      └─────────────────┘
```

---

## 🚀 Installation

### 1. Créer un bot Telegram

1. Va sur [@BotFather](https://t.me/BotFather)
2. Envoie `/newbot`
3. Donne un nom (ex: "SIGMA MDX Auth")
4. Donne un username (ex: `sigma_mdx_auth_bot`)
5. **Copie le token** (ex: `123456789:ABCdefGHI...`)

### 2. Configurer

```bash
node setup-telegram.js TON_TOKEN_ICI
```

### 3. Démarrer

```bash
npm start
```

---

## 👤 Pour les utilisateurs

### Se connecter

1. **Sur Telegram** : Cherche ton bot et envoie `/start`
2. **Copie le code** affiché (ex: `ABC123`)
3. **Sur WhatsApp** : Envoie `.connect ABC123` au bot
4. ✅ **Connecté !**

### Voir le statut

- **Sur Telegram** : Envoie `/status`
- **Sur WhatsApp** : Le bot confirme la connexion

### Se déconnecter

- **Sur Telegram** : Envoie `/disconnect`

---

## 📋 Commandes disponibles

### Telegram
| Commande | Description |
|----------|-------------|
| `/start` | Obtenir un code de connexion |
| `/status` | Voir si connecté |
| `/disconnect` | Déconnecter le compte |

### WhatsApp
| Commande | Description |
|----------|-------------|
| `.connect` | Voir l'aide |
| `.connect <code>` | Connecter avec un code |

---

## 🔧 Intégration dans bot.js

Ajoute ceci dans `bot.js` pour démarrer le système :

```javascript
import telegramAuth from './telegram-auth.js';

// Au démarrage
if (telegramAuth.config.enabled) {
  await telegramAuth.start();
}

// Quand le socket WhatsApp est prêt
telegramAuth.setWhatsAppSock(sock);
```

---

## 📁 Fichiers créés

| Fichier | Description |
|---------|-------------|
| `telegram-auth.js` | ⭐ Système d'authentification |
| `telegram-config.json` | Configuration (token) |
| `telegram-links.json` | Liens Telegram↔WhatsApp |
| `telegram-codes.json` | Codes temporaires |
| `commands/connect.js` | Commande WhatsApp `.connect` |

---

## 🔐 Sécurité

- Les codes expirent après **10 minutes**
- Un seul compte WhatsApp par Telegram
- Les codes sont aléatoires (6 caractères alphanumériques)
- Les données sont stockées localement en JSON

---

## 🔔 Notifications

Une fois connecté, tu peux envoyer des notifications depuis le bot :

```javascript
import telegramAuth from './telegram-auth.js';

// Envoyer à un utilisateur par son JID WhatsApp
await telegramAuth.notifyByWhatsApp(
  '32491942744@s.whatsapp.net', 
  '📢 Tu as reçu un nouveau message !'
);
```

---

## 🆘 Dépannage

### ❌ "Code invalide ou expiré"
→ Le code a expiré (10 min). Demande un nouveau sur Telegram avec `/start`

### ❌ "Token manquant"
→ Vérifie que `telegram-config.json` existe avec le token

### ❌ Bot Telegram ne répond pas
→ Vérifie que `node-telegram-bot-api` est installé :
```bash
npm install node-telegram-bot-api
```

---

## 💡 Exemples d'utilisation

**Notifier quand quelqu'un utilise une commande :**
```javascript
// Dans une commande
await telegramAuth.notifyByWhatsApp(
  senderJid,
  `✅ Commande ${name} exécutée avec succès !`
);
```

**Envoyer un récap quotidien :**
```javascript
// Dans une tâche planifiée
for (const [tgId, data] of Object.entries(telegramAuth.links)) {
  await telegramAuth.bot.sendMessage(
    tgId, 
    '📊 Récap du jour : 50 messages reçus'
  );
}
```

---

**SIGMA MDX © 2024 - Connexion Telegram v1.0**
