import TelegramBot from 'node-telegram-bot-api';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const CONFIG_FILE = join(__dirname, 'telegram-config.json');
const LINKS_FILE = join(__dirname, 'telegram-links.json');
const CODES_FILE = join(__dirname, 'telegram-codes.json');

function loadJson(file, defaultVal = {}) {
  if (existsSync(file)) return JSON.parse(readFileSync(file, 'utf8'));
  return defaultVal;
}

function saveJson(file, data) {
  writeFileSync(file, JSON.stringify(data, null, 2));
}

class TelegramAuthSystem {
  constructor() {
    this.config = loadJson(CONFIG_FILE, { enabled: false, botToken: '' });
    this.links = loadJson(LINKS_FILE, {}); // { telegramId: { whatsappJid, username, linkedAt } }
    this.pendingCodes = loadJson(CODES_FILE, {}); // { code: { telegramId, username, createdAt } }
    this.bot = null;
    this.whatsappSock = null;
  }

  async start(token) {
    if (!token && !this.config.botToken) {
      console.log('❌ Token Telegram manquant');
      return false;
    }

    const botToken = token || this.config.botToken;

    try {
      this.bot = new TelegramBot(botToken, { polling: true });
      this.config.botToken = botToken;
      this.config.enabled = true;
      saveJson(CONFIG_FILE, this.config);

      this.setupHandlers();
      console.log('✅ Système de connexion Telegram démarré');
      return true;
    } catch (err) {
      console.error('❌ Erreur:', err.message);
      return false;
    }
  }

  setupHandlers() {
    // /start - Afficher le code de connexion
    this.bot.onText(/\/start/, (msg) => {
      const chatId = msg.chat.id;
      const telegramId = msg.from.id;
      const username = msg.from.username || msg.from.first_name;

      // Vérifier si déjà lié
      if (this.links[telegramId]) {
        const link = this.links[telegramId];
        this.bot.sendMessage(chatId, 
          `✅ *Déjà connecté !*\n\n` +
          `📱 WhatsApp : \`${link.whatsappJid}\`\n` +
          `🔗 Lié le : ${new Date(link.linkedAt).toLocaleDateString()}`,
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Générer un code de connexion
      const code = this.generateCode();
      this.pendingCodes[code] = {
        telegramId,
        username,
        createdAt: Date.now()
      };
      saveJson(CODES_FILE, this.pendingCodes);

      // Expirer le code après 10 minutes
      setTimeout(() => {
        if (this.pendingCodes[code]) {
          delete this.pendingCodes[code];
          saveJson(CODES_FILE, this.pendingCodes);
        }
      }, 10 * 60 * 1000);

      const message = `
🤖 *SIGMA MDX - Connexion*

Ton code de connexion :

\`${code}\`

⏳ *Valide 10 minutes*

📲 *Comment te connecter :*
1. Ouvre WhatsApp
2. Envoie ce code au bot :
   \`.connect ${code}\`

❓ Besoin d'aide ? Contacte le support.
      `;

      this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    });

    // /status - Voir le statut
    this.bot.onText(/\/status/, (msg) => {
      const chatId = msg.chat.id;
      const telegramId = msg.from.id;

      if (this.links[telegramId]) {
        const link = this.links[telegramId];
        this.bot.sendMessage(chatId,
          `✅ *Connecté*\n📱 \`${link.whatsappJid}\``,
          { parse_mode: 'Markdown' }
        );
      } else {
        this.bot.sendMessage(chatId, '❌ *Non connecté*\n\nEnvoie /start pour obtenir un code.');
      }
    });

    // /disconnect - Déconnecter
    this.bot.onText(/\/disconnect/, (msg) => {
      const chatId = msg.chat.id;
      const telegramId = msg.from.id;

      if (this.links[telegramId]) {
        delete this.links[telegramId];
        saveJson(LINKS_FILE, this.links);
        this.bot.sendMessage(chatId, '✅ *Déconnecté avec succès*');
      } else {
        this.bot.sendMessage(chatId, '❌ Tu n\'es pas connecté.');
      }
    });

    // Gestion erreurs
    this.bot.on('polling_error', (err) => {
      console.error('Telegram error:', err.message);
    });
  }

  generateCode() {
    // Générer code aléatoire 6 caractères
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  // Vérifier et valider un code de connexion
  verifyCode(code, whatsappJid) {
    const pending = this.pendingCodes[code];
    if (!pending) return { success: false, error: 'Code invalide ou expiré' };

    // Lier les comptes
    this.links[pending.telegramId] = {
      whatsappJid,
      username: pending.username,
      linkedAt: Date.now()
    };
    saveJson(LINKS_FILE, this.links);

    // Supprimer le code utilisé
    delete this.pendingCodes[code];
    saveJson(CODES_FILE, this.pendingCodes);

    // Notifier sur Telegram
    this.bot.sendMessage(pending.telegramId,
      `✅ *Connexion réussie !*\n\n` +
      `Ton compte Telegram est maintenant lié à :\n` +
      `📱 \`${whatsappJid}\``,
      { parse_mode: 'Markdown' }
    );

    return { 
      success: true, 
      telegramId: pending.telegramId,
      username: pending.username 
    };
  }

  // Vérifier si un JID WhatsApp est lié
  getTelegramByWhatsApp(whatsappJid) {
    for (const [tgId, data] of Object.entries(this.links)) {
      if (data.whatsappJid === whatsappJid) {
        return { telegramId: tgId, ...data };
      }
    }
    return null;
  }

  // Envoyer message à un utilisateur par son JID WhatsApp
  async notifyByWhatsApp(whatsappJid, message) {
    const link = this.getTelegramByWhatsApp(whatsappJid);
    if (link && this.bot) {
      await this.bot.sendMessage(link.telegramId, message, { parse_mode: 'Markdown' });
      return true;
    }
    return false;
  }

  setWhatsAppSock(sock) {
    this.whatsappSock = sock;
  }

  stop() {
    if (this.bot) {
      this.bot.stopPolling();
    }
  }
}

const telegramAuth = new TelegramAuthSystem();
export default telegramAuth;
export { telegramAuth };
