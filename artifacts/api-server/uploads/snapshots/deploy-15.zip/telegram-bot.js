import TelegramBot from 'node-telegram-bot-api';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Fichier de config Telegram
const CONFIG_FILE = join(__dirname, 'telegram-config.json');

// Charger ou créer config
function loadConfig() {
  if (existsSync(CONFIG_FILE)) {
    return JSON.parse(readFileSync(CONFIG_FILE, 'utf8'));
  }
  return {
    enabled: false,
    botToken: '',
    allowedUsers: [], // IDs Telegram autorisés
    ownerId: null,
    connected: false
  };
}

function saveConfig(config) {
  writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

class TelegramController {
  constructor() {
    this.config = loadConfig();
    this.bot = null;
    this.whatsappSock = null;
    this.isConnected = false;
  }

  // Démarrer le bot Telegram
  async start(token) {
    if (!token) {
      console.log('❌ Token Telegram manquant');
      return false;
    }

    try {
      this.bot = new TelegramBot(token, { polling: true });
      this.config.botToken = token;
      this.config.enabled = true;
      saveConfig(this.config);

      this.setupHandlers();
      
      console.log('✅ Bot Telegram démarré');
      console.log('📱 Envoie /start à ton bot Telegram pour commencer');
      return true;
    } catch (err) {
      console.error('❌ Erreur démarrage Telegram:', err.message);
      return false;
    }
  }

  // Configurer les handlers
  setupHandlers() {
    // Commande /start
    this.bot.onText(/\/start/, (msg) => {
      const chatId = msg.chat.id;
      const userId = msg.from.id;
      
      if (!this.isAuthorized(userId)) {
        this.bot.sendMessage(chatId, '⛔ Tu n\'es pas autorisé à utiliser ce bot.');
        return;
      }

      const welcomeMsg = `
🤖 *SIGMA MDX - Telegram Controller*

Bienvenue ! Je suis le système de contrôle distant de ton bot WhatsApp.

📋 *Commandes disponibles :*

/status - Voir l'état du bot WhatsApp
/restart - Redémarrer le bot WhatsApp
/stop - Arrêter le bot WhatsApp
/cmd <commande> - Exécuter une commande WhatsApp
/msg <numéro> <message> - Envoyer un message WhatsApp
/broadcast <message> - Envoyer un message à tous les groupes
/groups - Liste des groupes WhatsApp
/info - Infos sur le bot

📝 *Exemples :*
/cmd .menu
/msg 32491942744 Salut !

⚠️ *Note :* Le bot doit être connecté à WhatsApp.
      `;

      this.bot.sendMessage(chatId, welcomeMsg, { parse_mode: 'Markdown' });
    });

    // /status - Statut du bot
    this.bot.onText(/\/status/, (msg) => {
      if (!this.checkAuth(msg)) return;
      
      const status = this.whatsappSock?.user ? 
        `✅ *Connecté*\n👤 ${this.whatsappSock.user.name || this.whatsappSock.user.id}` : 
        '❌ *Déconnecté*';
      
      this.bot.sendMessage(msg.chat.id, `📊 *Statut WhatsApp :*\n${status}`, { parse_mode: 'Markdown' });
    });

    // /info - Infos
    this.bot.onText(/\/info/, (msg) => {
      if (!this.checkAuth(msg)) return;
      
      const info = `
🤖 *SIGMA MDX Bot Info*

📱 Version : 3.0
🔄 Mode : Standalone
🌐 Status : ${this.whatsappSock?.user ? 'Connecté' : 'Déconnecté'}
⏱️ Uptime : ${process.uptime().toFixed(0)}s

🔗 *Liens :*
Canal : https://whatsapp.com/channel/0029VbBIAP58KMqoJluW8r06
      `;
      
      this.bot.sendMessage(msg.chat.id, info, { parse_mode: 'Markdown' });
    });

    // /cmd - Exécuter commande WhatsApp
    this.bot.onText(/\/cmd (.+)/, async (msg, match) => {
      if (!this.checkAuth(msg)) return;
      
      const command = match[1];
      const chatId = msg.chat.id;
      
      if (!this.whatsappSock?.user) {
        this.bot.sendMessage(chatId, '❌ Bot WhatsApp non connecté');
        return;
      }

      this.bot.sendMessage(chatId, `⏳ Exécution de : ${command}`);
      
      // Stocker la réponse à envoyer
      this.pendingCommand = {
        chatId: chatId,
        command: command
      };
    });

    // /msg - Envoyer message WhatsApp
    this.bot.onText(/\/msg (\d+) (.+)/, async (msg, match) => {
      if (!this.checkAuth(msg)) return;
      
      const number = match[1];
      const message = match[2];
      const chatId = msg.chat.id;
      
      if (!this.whatsappSock?.user) {
        this.bot.sendMessage(chatId, '❌ Bot WhatsApp non connecté');
        return;
      }

      try {
        const jid = number.includes('@') ? number : `${number}@s.whatsapp.net`;
        await this.whatsappSock.sendMessage(jid, { text: message });
        this.bot.sendMessage(chatId, `✅ Message envoyé à ${number}`);
      } catch (err) {
        this.bot.sendMessage(chatId, `❌ Erreur : ${err.message}`);
      }
    });

    // /groups - Liste des groupes
    this.bot.onText(/\/groups/, async (msg) => {
      if (!this.checkAuth(msg)) return;
      
      if (!this.whatsappSock?.user) {
        this.bot.sendMessage(msg.chat.id, '❌ Bot WhatsApp non connecté');
        return;
      }

      try {
        const groups = await this.whatsappSock.groupFetchAllParticipating();
        let groupList = '*📋 Groupes WhatsApp :*\n\n';
        
        Object.entries(groups).forEach(([id, group], idx) => {
          groupList += `${idx + 1}. ${group.subject}\n   ID: \`${id}\`\n\n`;
        });

        this.bot.sendMessage(msg.chat.id, groupList, { parse_mode: 'Markdown' });
      } catch (err) {
        this.bot.sendMessage(msg.chat.id, `❌ Erreur : ${err.message}`);
      }
    });

    // /broadcast - Message à tous les groupes
    this.bot.onText(/\/broadcast (.+)/, async (msg, match) => {
      if (!this.checkAuth(msg)) return;
      if (msg.from.id !== this.config.ownerId) {
        this.bot.sendMessage(msg.chat.id, '⛔ Seul le propriétaire peut faire des broadcasts');
        return;
      }
      
      const message = match[1];
      
      if (!this.whatsappSock?.user) {
        this.bot.sendMessage(msg.chat.id, '❌ Bot WhatsApp non connecté');
        return;
      }

      try {
        const groups = await this.whatsappSock.groupFetchAllParticipating();
        let sent = 0;
        
        for (const [id, group] of Object.entries(groups)) {
          await this.whatsappSock.sendMessage(id, { text: message });
          sent++;
          await new Promise(r => setTimeout(r, 1000)); // Délai pour éviter le spam
        }

        this.bot.sendMessage(msg.chat.id, `✅ Message envoyé à ${sent} groupes`);
      } catch (err) {
        this.bot.sendMessage(msg.chat.id, `❌ Erreur : ${err.message}`);
      }
    });

    // Gestion erreurs
    this.bot.on('polling_error', (err) => {
      console.error('Telegram polling error:', err.message);
    });
  }

  // Vérifier autorisation
  isAuthorized(userId) {
    if (this.config.ownerId && userId === this.config.ownerId) return true;
    return this.config.allowedUsers.includes(userId);
  }

  // Check auth helper
  checkAuth(msg) {
    if (!this.isAuthorized(msg.from.id)) {
      this.bot.sendMessage(msg.chat.id, '⛔ Non autorisé');
      return false;
    }
    return true;
  }

  // Connecter le socket WhatsApp
  setWhatsAppSock(sock) {
    this.whatsappSock = sock;
    this.isConnected = !!sock?.user;
    
    if (sock?.user) {
      console.log('🔗 Telegram connecté à WhatsApp');
      this.notifyOwner('✅ Bot WhatsApp connecté !');
    }
  }

  // Notifier le propriétaire
  notifyOwner(message) {
    if (this.config.ownerId && this.bot) {
      this.bot.sendMessage(this.config.ownerId, message);
    }
  }

  // Arrêter
  stop() {
    if (this.bot) {
      this.bot.stopPolling();
      console.log('🛑 Bot Telegram arrêté');
    }
  }
}

// Export singleton
const telegramController = new TelegramController();

export default telegramController;
export { telegramController };
