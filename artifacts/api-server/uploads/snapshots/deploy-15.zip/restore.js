import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const commandsDir = path.join(__dirname, 'commands');
const backupDir = path.join(__dirname, 'commands-backup');

if (!fs.existsSync(backupDir)) {
  console.error('❌ Dossier backup introuvable !');
  process.exit(1);
}

const files = fs.readdirSync(backupDir).filter(f => f.endsWith('.js'));

console.log(`🔄 Restauration de ${files.length} fichiers...\n`);

let restored = 0;

for (const file of files) {
  try {
    const backupPath = path.join(backupDir, file);
    const filePath = path.join(commandsDir, file);
    
    const content = fs.readFileSync(backupPath, 'utf8');
    fs.writeFileSync(filePath, content, 'utf8');
    console.log(`✅ ${file} restauré`);
    restored++;
  } catch (err) {
    console.error(`❌ Erreur ${file}:`, err.message);
  }
}

console.log(`\n✨ ${restored}/${files.length} fichiers restaurés !`);
console.log('🔄 Redémarre le bot: npm start');
