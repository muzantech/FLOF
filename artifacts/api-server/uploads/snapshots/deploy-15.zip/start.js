/**
 * SIGMA MDX Bot - Start Script
 * Ce fichier démarre simplement le bot
 */

import { startBot } from './bot.js';

console.log(`
╔══════════════════════════════════╗
║     SIGMA MDX BOT v3.0           ║
║     Standalone Deploy            ║
╠══════════════════════════════════╣
║  Prefix: .                         ║
║  Mode: Legacy (Single Bot)       ║
╚══════════════════════════════════╝
`);

startBot().catch(err => {
  console.error('❌ Erreur de démarrage:', err);
  process.exit(1);
});
