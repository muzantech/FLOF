import fs from "fs-extra";
import path from "path";

const GROUP_FILE = "./group.json";

// Initialiser le fichier
if (!fs.existsSync(GROUP_FILE)) {
  fs.writeJSONSync(GROUP_FILE, {}, { spaces: 2 });
}

export function getGroupProtections(groupId) {
  try {
    const data = fs.readJSONSync(GROUP_FILE);
    return data[groupId] || {};
  } catch {
    return {};
  }
}

export function setGroupProtection(groupId, setting, value) {
  try {
    const data = fs.readJSONSync(GROUP_FILE);
    if (!data[groupId]) data[groupId] = {};
    data[groupId][setting] = value;
    fs.writeJSONSync(GROUP_FILE, data, { spaces: 2 });
    return true;
  } catch {
    return false;
  }
}

export function loadSudo() {
  const SUDO_FILE = "./sudo.json";
  if (!fs.existsSync(SUDO_FILE)) return [];
  try {
    return fs.readJSONSync(SUDO_FILE);
  } catch {
    return [];
  }
}
