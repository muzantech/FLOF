# 🤖 Système Telegram Controller pour SIGMA MDX

Contrôle ton bot WhatsApp à distance via Telegram !

---

## 📱 Fonctionnalités

- ✅ Contrôle distant du bot WhatsApp
- ✅ Envoi de messages WhatsApp depuis Telegram
- ✅ Broadcast dans tous les groupes
- ✅ Liste des groupes WhatsApp
- ✅ Exécution de commandes WhatsApp
- ✅ Notifications en temps réel
- ✅ Sécurisé (seuls les utilisateurs autorisés)

---

## 🚀 Installation

### 1. Créer un bot Telegram

1. Va sur [@BotFather](https://t.me/BotFather) sur Telegram
2. Envoie `/newbot`
3. Donne un nom et un username à ton bot
4. **Copie le token API** (ex: `123456789:ABCdefGHIjklMNOpqrSTUvwxyz`)

### 2. Installer la dépendance

```bash
npm install node-telegram-bot-api
```

### 3. Configurer

Crée un fichier `telegram-config.json` :

```json
{
  "enabled": true,
  "botToken": "TON_TOKEN_TELEGRAM_ICI",
  "allowedUsers": [],
  "ownerId": null,
  "connected": false
}
```

**Ou** utilise le script de setup :

```bash
node setup-telegram.js TON_TOKEN_TELEGRAM_ICI
```

### 4. Démarrer

Le bot Telegram se connecte automatiquement au démarrage si le token est configuré.

---

## 📋 Commandes Telegram

| Commande | Description | Exemple |
|----------|-------------|---------|
| `/start` | Démarrer et voir l'aide | `/start` |
| `/status` | Statut du bot WhatsApp | `/status` |
| `/info` | Infos sur le bot | `/info` |
| `/cmd` | Exécuter une commande WhatsApp | `/cmd .menu` |
| `/msg` | Envoyer un message WhatsApp | `/msg 32491942744 Salut !` |
| `/groups` | Liste des groupes | `/groups` |
| `/broadcast` | Message à tous les groupes (owner only) | `/broadcast Bonjour !` |

---

## 🔐 Sécurité

**Obtenir ton ID Telegram :**

1. Va sur [@userinfobot](https://t.me/userinfobot)
2. Clique Start
3. Note ton ID (ex: `123456789`)

**Ajouter comme owner :**

```json
{
  "ownerId": 123456789,
  "allowedUsers": [123456789, 987654321]
}
```

---

## 🔧 Intégration dans bot.js

Le système est déjà intégré ! Le fichier `telegram-bot.js` s'occupe de tout.

Pour l'utiliser dans d'autres fichiers :

```javascript
import telegramController from './telegram-bot.js';

// Connecter le socket WhatsApp
telegramController.setWhatsAppSock(sock);

// Envoyer une notification
telegramController.notifyOwner('Message reçu !');
```

---

## 📊 Architecture

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│  Telegram Bot   │────▶│  Controller API  │────▶│  WhatsApp Bot │
│  (Telegram App) │◀────│  (telegram-bot)  │◀────│  (Baileys)     │
└─────────────────┘     └──────────────────┘     └─────────────────┘
```

---

## 🆘 Dépannage

### ❌ "ETELEGRAM: 401 Unauthorized"
**Solution :** Token invalide - Vérifie ton token sur @BotFather

### ❌ "Bot déjà en cours d'exécution"
**Solution :** Supprime `telegram-config.json` et recrée-le

### ❌ Commandes ne fonctionnent pas
**Solution :** Vérifie que ton ID Telegram est dans `allowedUsers`

---

## 💡 Exemples d'utilisation

**Envoyer un menu WhatsApp depuis Telegram :**
```
/cmd .menu
```

**Envoyer un message privé :**
```
/msg 32491942744 Coucou ! Comment ça va ?
```

**Voir les groupes :**
```
/groups
```

**Annoncer quelque chose :**
```
/broadcast 🎉 Mise à jour disponible !
```

---

## 📞 Support

Problèmes ? Contacte via WhatsApp : +32 491 942 744

Canal : https://whatsapp.com/channel/0029VbBIAP58KMqoJluW8r06

---

**SIGMA MDX © 2024 - By MUZAN SIGMA**
