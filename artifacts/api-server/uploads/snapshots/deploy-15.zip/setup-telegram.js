import { writeFileSync, existsSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const CONFIG_FILE = join(__dirname, 'telegram-config.json');

console.log(`
╔══════════════════════════════════════════════╗
║  SIGMA MDX - Setup Connexion Telegram        ║
╚══════════════════════════════════════════════╝
`);

const token = process.argv[2];

if (!token) {
  console.log('❌ Token manquant !');
  console.log('');
  console.log('Usage :');
  console.log('  node setup-telegram.js TON_TOKEN_TELEGRAM');
  console.log('');
  console.log('Comment obtenir un token :');
  console.log('  1. Va sur @BotFather sur Telegram');
  console.log('  2. Envoie /newbot');
  console.log('  3. Nomme ton bot (ex: SIGMA MDX Auth)');
  console.log('  4. Donne un username (ex: sigma_mdx_bot)');
  console.log('  5. Copie le token et colle-le ici');
  console.log('');
  process.exit(1);
}

// Créer la config
const config = {
  enabled: true,
  botToken: token,
  createdAt: new Date().toISOString()
};

writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));

console.log('✅ Configuration créée !');
console.log('');
console.log('📁 Fichiers créés :');
console.log('  - telegram-config.json');
console.log('  - telegram-links.json (sera créé automatiquement)');
console.log('  - telegram-codes.json (sera créé automatiquement)');
console.log('');
console.log('🚀 Prochaines étapes :');
console.log('  1. npm install (si pas déjà fait)');
console.log('  2. npm start');
console.log('');
console.log('📱 Pour les utilisateurs :');
console.log('  1. Cherche ton bot sur Telegram');
console.log('  2. Envoie /start');
console.log('  3. Copie le code de connexion');
console.log('  4. Envoie sur WhatsApp : .connect <code>');
console.log('');
console.log('📖 Documentation : TELEGRAM-AUTH-README.md');
console.log('');
