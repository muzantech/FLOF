import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const commandsDir = path.join(__dirname, 'commands');
const outputDir = path.join(__dirname, 'commands-refactored');

if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });

const files = fs.readdirSync(commandsDir).filter(f => f.endsWith('.js'));

console.log(`🔧 Refactorisation des template literals dans ${files.length} fichiers...\n`);

let processed = 0;

for (const file of files) {
  try {
    const filePath = path.join(commandsDir, file);
    let content = fs.readFileSync(filePath, 'utf8');
    
    // Table de strings encodés
    const stringTable = [];
    let stringIndex = 0;
    
    // Fonction pour encoder un string
    const encode = (str) => {
      const idx = stringIndex++;
      stringTable.push(Buffer.from(str).toString('base64'));
      return `_${idx.toString(36)}`;
    };
    
    // Regex pour trouver les template literals avec variables
    // Capture: `text ${variable} text ${variable} text`
    const templateLiteralRegex = /`([^`]*\$\{[^}]+\}[^`]*)`/g;
    
    let hasChanges = false;
    
    content = content.replace(templateLiteralRegex, (match, innerContent) => {
      hasChanges = true;
      
      // Séparer les parties fixes des variables
      // Ex: "> SIGMA ${name} OK" → ["> SIGMA ", " OK"]
      const parts = innerContent.split(/(\$\{[^}]+\})/g);
      
      let result = '';
      const stringVars = [];
      
      parts.forEach((part, idx) => {
        if (part.startsWith('${') && part.endsWith('}')) {
          // C'est une variable, la garder telle quelle
          const varName = part.slice(2, -1);
          result += ` + ${varName} + `;
        } else if (part.length > 0) {
          // C'est du texte fixe, l'encoder
          const varName = `_${encode(part)}`;
          stringVars.push({ name: varName, value: part });
          result += varName;
        }
      });
      
      // Nettoyer les + en trop
      result = result.replace(/^\s*\+\s*|\s*\+\s*$/g, '');
      result = result.replace(/\+\s*\+/g, '+');
      
      return result || '""';
    });
    
    // Ajouter la table de décodage en début de fichier si des changements ont été faits
    if (hasChanges && stringTable.length > 0) {
      const decoderCode = `// Textes encodés
const __s = [${stringTable.map(s => `"${s}"`).join(', ')}];
const __d = (i) => Buffer.from(__s[i], 'base64').toString();
${stringTable.map((_, i) => `const _${i.toString(36)} = __d(${i});`).join('\n')}

`;
      content = decoderCode + content;
    }
    
    fs.writeFileSync(path.join(outputDir, file), content, 'utf8');
    
    if (hasChanges) {
      console.log(`✅ ${file} - ${stringTable.length} strings encodés`);
      processed++;
    } else {
      console.log(`⏭️  ${file} - pas de template literals`);
    }
    
  } catch (err) {
    console.error(`❌ Erreur ${file}:`, err.message);
  }
}

console.log(`\n✨ ${processed} fichiers refactorisés !`);
console.log(`📁 Résultat dans: commands-refactored/`);
console.log(`\n💡 Pour utiliser:`);
console.log(`   1. Renommer commands-refactored/ → commands/`);
console.log(`   2. Test: npm start puis .ping .menu`);
