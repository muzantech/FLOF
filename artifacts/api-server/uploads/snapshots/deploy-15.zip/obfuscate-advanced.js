import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const commandsDir = path.join(__dirname, 'commands');
const backupDir = path.join(__dirname, 'commands-backup');

// Restaurer d'abord
const files = fs.readdirSync(backupDir).filter(f => f.endsWith('.js'));

console.log(`🔐 Offuscation AVANCÉE style _0x de ${files.length} fichiers...\n`);

// Générateur de noms _0x
let counter = 0x1000;
const generateName = () => `_0x${(counter++).toString(16)}`;

let obfuscated = 0;

for (const file of files) {
  try {
    const backupPath = path.join(backupDir, file);
    const filePath = path.join(commandsDir, file);
    
    let content = fs.readFileSync(backupPath, 'utf8');
    
    // 1. Extraire et encoder tous les strings
    const strings = [];
    const stringMap = new Map();
    
    // Fonction pour ajouter un string
    const addString = (str) => {
      if (str.length < 2) return str;
      if (stringMap.has(str)) return stringMap.get(str);
      
      const idx = strings.length;
      strings.push(str);
      const ref = `_0x${(0x100 + idx).toString(16)}`;
      stringMap.set(str, ref);
      return ref;
    };
    
    // Remplacer les strings doubles
    content = content.replace(/"([^"\\]{3,})"/g, (match, str) => {
      return addString(str);
    });
    
    // Remplacer les strings simples
    content = content.replace(/'([^'\\]{3,})'/g, (match, str) => {
      return addString(str);
    });
    
    // Remplacer les template literals sans variables
    content = content.replace(/`([^`\\$]{3,})`/g, (match, str) => {
      return addString(str);
    });
    
    // 2. Renommer les variables
    const protectedWords = new Set([
      'import', 'export', 'from', 'async', 'await', 'function', 'const', 'let', 'var',
      'return', 'if', 'else', 'try', 'catch', 'throw', 'new', 'this', 'true', 'false',
      'null', 'undefined', 'default', 'typeof', 'name', 'execute', 'sock', 'msg', 'args', 
      'from', 'console', 'log', 'error', 'JSON', 'Object', 'Array', 'String', 'Number',
      'Date', 'Math', 'Promise', 'axios', 'fs', 'path', 'fetch', 'getContextInfo',
      'require', 'module', 'exports', 'process', 'Buffer', '__dirname', '__filename'
    ]);
    
    // Extraire les noms de variables déclarées
    const varMap = new Map();
    const declRegex = /\b(const|let|var)\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\b/g;
    let m;
    
    while ((m = declRegex.exec(content)) !== null) {
      const varName = m[2];
      if (!protectedWords.has(varName) && !varName.startsWith('_0x')) {
        if (!varMap.has(varName)) {
          varMap.set(varName, generateName());
        }
      }
    }
    
    // Remplacer les variables
    const sortedVars = Array.from(varMap.entries()).sort((a, b) => b[0].length - a[0].length);
    for (const [oldName, newName] of sortedVars) {
      const regex = new RegExp(`\\b${oldName}\\b`, 'g');
      content = content.replace(regex, newName);
    }
    
    // 3. Créer la fonction de décodage avec control flow
    const tableName = `_0x${(0x500).toString(16)}`;
    const funcName = `_0x${(0x501).toString(16)}`;
    
    // Encoder les strings
    const encodedStrings = strings.map(s => {
      // XOR encoding simple
      const encoded = Buffer.from(s).toString('base64');
      return `"${encoded}"`;
    });
    
    // Générer le décodeur style _0x
    const decoderCode = `
const ${tableName}=[${encodedStrings.join(',')}];
(function(_0x1b5ca5,_0x204ae7){const _0x1f3bce=${funcName},_0x3061ab=_0x1b5ca5();while(!![]){try{const _0x4a40b2=-parseInt(_0x1f3bce(0x102))+-parseInt(_0x1f3bce(0x103))*-parseInt(_0x1f3bce(0x104))+parseInt(_0x1f3bce(0x105))+-parseInt(_0x1f3bce(0x106))+parseInt(_0x1f3bce(0x107))*parseInt(_0x1f3bce(0x108))+-parseInt(_0x1f3bce(0x109))+parseInt(_0x1f3bce(0x10a));if(_0x4a40b2===_0x204ae7)break;else _0x3061ab['push'](_0x3061ab['shift']());}catch(_0x1a2d0e){_0x3061ab['push'](_0x3061ab['shift']());}}}(_0x${(0x600).toString(16)},0x${(0x728ad).toString(16)}));
function ${funcName}(_0x56ea56,_0x57adad){const _0x42aa13=_0x${(0x600).toString(16)}();return ${funcName}=function(_0x57821c,_0x59d5c9){_0x57821c=_0x57821c-(0x9eb+0xf1*-0x14+0x9d7);let _0x182948=_0x42aa13[_0x57821c];return _0x182948;},${funcName}(_0x56ea56,_0x57adad);}
function _0x${(0x600).toString(16)}(){const _0x${(0x601).toString(16)}=[${encodedStrings.map(s => s.replace(/"/g, "'")).join(',')}];_0x${(0x600).toString(16)}=function(){return _0x${(0x601).toString(16)};};return _0x${(0x600).toString(16)}();}
const _0x${(0x602).toString(16)}=(h)=>{try{return Buffer.from(${tableName}[parseInt(h,16)-0x100],'base64').toString();}catch(e){return'';}};
`;
    
    // 4. Remplacer les références aux strings encodés
    stringMap.forEach((ref, original) => {
      const hexIdx = ref.replace('_0x', '');
      content = content.replace(new RegExp(ref, 'g'), `_0x${(0x602).toString(16)}(0x${hexIdx})`);
    });
    
    // 5. Assembler
    const finalContent = `// SIGMA MDX - PROTECTED
${decoderCode}
${content.trim()}`;
    
    fs.writeFileSync(filePath, finalContent, 'utf8');
    console.log(`🔒 ${file} - Protégé (${varMap.size} vars, ${strings.length} strings)`);
    obfuscated++;
    
    // Reset counter
    counter = 0x1000;
    
  } catch (err) {
    console.error(`❌ ${file}:`, err.message);
  }
}

console.log(`\n✅ ${obfuscated}/${files.length} fichiers protégés !`);
console.log(`\n🧪 Test: npm start puis .ping .menu`);
