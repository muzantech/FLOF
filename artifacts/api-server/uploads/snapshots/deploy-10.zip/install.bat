@echo off
chcp 65001 >nul
title AXTERIS MD — Installation

echo.
echo  ╔══════════════════════════════════════╗
echo  ║     🤖  AXTERIS MD  — INSTALLATION   ║
echo  ╚══════════════════════════════════════╝
echo.

:: ── Vérifier Node.js ─────────────────────────────
node --version >nul 2>&1
if errorlevel 1 (
    echo  ❌ Node.js n'est pas installé!
    echo  ➡️  Télécharge-le sur https://nodejs.org ^(version LTS^)
    pause
    exit /b 1
)

for /f "tokens=1" %%v in ('node --version') do set NODE_VER=%%v
echo  ✅ Node.js détecté : %NODE_VER%

:: ── Vérifier qu'on est dans le bon dossier ────────
if not exist "index.js" (
    echo.
    echo  ❌ ERREUR : Lance ce script depuis le dossier axteris-md!
    echo  ➡️  Le fichier index.js doit être dans le même dossier.
    pause
    exit /b 1
)

echo  ✅ Dossier correct détecté
echo.
echo  📦 Installation des dépendances...
echo  ^(Cela peut prendre 1-2 minutes^)
echo.

:: ── Supprimer node_modules si existant ───────────
if exist "node_modules" (
    echo  🗑️  Suppression de l'ancienne installation...
    rmdir /s /q node_modules 2>nul
)

:: ── Installation avec flags compatibilité ─────────
npm install --ignore-scripts --no-optional 2>&1

if errorlevel 1 (
    echo.
    echo  ⚠️  Première tentative échouée, essai avec --legacy-peer-deps...
    echo.
    npm install --ignore-scripts --no-optional --legacy-peer-deps 2>&1
)

if errorlevel 1 (
    echo.
    echo  ❌ Installation échouée.
    echo  💡 Solutions :
    echo     1. Ferme tous les programmes qui utilisent node_modules
    echo     2. Lance ce script en tant qu'Administrateur
    echo     3. Réessaie
    pause
    exit /b 1
)

echo.
echo  ╔══════════════════════════════════════╗
echo  ║   ✅  Installation terminée!         ║
echo  ╠══════════════════════════════════════╣
echo  ║                                      ║
echo  ║   1. Ouvre config.js                 ║
echo  ║   2. Mets ton numéro dans            ║
echo  ║      ownerNumber                     ║
echo  ║   3. Lance : npm start               ║
echo  ║                                      ║
echo  ╚══════════════════════════════════════╝
echo.
pause
