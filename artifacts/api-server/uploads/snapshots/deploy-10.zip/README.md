# 🤖 Axteris MD — Bot WhatsApp

Bot WhatsApp multi-fonctions propulsé par Baileys.

## Installation
```bash
npm install
```

## Configuration
Ouvre `config.js` → remplace `ownerNumber` par ton numéro sans le +.

## Lancement
```bash
npm start
```

Entre ton numéro → copie le code → WhatsApp > Appareils connectés > Saisir le code.

## Commandes
Tape `.menu` dans WhatsApp pour voir toutes les commandes.
