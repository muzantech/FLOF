// ── AXTERIS MD — POINT D'ENTRÉE ──────────
import {
  makeWASocket, useMultiFileAuthState, DisconnectReason,
  fetchLatestBaileysVersion, makeCacheableSignalKeyStore, isJidBroadcast,
} from "@whiskeysockets/baileys";
import pino          from "pino";
import { Boom }      from "@hapi/boom";
import readline      from "readline";
import chalk         from "chalk";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import fs from "fs";

import config from "./config.js";
import { getMessageText, isOwner, isAdmin, log } from "./lib/utils.js";

// ── Imports commandes ─────────────────────
import generalCommands, { TERMINAL_BANNER } from "./commands/general.js";
import groupCommands    from "./commands/group.js";
import mediaCommands    from "./commands/media.js";
import toolCommands     from "./commands/tools.js";
import aiCommands       from "./commands/ai.js";
import securityCommands, { banned, checkSpam, antilinkOn } from "./commands/security.js";
import funCommands      from "./commands/fun.js";
import pollCommands     from "./commands/poll.js";
import animeCommands    from "./commands/anime.js";
import sportsCommands   from "./commands/sports.js";
import stalkerCommands  from "./commands/stalker.js";

const __dirname    = dirname(fileURLToPath(import.meta.url));
const SESSION_PATH = join(__dirname, "session");
const msgStore     = {};

// ── Fusion commandes ──────────────────────
const allCommands = {
  ...generalCommands,
  ...groupCommands,
  ...mediaCommands,
  ...toolCommands,
  ...aiCommands,
  ...securityCommands,
  ...funCommands,
  ...pollCommands,
  ...animeCommands,
  ...sportsCommands,
  ...stalkerCommands,
};

// ── Bannière ──────────────────────────────
function printBanner() {
  console.log(TERMINAL_BANNER);
  console.log(chalk.yellow(`  Préfixe    : ${config.prefix}`));
  console.log(chalk.yellow(`  Commandes  : ${Object.keys(allCommands).length} chargées`));
  console.log(chalk.yellow(`  Session    : ${SESSION_PATH}`));
  console.log("");
}

// ── Demander le numéro ────────────────────
function askPhone() {
  return new Promise(resolve => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(chalk.green("\n  📱 Numéro WhatsApp (indicatif + numéro, sans +):\n  Ex: 32471234567\n  > "), num => {
      rl.close(); resolve(num.replace(/[^0-9]/g, ""));
    });
  });
}

function hasSession() {
  try { return fs.readdirSync(SESSION_PATH).some(f => f.includes("creds")); } catch { return false; }
}

// ── Démarrage ─────────────────────────────
async function startAxteris() {
  printBanner();
  if (!fs.existsSync(SESSION_PATH)) fs.mkdirSync(SESSION_PATH, { recursive: true });
  if (!fs.existsSync("./temp"))     fs.mkdirSync("./temp",     { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(SESSION_PATH);
  const { version }          = await fetchLatestBaileysVersion();
  log("info", `Baileys: ${version.join(".")}`);

  const sock = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      keys:  makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" })),
    },
    logger:                         pino({ level: "silent" }),
    printQRInTerminal:              false,
    browser:                        ["Ubuntu", "Chrome", "20.0.04"],
    syncFullHistory:                false,
    markOnlineOnConnect:            true,
    generateHighQualityLinkPreview: true,
    keepAliveIntervalMs:            25_000,
    connectTimeoutMs:               60_000,
    defaultQueryTimeoutMs:          0,
    retryRequestDelayMs:            2000,
    maxMsgRetryCount:               5,
    getMessage: async (key) => msgStore[key.id] || { conversation: "" },
  });

  // Stocker messages (fix Bad MAC)
  sock.ev.on("messages.upsert", ({ messages }) => {
    for (const m of messages) {
      if (m.key?.id && m.message) msgStore[m.key.id] = m.message;
    }
    const keys = Object.keys(msgStore);
    if (keys.length > 500) keys.slice(0, keys.length - 500).forEach(k => delete msgStore[k]);
  });

  // ── Code de couplage ──────────────────
  if (!state.creds.registered) {
    if (!hasSession()) {
      const phone = await askPhone();
      log("info", "Demande du code de couplage...");
      await new Promise(r => setTimeout(r, 3000));
      try {
        const code = await sock.requestPairingCode(phone);
        const fmt  = code?.match(/.{1,4}/g)?.join("-") || code;
        console.log("");
        console.log(chalk.bgGreen.black(`  ╔══════════════════════╗  `));
        console.log(chalk.bgGreen.black(`  ║  CODE : ${fmt.padEnd(9)}      ║  `));
        console.log(chalk.bgGreen.black(`  ╚══════════════════════╝  `));
        console.log("");
        console.log(chalk.yellow("  ➡️  WhatsApp > Paramètres > Appareils connectés"));
        console.log(chalk.yellow("  ➡️  Connecter un appareil > Saisir le code\n"));
      } catch (e) {
        log("error", `Code couplage: ${e.message}`);
        try { fs.rmSync(SESSION_PATH, { recursive: true, force: true }); } catch {}
        setTimeout(startAxteris, 5000); return;
      }
    } else {
      log("info", "Session trouvée — reconnexion...");
    }
  }

  // ── Connexion ────────────────────────
  sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
    if (connection === "open") {
      log("success", `Connecté : ${sock.user?.name || sock.user?.id}`);
      console.log(chalk.bgGreen.black(`\n  ✅  AXTERIS MD EN LIGNE !  \n`));
      console.log(chalk.green(`  → Tape ${config.prefix}menu dans WhatsApp\n`));

      // Message de bienvenue au propriétaire
      if (config.ownerNumber && config.ownerNumber !== "VOTRE_NUMERO_ICI") {
        try {
          await sock.sendMessage(`${config.ownerNumber}@s.whatsapp.net`, {
            text:
`╔══════════════════════════╗
║   🤖  *AXTERIS MD*  v${config.botVersion}   ║
╚══════════════════════════╝

✅ *Bot connecté et opérationnel!*

📌 *Préfixe* : \`${config.prefix}\`
⚡ *Commandes* : ${Object.keys(allCommands).length}
👑 *Owner* : ${config.ownerName}

Tape *${config.prefix}menu* pour voir toutes les commandes.`
          });
        } catch {}
      }
    }

    if (connection === "close") {
      const code = new Boom(lastDisconnect?.error)?.output?.statusCode;
      log("warn", `Connexion fermée — code ${code}`);

      if (code === DisconnectReason.loggedOut) {
        log("error", "Déconnecté. Suppression session...");
        try { fs.rmSync(SESSION_PATH, { recursive: true, force: true }); } catch {}
        process.exit(0);
      } else if (code === DisconnectReason.badSession) {
        log("error", "Session invalide. Suppression...");
        try { fs.rmSync(SESSION_PATH, { recursive: true, force: true }); } catch {}
        setTimeout(startAxteris, 3000);
      } else if (code === 515) {
        log("info", "Stream 515 — reconnexion dans 3s...");
        setTimeout(startAxteris, 3000);
      } else {
        log("info", `Reconnexion dans 5s... (code: ${code})`);
        setTimeout(startAxteris, 5000);
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  // ── Messages entrants ────────────────
  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify" && type !== "append") return;
    for (const msg of messages) {
      try { await handleMessage(sock, msg); }
      catch (e) { log("error", `msg: ${e.message}`); }
    }
  });

  // ── Bienvenue nouveaux membres ───────
  sock.ev.on("group-participants.update", async ({ id, participants, action }) => {
    if (!config.welcomeMsg || action !== "add") return;
    for (const jid of participants) {
      try {
        const meta = await sock.groupMetadata(id);
        await sock.sendMessage(id, {
          text: `👋 Bienvenue dans *${meta.subject}*, @${jid.split("@")[0]}!\n\n🤖 Je suis *${config.botName}*.\nTape *${config.prefix}menu* pour voir mes commandes.`,
          mentions: [jid],
        });
      } catch {}
    }
  });

  return sock;
}

// ── Traitement d'un message ───────────────
async function handleMessage(sock, msg) {
  if (!msg?.key?.remoteJid) return;
  if (!msg.message)         return;
  if (isJidBroadcast(msg.key.remoteJid)) return;
  if (msg.key.remoteJid === "status@broadcast") return;

  // fromMe → accepter seulement si c'est une commande
  if (msg.key.fromMe) {
    const t = getMessageText(msg);
    if (!t || !t.startsWith(config.prefix)) return;
  }

  const text = getMessageText(msg);
  const sender  = msg.key.participant || msg.key.remoteJid;
  const from    = msg.key.remoteJid;
  const isGroup = from.endsWith("@g.us");
  const botJid  = sock.user?.id?.replace(/:.*@/, "@") || "";

  // Log des messages
  if (text) log("info", `MSG de ${sender.split("@")[0]}: "${text.slice(0, 60)}"`);
  if (!text) return;

  // Banni
  if (banned.has(sender)) return;

  // Anti-spam
  if (isGroup && checkSpam(from, sender)) {
    await sock.sendMessage(from, {
      text: `⚠️ @${sender.split("@")[0]}, ralentis!`,
      mentions: [sender],
    });
    return;
  }

  // Anti-lien
  if (isGroup && antilinkOn.has(from) && !text.startsWith(config.prefix)) {
    if (/https?:\/\/|wa\.me|chat\.whatsapp\.com/i.test(text)) {
      let meta;
      try { meta = await sock.groupMetadata(from); } catch {}
      if (meta && !isAdmin(meta, sender) && !isOwner(sender)) {
        try { await sock.sendMessage(from, { delete: msg.key }); } catch {}
        await sock.sendMessage(from, {
          text: `⚠️ @${sender.split("@")[0]}, les liens sont interdits!`,
          mentions: [sender],
        });
        return;
      }
    }
  }

  // Vérifier préfixe
  if (!text.startsWith(config.prefix)) return;

  const body = text.slice(config.prefix.length).trim();
  if (!body) return;
  const [cmdName, ...args] = body.split(/\s+/);
  const cmd = cmdName?.toLowerCase();
  if (!cmd) return;

  // Contexte
  let groupMetadata = null;
  if (isGroup) {
    try { groupMetadata = await sock.groupMetadata(from); } catch {}
  }
  const ctx = { sender, isGroup, groupMetadata, botJid };

  log("cmd", `[${cmd}] ${sender.split("@")[0]} — ${isGroup ? groupMetadata?.subject || "groupe" : "privé"}`);

  // Exécuter
  if (allCommands[cmd]) {
    try {
      await allCommands[cmd](sock, msg, args, ctx);
    } catch (e) {
      log("error", `[${cmd}] ${e.message}`);
      await sock.sendMessage(from, { text: `❌ Erreur: ${e.message}` }, { quoted: msg }).catch(() => {});
    }
  } else {
    await sock.sendMessage(from, {
      text: `❓ Commande *${config.prefix}${cmd}* inconnue.\nTape *${config.prefix}menu* pour la liste.`,
    }, { quoted: msg }).catch(() => {});
  }
}

// ── Lancement ────────────────────────────
startAxteris().catch(e => { log("error", e.message); process.exit(1); });
process.on("uncaughtException",  e => log("error", `[uncaught] ${e.message}`));
process.on("unhandledRejection", e => log("error", `[rejection] ${String(e)}`));
