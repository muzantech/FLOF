// ============================================
//        AXTERIS MD — CONFIGURATION
// ============================================

const config = {
  // ── Identité ───────────────────────────────
  botName:    "Axteris MD",
  botVersion: "1.0.0",
  prefix:     ".",

  // ── Propriétaire ───────────────────────────
  // Format international SANS le +  →  ex: 32471234567
  ownerNumber: "32491942744",
  ownerName:   "Axteris",

  // ── GiftedTech Premium API ─────────────────
  // Clé Premium — rate limit élevé, accès complet
  giftedApiKey: "gifted-api_0u5a705yfobo870e70ge6",
  giftedBase:   "https://api.giftedtech.co.ke",

  // ── OpenAI (optionnel) ─────────────────────
  // Laisse vide → le bot utilise GiftedTech AI automatiquement
  openaiApiKey:   "",
  aiModel:        "gpt-3.5-turbo",
  aiMaxTokens:    500,
  aiSystemPrompt: "Tu es Axteris, un assistant WhatsApp intelligent et sympa. Réponds de façon concise en français.",

  // ── APIs météo & news ──────────────────────
  weatherApiKey: "4902c0f2550f58298ad4146a92b65e10",
  newsApiKey:    "dcd720a6f1914e2d9dba9790c188c08c",

  // ── Paramètres ────────────────────────────
  welcomeMsg:        true,
  downloadMaxSizeMB: 100,

  // ── Messages système ──────────────────────
  messages: {
    groupOnly:  "❌ Cette commande ne fonctionne qu'en groupe.",
    adminOnly:  "❌ Réservé aux admins du groupe.",
    ownerOnly:  "❌ Réservé au propriétaire.",
    privateOnly:"❌ Cette commande ne fonctionne qu'en privé.",
    error:      "❌ Une erreur s'est produite. Réessaie plus tard.",
  },
};

export default config;
