// ── AXTERIS MD — IA (GiftedTech) ─────────
// ai gpt gem dsk img clr
import { g } from "./gifted.js";
import { errMsg } from "../lib/utils.js";
import config from "../config.js";

const history = new Map();
const p = config.prefix;

async function ask(ep, q) {
  const d = await g(ep, { q });
  return d?.result || d?.message || d?.answer || d?.response || null;
}

const aiCommands = {

  // .ai — IA principale multi-fallback
  ai: async (sock, msg, args, { sender }) => {
    const from = msg.key.remoteJid;
    const q    = args.join(" ").trim();
    if (!q) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}ai Ta question\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: "🧠 Réflexion en cours..." }, { quoted: msg });
    try {
      let ans = null;
      for (const ep of ["/api/ai/ai", "/api/ai/gpt4o", "/api/ai/gemini", "/api/ai/unlimitedai", "/api/ai/pollinationsai"]) {
        try { ans = await ask(ep, q); if (ans && ans.length > 2) break; } catch {}
      }
      if (!ans) return sock.sendMessage(from, { text: errMsg("L'IA n'a pas répondu. Réessaie.") }, { quoted: msg });

      const conv = history.get(sender) || [];
      conv.push({ q, a: ans });
      if (conv.length > 10) conv.shift();
      history.set(sender, conv);

      const lines = ans.split("\n").slice(0, 25).map(l => `│  ${l}`).join("\n");
      await sock.sendMessage(from, {
        text: `╭──「 🧠 *AXTERIS IA* 」\n│\n${lines}\n│\n╰──────────────────────\n> _\`${p}clr\` pour réinitialiser_`
      }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .gpt — GPT-4o
  gpt: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const q    = args.join(" ").trim();
    if (!q) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}gpt Ta question\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: "🤖 GPT-4o..." }, { quoted: msg });
    try {
      const ans = await ask("/api/ai/gpt4o", q);
      if (!ans) throw new Error("Pas de réponse.");
      const lines = ans.split("\n").slice(0, 25).map(l => `│  ${l}`).join("\n");
      await sock.sendMessage(from, { text: `╭──「 🤖 *GPT-4o* 」\n│\n${lines}\n│\n╰──────────────────────` }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .gem — Google Gemini
  gem: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const q    = args.join(" ").trim();
    if (!q) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}gem Ta question\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: "✨ Gemini..." }, { quoted: msg });
    try {
      const ans = await ask("/api/ai/gemini", q);
      if (!ans) throw new Error("Pas de réponse.");
      const lines = ans.split("\n").slice(0, 25).map(l => `│  ${l}`).join("\n");
      await sock.sendMessage(from, { text: `╭──「 ✨ *GEMINI* 」\n│\n${lines}\n│\n╰──────────────────────` }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .dsk — DeepSeek
  dsk: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const q    = args.join(" ").trim();
    if (!q) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}dsk Ta question\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: "🔬 DeepSeek..." }, { quoted: msg });
    try {
      const d   = await g("/api/ai/deepseek", { q });
      const ans = d?.result || d?.response;
      if (!ans) throw new Error("Pas de réponse.");
      const lines = ans.split("\n").slice(0, 25).map(l => `│  ${l}`).join("\n");
      await sock.sendMessage(from, { text: `╭──「 🔬 *DEEPSEEK* 」\n│\n${lines}\n│\n╰──────────────────────` }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .img — Générer image IA
  img: async (sock, msg, args) => {
    const from   = msg.key.remoteJid;
    const prompt = args.join(" ").trim();
    if (!prompt) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}img Un chat dans l'espace\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: "🎨 Génération image IA..." }, { quoted: msg });
    try {
      let imgUrl = null;
      // Essayer plusieurs générateurs
      for (const [ep, param] of [
        ["/api/ai/fluximage",        { prompt }],
        ["/api/ai/magicstudio",      { prompt }],
        ["/api/ai/soratexttoimage",  { prompt }],
        ["/api/ai/deepaiimage",      { q: prompt }],
      ]) {
        try {
          const d = await g(ep, param);
          const r = d?.result;
          imgUrl  = (typeof r === "string" && r.startsWith("http")) ? r : r?.url || r?.image || r?.link;
          if (imgUrl) break;
        } catch {}
      }
      if (!imgUrl) throw new Error("Aucun générateur disponible. Réessaie.");
      await sock.sendMessage(from, { image: { url: imgUrl }, caption: `🎨 *${prompt}*\n\n_Axteris MD — IA_` }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .clr — Effacer historique
  clr: async (sock, msg, args, { sender }) => {
    history.delete(sender);
    await sock.sendMessage(msg.key.remoteJid, { text: "🧹 *Conversation IA réinitialisée!*" }, { quoted: msg });
  },
};

export default aiCommands;
