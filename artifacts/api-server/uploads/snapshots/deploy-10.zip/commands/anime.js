// ── AXTERIS MD — ANIME ───────────────────
// neko waifu aq ani mng
import { g } from "./gifted.js";
import { errMsg } from "../lib/utils.js";
import config from "../config.js";

const p = config.prefix;

const animeCommands = {

  neko: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try { const d = await g("/api/anime/neko"); const u = d?.result?.url || d?.result?.image || d?.result; await sock.sendMessage(from, { image: { url: u }, caption: "🐱 *Neko*\n\n_Axteris MD_" }, { quoted: msg }); }
    catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  waifu: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try { const d = await g("/api/anime/waifu"); const u = d?.result?.url || d?.result?.image || d?.result; await sock.sendMessage(from, { image: { url: u }, caption: "🌸 *Waifu*\n\n_Axteris MD_" }, { quoted: msg }); }
    catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  aq: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    try {
      const params = args.length ? { character: args.join(" ") } : {};
      const d      = await g("/api/anime/quotes", params);
      const r      = d?.result;
      const quote  = r?.quote || r?.text || r;
      const char   = r?.character || "?";
      const show   = r?.anime || r?.show || "";
      await sock.sendMessage(from, { text: `╭──「 🎌 *ANIME QUOTE* 」\n│\n│  _"${quote}"_\n│  — *${char}*${show ? ` (${show})` : ""}\n│\n╰──────────────────────` }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  ani: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try {
      const d     = await g("/api/anime/random");
      const r     = d?.result;
      const title = r?.title || r?.name || "?";
      const img   = r?.image || r?.cover;
      const text  = `╭──「 🎌 *ANIME* 」\n│  📺 *${title}*\n│  ⭐ ${r?.score || "?"} | 📺 ${r?.episodes || "?"} eps\n╰──────────────────────`;
      img ? await sock.sendMessage(from, { image: { url: img }, caption: text }, { quoted: msg })
          : await sock.sendMessage(from, { text }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  mng: async (sock, msg, args) => {
    const from  = msg.key.remoteJid;
    const query = args.join(" ").trim();
    if (!query) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}mng One Piece\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: `🔍 Manga: *${query}*...` }, { quoted: msg });
    try {
      const d     = await g("/api/anime/komiku", { query });
      const list  = d?.result;
      const r     = Array.isArray(list) ? list[0] : list;
      if (!r) throw new Error("Aucun résultat.");
      const title = r?.title || r?.name || "?";
      const cover = r?.cover || r?.image;
      const desc  = r?.description || r?.synopsis || "";
      const text  = `╭──「 📚 *MANGA* 」\n│  📖 *${title}*\n│  ${desc.slice(0, 80)}...\n╰──────────────────────`;
      cover ? await sock.sendMessage(from, { image: { url: cover }, caption: text }, { quoted: msg })
            : await sock.sendMessage(from, { text }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },
};

export default animeCommands;
