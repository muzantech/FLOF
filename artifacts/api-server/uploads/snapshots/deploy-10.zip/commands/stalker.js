// ── AXTERIS MD — STALKER & TEMPGEN ───────
// git igs tts tws ip  tmail tinb tnum sms
import { g } from "./gifted.js";
import { errMsg } from "../lib/utils.js";
import config from "../config.js";

const p = config.prefix;
const mails = new Map();
const nums  = new Map();

const stalkerCommands = {

  git: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const user = args[0];
    if (!user) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}git torvalds\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: `🔍 GitHub: *${user}*...` }, { quoted: msg });
    try {
      const d = await g("/api/stalker/gitstalk", { username: user });
      const r = d?.result;
      if (!r) throw new Error("Introuvable.");
      const avatar = r.avatar_url || r.avatar;
      const text   = `╭──「 🐙 *GITHUB — ${(r.name||user).toUpperCase()}* 」\n│  👤 *Nom*       : ${r.name||user}\n│  📦 *Repos*     : ${r.public_repos||"?"}\n│  👥 *Followers* : ${r.followers||"?"}\n│  👣 *Following* : ${r.following||"?"}\n${r.bio?`│  📝 *Bio* : ${r.bio.slice(0,50)}\n`:""}${r.location?`│  📍 ${r.location}\n`:""}│\n│  🔗 github.com/${user}\n╰──────────────────────────`;
      avatar ? await sock.sendMessage(from, { image: { url: avatar }, caption: text }, { quoted: msg })
             : await sock.sendMessage(from, { text }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  igs: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const user = args[0];
    if (!user) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}igs username\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: `🔍 Instagram: *${user}*...` }, { quoted: msg });
    try {
      const d      = await g("/api/stalker/instagramstalker", { username: user });
      const r      = d?.result;
      if (!r) throw new Error("Introuvable.");
      const avatar = r.profile_pic_url || r.avatar;
      const vrf    = r.is_verified ? " ✅" : "";
      const text   = `╭──「 📸 *INSTAGRAM — @${user}* 」\n│  👤 ${r.full_name||user}${vrf}\n│  👥 *Followers* : ${Number(r.follower_count||0).toLocaleString()}\n│  📷 *Posts*     : ${r.media_count||"?"}\n│  🔐 ${r.is_private?"🔒 Privé":"🔓 Public"}\n${r.biography?`│  📝 ${r.biography.slice(0,50)}\n`:""}│\n│  🔗 instagram.com/${user}\n╰──────────────────────────`;
      avatar ? await sock.sendMessage(from, { image: { url: avatar }, caption: text }, { quoted: msg })
             : await sock.sendMessage(from, { text }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  ttk: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const user = args[0];
    if (!user) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}tts username\` (TikTok)`) }, { quoted: msg });
    await sock.sendMessage(from, { text: `🔍 TikTok: *${user}*...` }, { quoted: msg });
    try {
      const d      = await g("/api/stalker/tiktokstalk", { username: user });
      const r      = d?.result;
      if (!r) throw new Error("Introuvable.");
      const uname  = r.uniqueId || r.username || user;
      const avatar = r.avatarThumb || r.avatar;
      const text   = `╭──「 🎵 *TIKTOK — @${uname}* 」\n│  👤 ${r.nickname||user}\n│  👥 *Followers* : ${Number(r.followerCount||0).toLocaleString()}\n│  ❤️  *Likes*    : ${Number(r.heartCount||0).toLocaleString()}\n│  🎬 *Vidéos*   : ${r.videoCount||"?"}\n${r.signature?`│  📝 ${r.signature.slice(0,50)}\n`:""}│\n│  🔗 tiktok.com/@${uname}\n╰──────────────────────────`;
      avatar ? await sock.sendMessage(from, { image: { url: avatar }, caption: text }, { quoted: msg })
             : await sock.sendMessage(from, { text }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  tws: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const user = args[0];
    if (!user) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}tws username\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: `🔍 Twitter/X: *${user}*...` }, { quoted: msg });
    try {
      const d      = await g("/api/stalker/twitterstalk", { username: user });
      const r      = d?.result;
      if (!r) throw new Error("Introuvable.");
      const avatar = r.profile_image_url || r.avatar;
      const vrf    = r.verified ? " ✅" : "";
      const text   = `╭──「 🐦 *TWITTER/X — @${user}* 」\n│  👤 ${r.name||user}${vrf}\n│  👥 *Followers* : ${Number(r.followers_count||0).toLocaleString()}\n│  🐦 *Tweets*   : ${Number(r.statuses_count||0).toLocaleString()}\n${r.description?`│  📝 ${r.description.slice(0,50)}\n`:""}│\n│  🔗 x.com/${user}\n╰──────────────────────────`;
      avatar ? await sock.sendMessage(from, { image: { url: avatar }, caption: text }, { quoted: msg })
             : await sock.sendMessage(from, { text }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  ip: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const addr = args[0];
    if (!addr) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}ip 8.8.8.8\``) }, { quoted: msg });
    try {
      const d = await g("/api/stalker/ipstalk", { address: addr });
      const r = d?.result;
      if (!r) throw new Error("Introuvable.");
      await sock.sendMessage(from, {
        text: `╭──「 🌐 *IP — ${addr}* 」\n│  🌍 *Pays*     : ${r.country||r.country_name||"?"}\n│  🏙️ *Ville*    : ${r.city||"?"}\n│  📍 *Région*   : ${r.region||"?"}\n│  🌐 *ISP*      : ${r.isp||r.org||"?"}\n│  🕐 *Timezone* : ${r.timezone||"?"}\n╰──────────────────────`
      }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  tmail: async (sock, msg, args, { sender }) => {
    const from = msg.key.remoteJid;
    await sock.sendMessage(from, { text: "📧 Génération email..." }, { quoted: msg });
    try {
      const d     = await g("/api/tempgen/v1/generate");
      const email = d?.result?.email || d?.result?.address || d?.result;
      if (!email) throw new Error("Impossible de générer.");
      mails.set(sender, email);
      await sock.sendMessage(from, { text: `╭──「 📧 *EMAIL TEMPORAIRE* 」\n│\n│  ✉️ *${email}*\n│\n│  ➤ \`${p}tinb\` pour voir les messages\n│  ⏳ ~10 minutes\n│\n╰──────────────────────` }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  tinb: async (sock, msg, args, { sender }) => {
    const from  = msg.key.remoteJid;
    const email = args[0] || mails.get(sender);
    if (!email) return sock.sendMessage(from, { text: errMsg(`Génère d'abord un email : \`${p}tmail\``) }, { quoted: msg });
    try {
      const d    = await g("/api/tempgen/v1/inbox", { email });
      const msgs = d?.result?.messages || d?.result || [];
      if (!msgs.length) return sock.sendMessage(from, { text: `📭 Boîte vide pour *${email}*` }, { quoted: msg });
      let text = `╭──「 📬 *INBOX — ${email}* 」\n│\n`;
      (Array.isArray(msgs) ? msgs : []).slice(0,5).forEach((m,i) => {
        text += `│  *${i+1}. ${(m.subject||"Sans sujet").slice(0,40)}*\n│  📤 ${m.from||"?"}\n│\n`;
      });
      text += "╰──────────────────────────────";
      await sock.sendMessage(from, { text }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  tnum: async (sock, msg, args, { sender }) => {
    const from    = msg.key.remoteJid;
    const country = args[0] || "random";
    await sock.sendMessage(from, { text: "📱 Génération numéro..." }, { quoted: msg });
    try {
      const d   = await g("/api/tempgen/sms/generate", { country });
      const num = d?.result?.number || d?.result?.phone || d?.result;
      if (!num) throw new Error("Impossible de générer.");
      nums.set(sender, num);
      await sock.sendMessage(from, { text: `╭──「 📱 *NUMÉRO TEMPORAIRE* 」\n│\n│  📞 *${num}*\n│  🌍 ${country}\n│\n│  ➤ \`${p}sms\` pour voir les SMS\n│  ⏳ ~10 minutes\n│\n╰──────────────────────` }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  sms: async (sock, msg, args, { sender }) => {
    const from = msg.key.remoteJid;
    const num  = args[0] || nums.get(sender);
    if (!num) return sock.sendMessage(from, { text: errMsg(`Génère d'abord un numéro : \`${p}tnum\``) }, { quoted: msg });
    try {
      const d   = await g("/api/tempgen/sms/inbox", { number: num });
      const sms = d?.result?.messages || d?.result || [];
      if (!sms.length) return sock.sendMessage(from, { text: `📭 Aucun SMS pour *${num}*` }, { quoted: msg });
      let text = `╭──「 💬 *SMS — ${num}* 」\n│\n`;
      (Array.isArray(sms) ? sms : []).slice(0,5).forEach((s,i) => {
        text += `│  *${i+1}. De: ${s.from||"?"}*\n│  ${(s.body||s.message||s.text||"?").slice(0,80)}\n│\n`;
      });
      text += "╰──────────────────────────────";
      await sock.sendMessage(from, { text }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },
};

export default stalkerCommands;
