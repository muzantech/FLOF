// ── AXTERIS MD — SÉCURITÉ ────────────────
// spam aln warn uwrn wls ban ubn
import config from "../config.js";
import { isAdmin, isBotAdmin, isOwner, errMsg } from "../lib/utils.js";

const warnings    = new Map();
export const banned      = new Set();
const spamTracker = new Map();
const antispamOn  = new Set();
export const antilinkOn  = new Set();

const WARN_MAX = 3, SPAM_LIM = 5, SPAM_WIN = 5000;

export function checkSpam(gid, jid) {
  if (!antispamOn.has(gid)) return false;
  const now = Date.now(), d = spamTracker.get(jid) || { c: 0, t: now };
  if (now - d.t > SPAM_WIN) { spamTracker.set(jid, { c: 1, t: now }); return false; }
  d.c++; d.t = now; spamTracker.set(jid, d);
  return d.c > SPAM_LIM;
}

function addW(gid, jid)   { if (!warnings.has(gid)) warnings.set(gid, new Map()); const m = warnings.get(gid); m.set(jid, (m.get(jid)||0)+1); return m.get(jid); }
function getW(gid, jid)   { return warnings.get(gid)?.get(jid) || 0; }
function resetW(gid, jid) { warnings.get(gid)?.delete(jid); }

const securityCommands = {

  spam: async (sock, msg, args, { sender, groupMetadata }) => {
    const from = msg.key.remoteJid;
    if (!groupMetadata) return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    if (!isAdmin(groupMetadata, sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    const t = args[0]?.toLowerCase();
    if (!["on","off"].includes(t)) return sock.sendMessage(from, { text: errMsg(`Usage: \`${config.prefix}spam on/off\``) }, { quoted: msg });
    t === "on" ? antispamOn.add(from) : antispamOn.delete(from);
    await sock.sendMessage(from, { text: `🛡️ Anti-spam *${t==="on"?"✅ Activé":"❌ Désactivé"}*\nLimite: ${SPAM_LIM} msgs/${SPAM_WIN/1000}s` }, { quoted: msg });
  },

  aln: async (sock, msg, args, { sender, groupMetadata }) => {
    const from = msg.key.remoteJid;
    if (!groupMetadata) return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    if (!isAdmin(groupMetadata, sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    const t = args[0]?.toLowerCase();
    if (!["on","off"].includes(t)) return sock.sendMessage(from, { text: errMsg(`Usage: \`${config.prefix}aln on/off\``) }, { quoted: msg });
    t === "on" ? antilinkOn.add(from) : antilinkOn.delete(from);
    await sock.sendMessage(from, { text: `🔗 Anti-lien *${t==="on"?"✅ Activé":"❌ Désactivé"}*` }, { quoted: msg });
  },

  warn: async (sock, msg, args, { sender, groupMetadata, botJid }) => {
    const from = msg.key.remoteJid;
    if (!groupMetadata) return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    if (!isAdmin(groupMetadata, sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    const m      = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!m.length) return sock.sendMessage(from, { text: errMsg("Mentionne un utilisateur.") }, { quoted: msg });
    const reason = args.filter(a => !a.startsWith("@")).join(" ") || "Aucune raison";
    for (const t of m) {
      const n = addW(from, t);
      if (n >= WARN_MAX) {
        resetW(from, t);
        if (isBotAdmin(groupMetadata, botJid)) await sock.groupParticipantsUpdate(from, [t], "remove");
        await sock.sendMessage(from, { text: `⛔ @${t.split("@")[0]} — *${WARN_MAX}/${WARN_MAX}* warns → Expulsé!\n📝 ${reason}`, mentions: [t] }, { quoted: msg });
      } else {
        await sock.sendMessage(from, { text: `⚠️ @${t.split("@")[0]} — *${n}/${WARN_MAX}* warns\n📝 ${reason}`, mentions: [t] }, { quoted: msg });
      }
    }
  },

  uwrn: async (sock, msg, args, { sender, groupMetadata }) => {
    const from = msg.key.remoteJid;
    if (!groupMetadata) return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    if (!isAdmin(groupMetadata, sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    const m = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!m.length) return sock.sendMessage(from, { text: errMsg("Mentionne un utilisateur.") }, { quoted: msg });
    for (const t of m) {
      const cur = getW(from, t);
      if (cur <= 0) await sock.sendMessage(from, { text: `ℹ️ Aucun warn pour @${t.split("@")[0]}.`, mentions: [t] }, { quoted: msg });
      else { warnings.get(from).set(t, cur-1); await sock.sendMessage(from, { text: `✅ Warn retiré à @${t.split("@")[0]}. Total: *${cur-1}/${WARN_MAX}*`, mentions: [t] }, { quoted: msg }); }
    }
  },

  wls: async (sock, msg, args, { sender, groupMetadata }) => {
    const from = msg.key.remoteJid;
    if (!groupMetadata) return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    if (!isAdmin(groupMetadata, sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    const gMap = warnings.get(from);
    if (!gMap?.size) return sock.sendMessage(from, { text: "ℹ️ Aucun avertissement." }, { quoted: msg });
    const entries = [...gMap.entries()].filter(([,c]) => c > 0);
    const lines   = entries.map(([j,c],i) => `  ${i+1}. @${j.split("@")[0]} — *${c}/${WARN_MAX}*`).join("\n");
    await sock.sendMessage(from, {
      text: `╭──「 📋 *WARNS* 」\n╰──────────────────────\n\n${lines}\n\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬`,
      mentions: entries.map(([j]) => j)
    }, { quoted: msg });
  },

  ban: async (sock, msg, args, { sender, groupMetadata }) => {
    const from = msg.key.remoteJid;
    if (!isAdmin(groupMetadata, sender) && !isOwner(sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    const m = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!m.length) return sock.sendMessage(from, { text: errMsg("Mentionne un utilisateur.") }, { quoted: msg });
    for (const t of m) banned.add(t);
    await sock.sendMessage(from, { text: `🚫 *${m.map(j=>"@"+j.split("@")[0]).join(", ")}* bannis du bot.`, mentions: m }, { quoted: msg });
  },

  ubn: async (sock, msg, args, { sender, groupMetadata }) => {
    const from = msg.key.remoteJid;
    if (!isAdmin(groupMetadata, sender) && !isOwner(sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    const m = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!m.length) return sock.sendMessage(from, { text: errMsg("Mentionne un utilisateur.") }, { quoted: msg });
    for (const t of m) banned.delete(t);
    await sock.sendMessage(from, { text: `✅ *${m.map(j=>"@"+j.split("@")[0]).join(", ")}* débanni(s).`, mentions: m }, { quoted: msg });
  },
};

export default securityCommands;
