// ── AXTERIS MD — FUN ─────────────────────
// joke dare true adv mot luv flrt pick gdnt hb coin 8bl
import { g, txt } from "./gifted.js";
import { errMsg } from "../lib/utils.js";
import config from "../config.js";

const p = config.prefix;

async function fun(ep) {
  const d = await g(ep);
  return txt(d?.result) || null;
}

const R8BALL = [
  "✅ Oui, absolument!","✅ C'est certain.","✅ Sans aucun doute.",
  "🤔 C'est difficile à dire.","🤔 Repose la question plus tard.",
  "❌ N'y compte pas.","❌ Ma réponse est non.","❌ Très peu probable.",
];

const funCommands = {

  joke: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try { const t = await fun("/api/fun/jokes"); await sock.sendMessage(from, { text: `╭──「 😂 *BLAGUE* 」\n│\n│  ${t}\n│\n╰──────────────────────` }, { quoted: msg }); }
    catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  dare: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try { const t = await fun("/api/fun/dares"); await sock.sendMessage(from, { text: `╭──「 🎯 *DÉFI* 」\n│\n│  ${t}\n│\n╰──────────────────────\n> _Oses-tu?_ 😏` }, { quoted: msg }); }
    catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  true: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try { const t = await fun("/api/fun/truth"); await sock.sendMessage(from, { text: `╭──「 🤫 *VÉRITÉ* 」\n│\n│  ${t}\n│\n╰──────────────────────` }, { quoted: msg }); }
    catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  adv: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try { const t = await fun("/api/fun/advice"); await sock.sendMessage(from, { text: `╭──「 💡 *CONSEIL* 」\n│\n│  ${t}\n│\n╰──────────────────────` }, { quoted: msg }); }
    catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  mot: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try { const t = await fun("/api/fun/motivation"); await sock.sendMessage(from, { text: `╭──「 💪 *MOTIVATION* 」\n│\n│  ${t}\n│\n╰──────────────────────` }, { quoted: msg }); }
    catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  luv: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try { const t = await fun("/api/fun/love"); await sock.sendMessage(from, { text: `╭──「 ❤️ *AMOUR* 」\n│\n│  ${t}\n│\n╰──────────────────────` }, { quoted: msg }); }
    catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  flrt: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try { const t = await fun("/api/fun/flirt"); await sock.sendMessage(from, { text: `╭──「 💝 *FLIRT* 」\n│\n│  ${t}\n│\n╰──────────────────────` }, { quoted: msg }); }
    catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  pick: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try { const t = await fun("/api/fun/pickuplines"); await sock.sendMessage(from, { text: `╭──「 😍 *PICKUP LINE* 」\n│\n│  ${t}\n│\n╰──────────────────────` }, { quoted: msg }); }
    catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  gdnt: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try { const t = await fun("/api/fun/goodnight"); await sock.sendMessage(from, { text: `╭──「 🌙 *BONNE NUIT* 」\n│\n│  ${t}\n│\n╰──────────────────────` }, { quoted: msg }); }
    catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  hb: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try { const t = await fun("/api/fun/heartbreak"); await sock.sendMessage(from, { text: `╭──「 💔 *PEINE DE CŒUR* 」\n│\n│  _${t}_\n│\n╰──────────────────────` }, { quoted: msg }); }
    catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  coin: async (sock, msg) => {
    const from = msg.key.remoteJid;
    const r    = Math.random() < 0.5 ? "🪙 *PILE*" : "🪙 *FACE*";
    await sock.sendMessage(from, { text: `╭──「 🪙 *PILE OU FACE* 」\n│\n│  ${r}\n│\n╰──────────────────────` }, { quoted: msg });
  },

  "8bl": async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const q    = args.join(" ").trim();
    if (!q) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}8bl Ta question?\``) }, { quoted: msg });
    const rep  = R8BALL[Math.floor(Math.random() * R8BALL.length)];
    await sock.sendMessage(from, { text: `╭──「 🎱 *BOULE MAGIQUE* 」\n│\n│  ❓ ${q}\n│  🎱 ${rep}\n│\n╰──────────────────────` }, { quoted: msg });
  },
};

export default funCommands;
