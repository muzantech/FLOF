// ── AXTERIS MD — SONDAGE ─────────────────
// poll vote pres pend
import config from "../config.js";
import { isAdmin, errMsg } from "../lib/utils.js";

const polls = new Map();
const p     = config.prefix;

function fmtR(poll) {
  const total  = poll.votes.size;
  const counts = poll.options.map((_,i) => [...poll.votes.values()].filter(v=>v===i).length);
  const bars   = poll.options.map((opt,i) => {
    const pct    = total > 0 ? Math.round(counts[i]/total*100) : 0;
    const bar    = "█".repeat(Math.round(pct/10)) + "░".repeat(10-Math.round(pct/10));
    return `  ${String(i+1).padStart(2,"0")}. ${opt}\n      ${bar} ${pct}% (${counts[i]}v)`;
  });
  return { bars, total, counts };
}

const pollCommands = {

  poll: async (sock, msg, args, { sender }) => {
    const from  = msg.key.remoteJid;
    const parts = args.join(" ").split("|").map(s=>s.trim()).filter(Boolean);
    if (parts.length < 3) return sock.sendMessage(from, {
      text: `╭──「 📊 *SONDAGE* 」\n│\n│  Usage:\n│  \`${p}poll Question | Opt1 | Opt2\`\n│\n╰──────────────────────`
    }, { quoted: msg });
    if (polls.get(from)?.open) return sock.sendMessage(from, { text: errMsg(`Sondage actif. Tape \`${p}pend\` d'abord.`) }, { quoted: msg });
    const question = parts[0], options = parts.slice(1);
    polls.set(from, { question, options, votes: new Map(), creator: sender, open: true });
    const lines = options.map((o,i) => `  ${String(i+1).padStart(2,"0")}. ${o}`).join("\n");
    await sock.sendMessage(from, {
      text: `╭──「 📊 *SONDAGE* 」\n│  ❓ *${question}*\n╰──────────────────────\n\n${lines}\n\n➤ \`${p}vote <n°>\` pour voter\n➤ \`${p}pres\` pour les résultats\n➤ \`${p}pend\` pour clôturer`
    }, { quoted: msg });
  },

  vote: async (sock, msg, args, { sender }) => {
    const from = msg.key.remoteJid;
    const poll = polls.get(from);
    if (!poll?.open) return sock.sendMessage(from, { text: errMsg(`Aucun sondage actif.`) }, { quoted: msg });
    const n = parseInt(args[0]);
    if (isNaN(n)||n<1||n>poll.options.length) return sock.sendMessage(from, { text: errMsg(`Vote entre 1 et ${poll.options.length}.`) }, { quoted: msg });
    poll.votes.set(sender, n-1);
    await sock.sendMessage(from, { text: `✅ Vote pour *${n}. ${poll.options[n-1]}*\n👥 Total: ${poll.votes.size}` }, { quoted: msg });
  },

  pres: async (sock, msg) => {
    const from = msg.key.remoteJid;
    const poll = polls.get(from);
    if (!poll) return sock.sendMessage(from, { text: errMsg("Aucun sondage.") }, { quoted: msg });
    const { bars, total } = fmtR(poll);
    await sock.sendMessage(from, {
      text: `╭──「 📊 *RÉSULTATS* 」\n│  ❓ *${poll.question}*\n│  👥 ${total} vote(s) — ${poll.open?"🟢 Ouvert":"🔴 Clôturé"}\n╰──────────────────────\n\n${bars.join("\n\n")}\n\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬`
    }, { quoted: msg });
  },

  pend: async (sock, msg, args, { sender, groupMetadata }) => {
    const from = msg.key.remoteJid;
    const poll = polls.get(from);
    if (!poll?.open) return sock.sendMessage(from, { text: errMsg("Aucun sondage actif.") }, { quoted: msg });
    if (poll.creator !== sender && !(groupMetadata && isAdmin(groupMetadata, sender)))
      return sock.sendMessage(from, { text: errMsg("Seul le créateur ou un admin peut clôturer.") }, { quoted: msg });
    poll.open = false;
    const { bars, total, counts } = fmtR(poll);
    const max     = Math.max(...counts);
    const winners = poll.options.filter((_,i) => counts[i] === max);
    await sock.sendMessage(from, {
      text: `╭──「 🔴 *SONDAGE CLÔTURÉ* 」\n│  ❓ *${poll.question}*\n│  👥 ${total} vote(s)\n╰──────────────────────\n\n${bars.join("\n\n")}\n\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n🏆 *Gagnant(s)* : ${winners.join(", ")}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬`
    }, { quoted: msg });
  },
};

export default pollCommands;
