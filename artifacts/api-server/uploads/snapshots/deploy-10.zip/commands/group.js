// ── AXTERIS MD — GROUPE ──────────────────
// kick add prm dem mute unm tag kall link rev
import config from "../config.js";
import { isAdmin, isBotAdmin, errMsg, sleep } from "../lib/utils.js";

const p = config.prefix;

const groupCommands = {

  kick: async (sock, msg, args, { sender, groupMetadata, botJid }) => {
    const from = msg.key.remoteJid;
    if (!groupMetadata) return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    if (!isAdmin(groupMetadata, sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    if (!isBotAdmin(groupMetadata, botJid)) return sock.sendMessage(from, { text: errMsg("Je dois être admin.") }, { quoted: msg });
    const m = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!m.length) return sock.sendMessage(from, { text: errMsg(`Mentionne un utilisateur`) }, { quoted: msg });
    for (const jid of m) await sock.groupParticipantsUpdate(from, [jid], "remove");
    await sock.sendMessage(from, { text: `✅ *${m.length}* membre(s) expulsé(s).` }, { quoted: msg });
  },

  add: async (sock, msg, args, { sender, groupMetadata, botJid }) => {
    const from = msg.key.remoteJid;
    if (!groupMetadata) return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    if (!isAdmin(groupMetadata, sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    if (!isBotAdmin(groupMetadata, botJid)) return sock.sendMessage(from, { text: errMsg("Je dois être admin.") }, { quoted: msg });
    if (!args[0]) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}add 32471234567\``) }, { quoted: msg });
    await sock.groupParticipantsUpdate(from, [`${args[0].replace(/[^0-9]/g,"")}@s.whatsapp.net`], "add");
    await sock.sendMessage(from, { text: "✅ Membre ajouté." }, { quoted: msg });
  },

  prm: async (sock, msg, args, { sender, groupMetadata, botJid }) => {
    const from = msg.key.remoteJid;
    if (!groupMetadata) return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    if (!isAdmin(groupMetadata, sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    if (!isBotAdmin(groupMetadata, botJid)) return sock.sendMessage(from, { text: errMsg("Je dois être admin.") }, { quoted: msg });
    const m = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!m.length) return sock.sendMessage(from, { text: errMsg("Mentionne un utilisateur.") }, { quoted: msg });
    await sock.groupParticipantsUpdate(from, m, "promote");
    await sock.sendMessage(from, { text: "👑 Promu(s) admin!" }, { quoted: msg });
  },

  dem: async (sock, msg, args, { sender, groupMetadata, botJid }) => {
    const from = msg.key.remoteJid;
    if (!groupMetadata) return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    if (!isAdmin(groupMetadata, sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    if (!isBotAdmin(groupMetadata, botJid)) return sock.sendMessage(from, { text: errMsg("Je dois être admin.") }, { quoted: msg });
    const m = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!m.length) return sock.sendMessage(from, { text: errMsg("Mentionne un admin.") }, { quoted: msg });
    await sock.groupParticipantsUpdate(from, m, "demote");
    await sock.sendMessage(from, { text: "✅ Rétrogradé(s)." }, { quoted: msg });
  },

  mute: async (sock, msg, args, { sender, groupMetadata, botJid }) => {
    const from = msg.key.remoteJid;
    if (!groupMetadata) return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    if (!isAdmin(groupMetadata, sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    if (!isBotAdmin(groupMetadata, botJid)) return sock.sendMessage(from, { text: errMsg("Je dois être admin.") }, { quoted: msg });
    await sock.groupSettingUpdate(from, "announcement");
    await sock.sendMessage(from, { text: "🔇 *Groupe fermé.* Seuls les admins peuvent écrire." }, { quoted: msg });
  },

  unm: async (sock, msg, args, { sender, groupMetadata, botJid }) => {
    const from = msg.key.remoteJid;
    if (!groupMetadata) return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    if (!isAdmin(groupMetadata, sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    if (!isBotAdmin(groupMetadata, botJid)) return sock.sendMessage(from, { text: errMsg("Je dois être admin.") }, { quoted: msg });
    await sock.groupSettingUpdate(from, "not_announcement");
    await sock.sendMessage(from, { text: "🔊 *Groupe ouvert.*" }, { quoted: msg });
  },

  tag: async (sock, msg, args, { sender, groupMetadata }) => {
    const from = msg.key.remoteJid;
    if (!groupMetadata) return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    if (!isAdmin(groupMetadata, sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    const participants = groupMetadata.participants.map(p => p.id);
    const total        = participants.length;
    const custom       = args.join(" ") || "📢 Attention tout le monde!";
    const lines        = participants.map((j,i) => `  ${String(i+1).padStart(2,"0")}. @${j.split("@")[0]}`).join("\n");
    await sock.sendMessage(from, {
      text: `╭──「 📢 *TAG ALL — ${total} membres* 」\n│  ${custom}\n╰──────────────────\n\n${lines}`,
      mentions: participants,
    }, { quoted: msg });
  },

  kall: async (sock, msg, args, { sender, groupMetadata, botJid }) => {
    const from = msg.key.remoteJid;
    if (!groupMetadata) return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    if (!isAdmin(groupMetadata, sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    if (!isBotAdmin(groupMetadata, botJid)) return sock.sendMessage(from, { text: errMsg("Je dois être admin.") }, { quoted: msg });
    if (args[0]?.toLowerCase() !== "ok") return sock.sendMessage(from, {
      text: `╭──「 ⚠️ *KICKALL* 」\n│\n│  Tape \`${p}kall ok\` pour confirmer\n│  ⚠️ Expulse TOUS les non-admins!\n│\n╰──────────────────────`
    }, { quoted: msg });
    const toKick = groupMetadata.participants.filter(p => {
      const adm = p.admin === "admin" || p.admin === "superadmin";
      return !adm && p.id !== botJid && p.id !== sender;
    }).map(p => p.id);
    if (!toKick.length) return sock.sendMessage(from, { text: "ℹ️ Aucun membre non-admin." }, { quoted: msg });
    await sock.sendMessage(from, { text: `⏳ Expulsion de *${toKick.length}* membres...` }, { quoted: msg });
    let done = 0;
    for (let i = 0; i < toKick.length; i += 5) {
      try { await sock.groupParticipantsUpdate(from, toKick.slice(i, i+5), "remove"); done += Math.min(5, toKick.length-i); } catch {}
      if (i + 5 < toKick.length) await sleep(1500);
    }
    await sock.sendMessage(from, { text: `✅ *${done}* membre(s) expulsé(s).` }, { quoted: msg });
  },

  link: async (sock, msg, args, { groupMetadata }) => {
    const from = msg.key.remoteJid;
    if (!groupMetadata) return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    const code = await sock.groupInviteCode(from);
    await sock.sendMessage(from, { text: `╭──「 🔗 *LIEN DU GROUPE* 」\n│\n│  https://chat.whatsapp.com/${code}\n│\n╰──────────────────────` }, { quoted: msg });
  },

  rev: async (sock, msg, args, { sender, groupMetadata }) => {
    const from = msg.key.remoteJid;
    if (!groupMetadata) return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    if (!isAdmin(groupMetadata, sender)) return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    await sock.groupRevokeInvite(from);
    await sock.sendMessage(from, { text: "⛔ Lien révoqué. Nouveau lien généré." }, { quoted: msg });
  },
};

export default groupCommands;
