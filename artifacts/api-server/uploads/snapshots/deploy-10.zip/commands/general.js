// ── AXTERIS MD — GÉNÉRAL ──────────────────
import config from "../config.js";

export const TERMINAL_BANNER =
`\x1b[36m
 █████╗ ██╗  ██╗████████╗███████╗██████╗ ██╗███████╗
██╔══██╗╚██╗██╔╝╚══██╔══╝██╔════╝██╔══██╗██║██╔════╝
███████║ ╚███╔╝    ██║   █████╗  ██████╔╝██║███████╗
██╔══██║ ██╔██╗    ██║   ██╔══╝  ██╔══██╗██║╚════██║
██║  ██║██╔╝╚██╗   ██║   ███████╗██║  ██║██║███████║
╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝╚══════╝\x1b[33m
  ███╗   ███╗██████╗
  ████╗ ████║██╔══██╗
  ██╔████╔██║██║  ██║
  ██║╚██╔╝██║██║  ██║
  ██║ ╚═╝ ██║██████╔╝
  ╚═╝     ╚═╝╚═════╝   v${config.botVersion}\x1b[0m`;

const SEP  = "┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄";
const LINE = "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬";

const generalCommands = {

  menu: async (sock, msg, args, { sender }) => {
    const from = msg.key.remoteJid;
    const name = msg.pushName || sender.split("@")[0];
    const hr   = new Date().getHours();
    const sal  = hr<5?"🌙 Bonne nuit":hr<12?"🌅 Bonjour":hr<18?"☀️ Bon après-midi":"🌆 Bonsoir";
    const up   = process.uptime();
    const p    = config.prefix;
    const hUp  = Math.floor(up/3600), mUp = Math.floor((up%3600)/60);

    const text =
`╔╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╦╗
╠╣   ░▒▓  *A X T E R I S*  ▓▒░  ╠╣
╠╣        *M  D*  v${config.botVersion}        ╠╣
╚╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╩╝

${LINE}
${sal}, *${name}* 👋
${LINE}

╭──「 🤖 *BOT INFO* 」
│  ◈ *Préfixe* › \`${p}\`
│  ◈ *Uptime*  › ${hUp}h ${mUp}m
│  ◈ *Owner*   › ${config.ownerName}
╰──────────────────────────

${SEP}
   📌  *G É N É R A L*
${SEP}
  ➤ \`${p}menu\` ➤ \`${p}ping\`
  ➤ \`${p}info\` ➤ \`${p}own\`

${SEP}
   🎵  *T É L É C H A R G E M E N T S*
${SEP}
  ➤ \`${p}play\` ─ Audio YouTube par titre
  ➤ \`${p}yt\`   ─ YouTube URL mp3/mp4
  ➤ \`${p}tt\`   ─ TikTok
  ➤ \`${p}ig\`   ─ Instagram
  ➤ \`${p}fb\`   ─ Facebook
  ➤ \`${p}tw\`   ─ Twitter/X
  ➤ \`${p}spot\` ─ Spotify
  ➤ \`${p}sc\`   ─ SoundCloud
  ➤ \`${p}pin\`  ─ Pinterest
  ➤ \`${p}lyr\`  ─ Paroles chanson
  ➤ \`${p}shaz\` ─ Identifier musique

${SEP}
   🖼️  *M É D I A S & O U T I L S*
${SEP}
  ➤ \`${p}stk\`  ─ Image/vidéo → sticker
  ➤ \`${p}ss\`   ─ Screenshot site web
  ➤ \`${p}qr\`   ─ Créer QR code
  ➤ \`${p}rqr\`  ─ Lire QR code
  ➤ \`${p}ocr\`  ─ Lire texte image
  ➤ \`${p}bg\`   ─ Supprimer fond photo
  ➤ \`${p}hd\`   ─ Améliorer photo (Remini)
  ➤ \`${p}up\`   ─ Améliorer résolution
  ➤ \`${p}ttp\`  ─ Texte → sticker
  ➤ \`${p}tts\`  ─ Texte → voix
  ➤ \`${p}mx\`   ─ Fusionner 2 emojis
  ➤ \`${p}code\` ─ Image de code (Carbon)

${SEP}
   🔧  *U T I L I T A I R E S*
${SEP}
  ➤ \`${p}calc\` ─ Calculatrice
  ➤ \`${p}trad\` ─ Traduction
  ➤ \`${p}meteo\` ─ Météo ville
  ➤ \`${p}time\` ─ Heure ville
  ➤ \`${p}url\`  ─ Raccourcir lien
  ➤ \`${p}def\`  ─ Définition mot
  ➤ \`${p}news\` ─ Actualités
  ➤ \`${p}wiki\` ─ Recherche Wikipedia
  ➤ \`${p}b64e\` ─ Encoder Base64
  ➤ \`${p}b64d\` ─ Décoder Base64
  ➤ \`${p}bine\` ─ Encoder Binaire
  ➤ \`${p}bind\` ─ Décoder Binaire

${SEP}
   🎲  *F U N*
${SEP}
  ➤ \`${p}joke\` ─ Blague
  ➤ \`${p}dare\` ─ Défi
  ➤ \`${p}true\` ─ Vérité
  ➤ \`${p}adv\`  ─ Conseil
  ➤ \`${p}mot\`  ─ Motivation
  ➤ \`${p}luv\`  ─ Message amour
  ➤ \`${p}flrt\` ─ Flirt
  ➤ \`${p}pick\` ─ Pickup line
  ➤ \`${p}gdnt\` ─ Bonne nuit
  ➤ \`${p}fact\` ─ Fait aléatoire
  ➤ \`${p}qt\`   ─ Citation
  ➤ \`${p}hb\`   ─ Peine de coeur
  ➤ \`${p}coin\` ─ Pile ou face
  ➤ \`${p}8bl\`  ─ Boule magique

${SEP}
   📊  *S O N D A G E*
${SEP}
  ➤ \`${p}poll\` ─ Créer sondage
  ➤ \`${p}vote\` ─ Voter
  ➤ \`${p}pres\` ─ Résultats
  ➤ \`${p}pend\` ─ Clôturer

${SEP}
   🎌  *A N I M E*
${SEP}
  ➤ \`${p}neko\` ─ Image neko
  ➤ \`${p}waifu\` ─ Image waifu
  ➤ \`${p}aq\`  ─ Citation anime
  ➤ \`${p}ani\` ─ Info anime aléatoire
  ➤ \`${p}mng\` ─ Recherche manga

${SEP}
   ⚽  *S P O R T S*
${SEP}
  ➤ \`${p}live\` ─ Scores en direct
  ➤ \`${p}pred\` ─ Prédictions foot
  ➤ \`${p}epl\`  ─ Premier League
  ➤ \`${p}liga\` ─ La Liga
  ➤ \`${p}bun\`  ─ Bundesliga
  ➤ \`${p}sa\`   ─ Serie A
  ➤ \`${p}l1\`   ─ Ligue 1
  ➤ \`${p}ucl\`  ─ Champions League

${SEP}
   🕵️  *S T A L K E R & T E M P*
${SEP}
  ➤ \`${p}git\`  ─ Profil GitHub
  ➤ \`${p}ttk\`  ─ Profil TikTok
  ➤ \`${p}igs\`  ─ Profil Instagram
  ➤ \`${p}tws\`  ─ Profil Twitter/X
  ➤ \`${p}ip\`   ─ Info adresse IP
  ➤ \`${p}tmail\` ─ Email temporaire
  ➤ \`${p}tinb\`  ─ Boîte email temp
  ➤ \`${p}tnum\`  ─ Numéro temporaire
  ➤ \`${p}sms\`   ─ SMS reçus

${SEP}
   👥  *G R O U P E*
${SEP}
  ➤ \`${p}kick\` ➤ \`${p}add\`
  ➤ \`${p}prm\`  ➤ \`${p}dem\`
  ➤ \`${p}mute\` ➤ \`${p}unm\`
  ➤ \`${p}tag\`  ➤ \`${p}kall\`
  ➤ \`${p}link\` ➤ \`${p}rev\`

${SEP}
   🛡️  *S É C U R I T É*
${SEP}
  ➤ \`${p}spam\` ➤ \`${p}aln\`
  ➤ \`${p}warn\` ➤ \`${p}uwrn\`
  ➤ \`${p}wls\`  ➤ \`${p}ban\`
  ➤ \`${p}ubn\`

${SEP}
   🧠  *I N T E L L I G E N C E  A R T I F I C I E L L E*
${SEP}
  ➤ \`${p}ai\`   ─ Axteris IA (GiftedTech)
  ➤ \`${p}gpt\`  ─ GPT-4o
  ➤ \`${p}gem\`  ─ Google Gemini
  ➤ \`${p}dsk\`  ─ DeepSeek
  ➤ \`${p}img\`  ─ Générer image AI
  ➤ \`${p}clr\`  ─ Réinitialiser IA

${LINE}
> 🚀 *Axteris MD* — _Powered by GiftedTech Premium_
${LINE}`;

    await sock.sendMessage(from, { text }, { quoted: msg });
  },

  help: async (sock, msg, args, ctx) => generalCommands.menu(sock, msg, args, ctx),

  ping: async (sock, msg) => {
    const from = msg.key.remoteJid;
    const t    = Date.now();
    await sock.sendMessage(from, { text: "_⏱️..._" }, { quoted: msg });
    await sock.sendMessage(from, {
      text: `╭──「 🏓 *PONG!* 」\n│  ⚡ *${Date.now()-t} ms*\n│  ✅ En ligne\n╰──────────────────`
    }, { quoted: msg });
  },

  info: async (sock, msg) => {
    const up = process.uptime();
    const h  = Math.floor(up/3600), m = Math.floor((up%3600)/60), s = Math.floor(up%60);
    await sock.sendMessage(msg.key.remoteJid, {
      text: `╭──「 🤖 *AXTERIS MD* 」\n│  ◈ *Version* › v${config.botVersion}\n│  ◈ *Préfixe* › \`${config.prefix}\`\n│  ◈ *Owner*   › ${config.ownerName}\n│  ◈ *Uptime*  › ${h}h ${m}m ${s}s\n│  ◈ *Node.js* › ${process.version}\n╰──────────────────────────`
    }, { quoted: msg });
  },

  own: async (sock, msg) => {
    const ownerJid = `${config.ownerNumber}@s.whatsapp.net`;
    await sock.sendMessage(msg.key.remoteJid, {
      text: `╭──「 👑 *PROPRIÉTAIRE* 」\n│  ◈ *Nom*  › ${config.ownerName}\n│  ◈ *Lien* › wa.me/${config.ownerNumber}\n╰──────────────────────────`,
      mentions: [ownerJid]
    }, { quoted: msg });
  },
};

export default generalCommands;
