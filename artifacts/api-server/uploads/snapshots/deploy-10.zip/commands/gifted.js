// ── Helper GiftedTech Premium ─────────────
import axios  from "axios";
import config from "../config.js";

export const KEY  = config.giftedApiKey;
export const BASE = "https://api.giftedtech.co.ke";

export async function g(ep, params = {}, type = "json") {
  const r = await axios.get(`${BASE}${ep}`, {
    params:       { apikey: KEY, ...params },
    responseType: type,
    timeout:      45000,
    headers:      { "User-Agent": "Axteris-MD/1.0" },
  });
  return r.data;
}

export async function gBuf(ep, params = {}) {
  return g(ep, params, "arraybuffer").then(d => Buffer.from(d));
}

// Extraire l'URL du résultat
export function url(r) {
  if (!r) return null;
  if (typeof r === "string" && r.startsWith("http")) return r;
  return r.download_url || r.url || r.link || r.audio ||
         r.video || r.file_url || r.image || r.result || null;
}

// Extraire le texte du résultat
export function txt(r) {
  if (!r) return null;
  if (typeof r === "string" && r.length > 1) return r;
  return r.joke || r.advice || r.dare || r.quote || r.truth ||
         r.motivation || r.love || r.heartbreak || r.pickup ||
         r.message || r.text || r.result || r.content || r.flirt ||
         r.goodnight || r.friendship || r.fact || null;
}
