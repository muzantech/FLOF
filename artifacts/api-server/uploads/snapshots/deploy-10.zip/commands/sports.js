// ── AXTERIS MD — SPORTS ──────────────────
// live pred epl liga bun sa l1 ucl
import { g } from "./gifted.js";
import { errMsg } from "../lib/utils.js";
import config from "../config.js";

const p = config.prefix;

function fmtS(teams, league) {
  if (!teams?.length) return "Aucune donnée.";
  let t = `╭──「 🏆 *${league} CLASSEMENT* 」\n│\n`;
  teams.slice(0,10).forEach((tm,i) => {
    const pos  = tm.position || tm.rank || (i+1);
    const name = (tm.team || tm.name || tm.club || "?").slice(0,16).padEnd(16);
    const pts  = tm.points || tm.pts || "?";
    t += `│  *${String(pos).padStart(2)}*. ${name} ${pts}pts\n`;
  });
  return t + `│\n╰──────────────────────────────`;
}

function fmtM(matches, league, type = "") {
  if (!matches?.length) return `Aucun match.`;
  let t = `╭──「 📅 *${league}${type?" — "+type:""}* 」\n│\n`;
  matches.slice(0,8).forEach(m => {
    const home  = (m.home_team || m.home || m.homeTeam || "?").slice(0,10);
    const away  = (m.away_team || m.away || m.awayTeam || "?").slice(0,10);
    const score = m.score || m.result || (m.home_score!=null ? `${m.home_score}-${m.away_score}` : "vs");
    t += `│  ${home} *${score}* ${away}\n`;
  });
  return t + `│\n╰──────────────────────────────`;
}

async function leagueCmd(sock, msg, sub, eps, name) {
  const from = msg.key.remoteJid;
  try {
    const key = ["scor","scores","buteurs","top"].includes(sub?.toLowerCase()) ? "scorers"
              : ["match","matches","results"].includes(sub?.toLowerCase()) ? "matches"
              : ["up","upcoming","next","prochain"].includes(sub?.toLowerCase()) ? "upcoming"
              : "standings";
    const ep  = eps[key] || eps.standings;
    const d   = await g(ep);
    const res = d?.result || [];
    if (key === "standings") await sock.sendMessage(from, { text: fmtS(res, name) }, { quoted: msg });
    else await sock.sendMessage(from, { text: fmtM(res, name, key === "upcoming" ? "À Venir" : "Matchs") }, { quoted: msg });
  } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
}

const sportsCommands = {

  // .live — Scores en direct
  live: async (sock, msg) => {
    const from = msg.key.remoteJid;
    await sock.sendMessage(from, { text: "⚽ Scores en direct..." }, { quoted: msg });
    try {
      let matches = null;
      for (const ep of ["/api/sports/football/livescore","/api/sports/football/livescore2"]) {
        try { const d = await g(ep); matches = d?.result || d?.data || d?.matches; if (matches?.length) break; } catch {}
      }
      if (!matches?.length) return sock.sendMessage(from, { text: "ℹ️ Aucun match en direct." }, { quoted: msg });
      let text = `╭──「 🔴 *LIVE SCORES* 」\n│\n`;
      (Array.isArray(matches) ? matches : []).slice(0,10).forEach(m => {
        const home  = (m.home_team || m.home || "?").slice(0,10);
        const away  = (m.away_team || m.away || "?").slice(0,10);
        const score = m.score || m.result || (m.home_score!=null ? `${m.home_score}-${m.away_score}` : "vs");
        const min   = m.minute || m.time || m.elapsed || "";
        text += `│  ${home} *${score}* ${away}${min ? ` ⏱️${min}'` : ""}\n`;
      });
      text += `│\n╰──────────────────────────────\n> _En temps réel_`;
      await sock.sendMessage(from, { text }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .pred — Prédictions
  pred: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    await sock.sendMessage(from, { text: "🔮 Prédictions..." }, { quoted: msg });
    try {
      const date  = args[0] || new Date().toISOString().split("T")[0];
      const data  = await g("/api/sports/football/predictions", { date });
      const preds = data?.result || data?.predictions || [];
      const list  = (Array.isArray(preds) ? preds : []).slice(0, 8);
      if (!list.length) return sock.sendMessage(from, { text: "ℹ️ Aucune prédiction." }, { quoted: msg });
      let text = `╭──「 🔮 *PRÉDICTIONS — ${date}* 」\n│\n`;
      list.forEach((p, i) => {
        const home = (p.home_team || p.home || "?").slice(0,10);
        const away = (p.away_team || p.away || "?").slice(0,10);
        const pred = p.prediction || p.winner || p.tip || "?";
        text += `│  *${i+1}*. ${home} vs ${away}\n│     💡 ${pred}\n│\n`;
      });
      text += "╰──────────────────────────────";
      await sock.sendMessage(from, { text }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .epl [scor/match/up] — Premier League
  epl: async (sock, msg, args) => leagueCmd(sock, msg, args[0], {
    standings: "/api/sports/football/eplstandings",
    scorers:   "/api/sports/football/eplscorers",
    matches:   "/api/sports/football/eplmatches",
    upcoming:  "/api/sports/football/eplupcoming",
  }, "🏴󠁧󠁢󠁥󠁮󠁧󠁿 EPL"),

  // .liga — La Liga
  liga: async (sock, msg, args) => leagueCmd(sock, msg, args[0], {
    standings: "/api/sports/football/laligastandings",
    scorers:   "/api/sports/football/laligascorers",
    matches:   "/api/sports/football/laligamatches",
    upcoming:  "/api/sports/football/laligaupcoming",
  }, "🇪🇸 La Liga"),

  // .bun — Bundesliga
  bun: async (sock, msg, args) => leagueCmd(sock, msg, args[0], {
    standings: "/api/sports/football/bundesligastandings",
    scorers:   "/api/sports/football/bundesligascorers",
    matches:   "/api/sports/football/bundesligamatches",
    upcoming:  "/api/sports/football/bundesligaupcoming",
  }, "🇩🇪 Bundesliga"),

  // .sa — Serie A
  sa: async (sock, msg, args) => leagueCmd(sock, msg, args[0], {
    standings: "/api/sports/football/serieastandings",
    scorers:   "/api/sports/football/serieascorers",
    matches:   "/api/sports/football/serieamatches",
    upcoming:  "/api/sports/football/serieaupcoming",
  }, "🇮🇹 Serie A"),

  // .l1 — Ligue 1
  l1: async (sock, msg, args) => leagueCmd(sock, msg, args[0], {
    standings: "/api/sports/football/ligue1standings",
    scorers:   "/api/sports/football/ligue1scorers",
    matches:   "/api/sports/football/ligue1matches",
    upcoming:  "/api/sports/football/ligue1upcoming",
  }, "🇫🇷 Ligue 1"),

  // .ucl — Champions League
  ucl: async (sock, msg, args) => leagueCmd(sock, msg, args[0], {
    standings: "/api/sports/football/uclstandings",
    scorers:   "/api/sports/football/uclscorers",
    matches:   "/api/sports/football/uclmatches",
    upcoming:  "/api/sports/football/uclupcoming",
  }, "⭐ UCL"),
};

export default sportsCommands;
