// ── AXTERIS MD — MÉDIAS & DOWNLOADS ──────
// play yt tt ig fb tw spot sc pin lyr shaz stk ss
import axios from "axios";
import fs    from "fs";
import path  from "path";
import { exec } from "child_process";
import { downloadMediaMessage } from "@whiskeysockets/baileys";
import { g, gBuf, KEY, BASE } from "./gifted.js";
import { errMsg, log } from "../lib/utils.js";
import config from "../config.js";

const p    = config.prefix;
const TEMP = "./temp";
if (!fs.existsSync(TEMP)) fs.mkdirSync(TEMP, { recursive: true });

function getUrl(r) {
  if (!r) return null;
  if (typeof r === "string" && r.startsWith("http")) return r;
  return r.download_url || r.url || r.link || r.audio || r.video || r.file_url || null;
}

// ── YouTube Audio avec fallback ─────────
async function ytAudio(url) {
  for (const ep of [
    "/api/download/ytmp3",
    "/api/download/ytaudio",
    "/api/download/dlmp3",
    "/api/download/savenowmp3",
    "/api/download/yta",
  ]) {
    try {
      const d = await g(ep, { url, quality: "128" });
      const u = getUrl(d?.result);
      if (u) return u;
    } catch {}
  }
  return null;
}

// ── YouTube Vidéo avec fallback ─────────
async function ytVideo(url) {
  for (const ep of [
    "/api/download/ytmp4",
    "/api/download/ytvideo",
    "/api/download/dlmp4",
    "/api/download/savenowmp4",
    "/api/download/ytv",
  ]) {
    try {
      const d = await g(ep, { url, quality: "360" });
      const u = getUrl(d?.result);
      if (u) return u;
    } catch {}
  }
  return null;
}

// ── Recherche YouTube ───────────────────
async function ytSearch(q) {
  try {
    const d = await g("/api/search/youtube", { query: q });
    const list = d?.result;
    const v = Array.isArray(list) ? list[0] : list?.videos?.[0] || list;
    if (v?.url || v?.link) return { url: v.url || v.link, title: v.title || q, dur: v.duration || "??" };
  } catch {}
  try {
    const yts = (await import("yt-search")).default;
    const v   = (await yts(q)).videos?.[0];
    if (v) return { url: v.url, title: v.title, dur: v.timestamp };
  } catch {}
  return null;
}

const mediaCommands = {

  // .play — YouTube par titre (audio)
  play: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const q    = args.join(" ").trim();
    if (!q) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}play Titre\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: `🔍 Recherche *${q}*...` }, { quoted: msg });
    try {
      let videoUrl = q, title = q, dur = "??";
      if (!q.match(/youtu/i)) {
        const v = await ytSearch(q);
        if (!v) return sock.sendMessage(from, { text: errMsg("Aucun résultat.") }, { quoted: msg });
        videoUrl = v.url; title = v.title; dur = v.dur;
      }
      await sock.sendMessage(from, { text: `🎵 *${title}* (${dur})\n⏳ Téléchargement...` }, { quoted: msg });
      const dlUrl = await ytAudio(videoUrl);
      if (!dlUrl) throw new Error("Toutes les APIs sont indisponibles.");
      await sock.sendMessage(from, { audio: { url: dlUrl }, mimetype: "audio/mpeg" }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .yt <url> [mp3/mp4] — YouTube URL
  yt: async (sock, msg, args) => {
    const from   = msg.key.remoteJid;
    const url    = args[0];
    const format = args[1]?.toLowerCase() === "mp4" ? "mp4" : "mp3";
    if (!url) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}yt <URL> mp3\` ou \`mp4\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: `⏳ Téléchargement ${format.toUpperCase()}...` }, { quoted: msg });
    try {
      const dlUrl = format === "mp4" ? await ytVideo(url) : await ytAudio(url);
      if (!dlUrl) throw new Error("APIs indisponibles.");
      if (format === "mp4") {
        await sock.sendMessage(from, { video: { url: dlUrl }, mimetype: "video/mp4", caption: "_Axteris MD_" }, { quoted: msg });
      } else {
        await sock.sendMessage(from, { audio: { url: dlUrl }, mimetype: "audio/mpeg" }, { quoted: msg });
      }
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .tt — TikTok
  tt: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const url  = args[0];
    if (!url || !url.includes("tiktok")) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}tt <URL TikTok>\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: "⏳ TikTok..." }, { quoted: msg });
    try {
      let res = null;
      for (const ep of ["/api/download/tiktok","/api/download/tiktokdlv2","/api/download/tiktokdlv3","/api/download/tiktokdlv4","/api/download/tiktokdlv5"]) {
        try {
          const d = await g(ep, { url });
          const r = d?.result;
          const v = r?.video?.noWatermark || r?.nowm || getUrl(r?.video) || getUrl(r);
          if (v) { res = { video: v, title: r?.title || "TikTok", author: r?.author?.nickname || r?.author || "?" }; break; }
        } catch {}
      }
      if (!res) throw new Error("APIs TikTok indisponibles.");
      await sock.sendMessage(from, {
        video: { url: res.video },
        caption: `🎵 *${res.title}*\n👤 ${res.author}\n\n_Axteris MD_`
      }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .ig — Instagram
  ig: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const url  = args[0];
    if (!url || !url.includes("instagram")) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}ig <URL Instagram>\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: "⏳ Instagram..." }, { quoted: msg });
    try {
      let vUrl = null;
      for (const ep of ["/api/download/instadl","/api/download/instadlv2"]) {
        try { const d = await g(ep, { url }); vUrl = getUrl(d?.result); if (vUrl) break; } catch {}
      }
      if (!vUrl) throw new Error("Impossible de télécharger.");
      await sock.sendMessage(from, { video: { url: vUrl }, caption: "📸 *Instagram*\n\n_Axteris MD_" }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .fb — Facebook
  fb: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const url  = args[0];
    if (!url || !url.includes("facebook")) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}fb <URL Facebook>\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: "⏳ Facebook..." }, { quoted: msg });
    try {
      let vUrl = null;
      for (const ep of ["/api/download/facebook","/api/download/facebookv2","/api/download/facebookv3"]) {
        try { const d = await g(ep, { url }); vUrl = getUrl(d?.result); if (vUrl) break; } catch {}
      }
      if (!vUrl) throw new Error("Impossible de télécharger.");
      await sock.sendMessage(from, { video: { url: vUrl }, caption: "📘 *Facebook*\n\n_Axteris MD_" }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .tw — Twitter/X
  tw: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const url  = args[0];
    if (!url || (!url.includes("twitter") && !url.includes("x.com"))) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}tw <URL Twitter/X>\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: "⏳ Twitter/X..." }, { quoted: msg });
    try {
      let vUrl = null;
      for (const ep of ["/api/download/twitterdl","/api/download/twitterdlv2"]) {
        try { const d = await g(ep, { url }); vUrl = getUrl(d?.result); if (vUrl) break; } catch {}
      }
      if (!vUrl) throw new Error("Impossible de télécharger.");
      await sock.sendMessage(from, { video: { url: vUrl }, caption: "🐦 *Twitter/X*\n\n_Axteris MD_" }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .spot — Spotify
  spot: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const url  = args[0];
    if (!url || !url.includes("spotify")) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}spot <URL Spotify>\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: "🎵 Spotify..." }, { quoted: msg });
    try {
      let aUrl = null;
      for (const ep of ["/api/download/spotifydl","/api/download/spotifydlv2","/api/download/spotifydlv3","/api/download/spotifydlv4"]) {
        try { const d = await g(ep, { url }); aUrl = getUrl(d?.result); if (aUrl) break; } catch {}
      }
      if (!aUrl) throw new Error("APIs Spotify indisponibles.");
      await sock.sendMessage(from, { audio: { url: aUrl }, mimetype: "audio/mpeg" }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .sc — SoundCloud
  sc: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const url  = args[0];
    if (!url || !url.includes("soundcloud")) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}sc <URL SoundCloud>\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: "🎧 SoundCloud..." }, { quoted: msg });
    try {
      const d    = await g("/api/download/soundclouddl", { url });
      const aUrl = getUrl(d?.result);
      if (!aUrl) throw new Error("Impossible de télécharger.");
      await sock.sendMessage(from, { audio: { url: aUrl }, mimetype: "audio/mpeg" }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .pin — Pinterest
  pin: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const url  = args[0];
    if (!url || !url.includes("pinterest")) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}pin <URL Pinterest>\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: "📌 Pinterest..." }, { quoted: msg });
    try {
      let mUrl = null;
      for (const ep of ["/api/download/pinterest","/api/download/pinterestdlv2","/api/download/pinterestdlv3","/api/download/pinterestdlv4"]) {
        try { const d = await g(ep, { url }); mUrl = getUrl(d?.result); if (mUrl) break; } catch {}
      }
      if (!mUrl) throw new Error("Impossible de télécharger.");
      const isVid = mUrl.includes(".mp4") || mUrl.includes("video");
      if (isVid) {
        await sock.sendMessage(from, { video: { url: mUrl }, caption: "📌 *Pinterest*\n\n_Axteris MD_" }, { quoted: msg });
      } else {
        await sock.sendMessage(from, { image: { url: mUrl }, caption: "📌 *Pinterest*\n\n_Axteris MD_" }, { quoted: msg });
      }
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .lyr — Paroles
  lyr: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const song = args.join(" ").trim();
    if (!song) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}lyr Shape of You\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: `🔍 Paroles de *${song}*...` }, { quoted: msg });
    try {
      let lyr = null;
      for (const ep of ["/api/search/lyrics","/api/search/lyricsv2"]) {
        try { const d = await g(ep, { query: song }); lyr = d?.result?.lyrics || (typeof d?.result === "string" ? d.result : null); if (lyr) break; } catch {}
      }
      if (!lyr) throw new Error(`Aucune parole pour "${song}".`);
      const out = lyr.length > 4000 ? lyr.slice(0, 3997) + "..." : lyr;
      await sock.sendMessage(from, {
        text: `╭──「 🎵 *PAROLES — ${song.toUpperCase()}* 」\n╰──────────────────────\n\n${out}\n\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬`
      }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .shaz — Identifier musique
  shaz: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const url  = args[0];
    if (!url) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}shaz <URL audio/vidéo>\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: "🎵 Identification..." }, { quoted: msg });
    try {
      const d = await g("/api/search/shazam", { url });
      const r = d?.result;
      if (!r) throw new Error("Aucune musique identifiée.");
      await sock.sendMessage(from, {
        text: `╭──「 🎵 *SHAZAM* 」\n│\n│  🎤 *Titre*   : ${r.title || r.track || "?"}\n│  👤 *Artiste* : ${r.artist || r.subtitle || "?"}\n${r.album ? `│  💿 *Album*   : ${r.album}\n` : ""}│\n╰──────────────────────`
      }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .stk — Image/vidéo → sticker
  stk: async (sock, msg, args, { sender }) => {
    const from   = msg.key.remoteJid;
    let target   = msg;
    if (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
      const q = msg.message.extendedTextMessage.contextInfo;
      target  = { key: { remoteJid: from, id: q.stanzaId, participant: q.participant }, message: q.quotedMessage };
    }
    const mediaMsg = target.message?.imageMessage || target.message?.videoMessage || target.message?.documentMessage;
    if (!mediaMsg) return sock.sendMessage(from, {
      text: `╭──「 🖼️ *STICKER* 」\n│\n│  Envoie ou cite une image/vidéo\n│  puis tape \`${p}stk\`\n│\n╰──────────────────────`
    }, { quoted: msg });
    try {
      const buf = await downloadMediaMessage(target, "buffer", {}, { reuploadRequest: sock.updateMediaMessage });
      if (!buf) throw new Error("Impossible de télécharger.");
      const inp = path.join(TEMP, `i_${Date.now()}`);
      const out = path.join(TEMP, `s_${Date.now()}.webp`);
      fs.writeFileSync(inp, buf);
      const anim = mediaMsg.mimetype?.includes("video") || mediaMsg.mimetype?.includes("gif") || (mediaMsg.seconds > 0);
      const cmd  = anim
        ? `ffmpeg -y -i "${inp}" -vf "scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" -loop 0 -c:v libwebp -an -vsync 0 -pix_fmt yuva420p -quality 70 "${out}"`
        : `ffmpeg -y -i "${inp}" -vf "scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" -loop 0 -c:v libwebp -an -vsync 0 -pix_fmt yuva420p -quality 80 "${out}"`;
      await new Promise((res, rej) => exec(cmd, e => e ? rej(e) : res()));
      let fb = fs.readFileSync(out);
      try {
        const webp = (await import("node-webpmux")).default;
        const img  = new webp.Image();
        await img.load(fb);
        const meta = { "sticker-pack-name": config.botName, "sticker-pack-publisher": config.ownerName, emojis: ["🔥"] };
        const ea   = Buffer.from([0x49,0x49,0x2a,0x00,0x08,0x00,0x00,0x00,0x01,0x00,0x41,0x57,0x07,0x00,0x00,0x00,0x00,0x00,0x16,0x00,0x00,0x00]);
        const jb   = Buffer.from(JSON.stringify(meta), "utf8");
        const ex   = Buffer.concat([ea, jb]);
        ex.writeUIntLE(jb.length, 14, 4);
        img.exif = ex;
        fb = await img.save(null);
      } catch {}
      await sock.sendMessage(from, { sticker: fb }, { quoted: msg });
      try { fs.unlinkSync(inp); fs.unlinkSync(out); } catch {}
    } catch (e) { await sock.sendMessage(from, { text: errMsg(`Sticker: ${e.message}`) }, { quoted: msg }); }
  },

  // .ss — Screenshot
  ss: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const url  = args[0];
    if (!url) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}ss https://google.com\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: "📸 Screenshot..." }, { quoted: msg });
    try {
      const buf = await gBuf("/api/tools/ssweb", { url });
      await sock.sendMessage(from, { image: buf, caption: `📸 *${url}*\n\n_Axteris MD_` }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },
};

export default mediaCommands;
