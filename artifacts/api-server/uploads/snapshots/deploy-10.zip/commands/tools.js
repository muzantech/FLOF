// ── AXTERIS MD — OUTILS ──────────────────
// qr rqr ocr bg hd up ttp tts mx code
// calc trad meteo time url def news wiki
// b64e b64d bine bind fact qt
import axios from "axios";
import fs    from "fs";
import path  from "path";
import { g, gBuf } from "./gifted.js";
import { errMsg } from "../lib/utils.js";
import config from "../config.js";

const p    = config.prefix;
const TEMP = "./temp";

const toolCommands = {

  // .qr — Créer QR code
  qr: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const text = args.join(" ").trim();
    if (!text) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}qr https://example.com\``) }, { quoted: msg });
    try {
      const buf = await gBuf("/api/tools/createqr", { query: text });
      await sock.sendMessage(from, { image: buf, caption: `📱 *QR Code*\n\n_Axteris MD_` }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .rqr — Lire QR code
  rqr: async (sock, msg, args) => {
    const from   = msg.key.remoteJid;
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const imgUrl = args[0] || quoted?.imageMessage?.url;
    if (!imgUrl) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}rqr <url-image>\``) }, { quoted: msg });
    try {
      const d = await g("/api/tools/readqr", { url: imgUrl });
      await sock.sendMessage(from, { text: `╭──「 📷 *QR LU* 」\n│\n│  ${d?.result?.data || d?.result}\n│\n╰──────────────────────` }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .ocr — Lire texte image
  ocr: async (sock, msg, args) => {
    const from   = msg.key.remoteJid;
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const imgUrl = args[0] || quoted?.imageMessage?.url;
    if (!imgUrl) return sock.sendMessage(from, { text: errMsg(`Cite ou donne l'URL d'une image`) }, { quoted: msg });
    await sock.sendMessage(from, { text: "📖 Lecture du texte..." }, { quoted: msg });
    try {
      const d = await g("/api/tools/ocr", { url: imgUrl });
      const t = d?.result?.text || d?.result;
      if (!t) throw new Error("Aucun texte détecté.");
      await sock.sendMessage(from, { text: `╭──「 📖 *OCR* 」\n╰──────────────────────\n\n${t}\n\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬` }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .bg — Supprimer fond
  bg: async (sock, msg, args) => {
    const from   = msg.key.remoteJid;
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const imgUrl = args[0] || quoted?.imageMessage?.url;
    if (!imgUrl) return sock.sendMessage(from, { text: errMsg(`Cite ou donne l'URL d'une image`) }, { quoted: msg });
    await sock.sendMessage(from, { text: "🖼️ Suppression du fond..." }, { quoted: msg });
    try {
      let u = null;
      for (const ep of ["/api/tools/removebg","/api/tools/removebgv2"]) {
        try { const d = await g(ep, { url: imgUrl }); u = d?.result?.url || d?.result?.image || d?.result; if (u) break; } catch {}
      }
      if (!u) throw new Error("Pas de résultat.");
      await sock.sendMessage(from, { image: { url: u }, caption: "🖼️ *Fond supprimé*\n\n_Axteris MD_" }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .hd — Améliorer photo (Remini)
  hd: async (sock, msg, args) => {
    const from   = msg.key.remoteJid;
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const imgUrl = args[0] || quoted?.imageMessage?.url;
    if (!imgUrl) return sock.sendMessage(from, { text: errMsg(`Cite ou donne l'URL d'une image`) }, { quoted: msg });
    await sock.sendMessage(from, { text: "✨ Amélioration..." }, { quoted: msg });
    try {
      const d = await g("/api/tools/remini", { url: imgUrl });
      const u = d?.result?.url || d?.result?.image || d?.result;
      if (!u) throw new Error("Pas de résultat.");
      await sock.sendMessage(from, { image: { url: u }, caption: "✨ *Photo améliorée (Remini)*\n\n_Axteris MD_" }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .up — Améliorer résolution
  up: async (sock, msg, args) => {
    const from   = msg.key.remoteJid;
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const imgUrl = args[0] || quoted?.imageMessage?.url;
    if (!imgUrl) return sock.sendMessage(from, { text: errMsg(`Cite ou donne l'URL d'une image`) }, { quoted: msg });
    await sock.sendMessage(from, { text: "🔍 Amélioration résolution..." }, { quoted: msg });
    try {
      const d = await g("/api/tools/imageupscaler", { url: imgUrl });
      const u = d?.result?.url || d?.result?.image || d?.result;
      if (!u) throw new Error("Pas de résultat.");
      await sock.sendMessage(from, { image: { url: u }, caption: "🔍 *Résolution améliorée*\n\n_Axteris MD_" }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .ttp — Texte → sticker
  ttp: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const text = args.join(" ").trim();
    if (!text) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}ttp Ton texte\``) }, { quoted: msg });
    try {
      const d = await g("/api/tools/ttp", { query: text });
      const u = d?.result?.url || d?.result?.image || d?.result;
      if (!u) throw new Error("Pas de résultat.");
      await sock.sendMessage(from, { sticker: { url: u } }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .tts — Texte → voix
  tts: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const text = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.conversation ||
                 msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.extendedTextMessage?.text ||
                 args.join(" ").trim();
    if (!text) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}tts Bonjour\``) }, { quoted: msg });
    try {
      const { default: gTTS } = await import("node-gtts");
      const tts  = gTTS("fr");
      const fp   = path.join(TEMP, `tts_${Date.now()}.mp3`);
      if (!fs.existsSync(TEMP)) fs.mkdirSync(TEMP, { recursive: true });
      await new Promise((res, rej) => tts.save(fp, text, e => e ? rej(e) : res()));
      await sock.sendMessage(from, { audio: fs.readFileSync(fp), mimetype: "audio/mpeg", ptt: false }, { quoted: msg });
      fs.unlinkSync(fp);
    } catch (e) { await sock.sendMessage(from, { text: errMsg(`TTS: ${e.message}`) }, { quoted: msg }); }
  },

  // .mx — Fusionner 2 emojis
  mx: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    if (args.length < 2) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}mx 😀 🔥\``) }, { quoted: msg });
    try {
      const buf = await gBuf("/api/tools/emojimix", { emoji1: args[0], emoji2: args[1] });
      await sock.sendMessage(from, { image: buf, caption: `${args[0]} + ${args[1]}\n\n_Axteris MD_` }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .code — Image de code (Carbon)
  code: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const code = args.join(" ").trim() ||
      msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.conversation;
    if (!code) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}code console.log("hi")\``) }, { quoted: msg });
    try {
      const d = await g("/api/tools/carbon", { code });
      const u = d?.result?.url || d?.result?.image || d?.result;
      if (!u) throw new Error("Pas de résultat.");
      await sock.sendMessage(from, { image: { url: u }, caption: "💻 *Carbon Code*\n\n_Axteris MD_" }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .calc — Calculatrice
  calc: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const expr = args.join(" ").trim();
    if (!expr) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}calc 2+2*5\``) }, { quoted: msg });
    try {
      const clean = expr.replace(/[^0-9+\-*/().,\s]/g, "").replace(/\^/g, "**");
      // eslint-disable-next-line no-new-func
      const val = new Function(`"use strict"; return (${clean})`)();
      await sock.sendMessage(from, {
        text: `╭──「 🧮 *CALC* 」\n│  📝 ${expr}\n│  ✅ *${val}*\n╰──────────────────────`
      }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(`Calcul invalide`) }, { quoted: msg }); }
  },

  // .trad — Traduction
  trad: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    if (args.length < 2) return sock.sendMessage(from, {
      text: errMsg(`Usage: \`${p}trad fr Hello world\`\nCodes: fr en es de ar zh ja pt ru`)
    }, { quoted: msg });
    const lang = args[0], text = args.slice(1).join(" ");
    try {
      const d    = await g("/api/tools/translate", { text, lang });
      const trad = d?.result?.translated_text || d?.result?.translation || d?.result;
      if (!trad) throw new Error("Pas de traduction.");
      await sock.sendMessage(from, {
        text: `╭──「 🌐 *TRADUCTION* 」\n│  📝 ${text}\n│  ✅ *${lang.toUpperCase()}* : ${trad}\n╰──────────────────────`
      }, { quoted: msg });
    } catch {
      try {
        const r = await axios.get(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=auto|${lang}`, { timeout: 10000 });
        const t = r.data?.responseData?.translatedText;
        await sock.sendMessage(from, { text: `╭──「 🌐 *TRADUCTION* 」\n│  📝 ${text}\n│  ✅ *${lang.toUpperCase()}* : ${t}\n╰──────────────────────` }, { quoted: msg });
      } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
    }
  },

  // .meteo — Météo
  meteo: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const city = args.join(" ").trim();
    if (!city) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}meteo Paris\``) }, { quoted: msg });
    try {
      const API = config.weatherApiKey;
      const r   = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${API}&units=metric&lang=fr`, { timeout: 10000 });
      const w   = r.data;
      await sock.sendMessage(from, {
        text: `╭──「 🌤️ *MÉTÉO — ${w.name.toUpperCase()}* 」\n│\n│  🌡️ *Temp*     : ${w.main.temp}°C (ressenti ${w.main.feels_like}°C)\n│  🌥️ *Ciel*     : ${w.weather[0].description}\n│  💧 *Humidité* : ${w.main.humidity}%\n│  💨 *Vent*     : ${w.wind.speed} m/s\n│\n╰──────────────────────`
      }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.response?.status === 404 ? `Ville "${city}" introuvable.` : e.message) }, { quoted: msg }); }
  },

  // .time — Heure d'une ville
  time: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const city = args.join(" ").trim();
    if (!city) {
      const now = new Date();
      return sock.sendMessage(from, { text: `╭──「 🕒 *HEURE* 」\n│  🌍 UTC : ${now.toUTCString()}\n│  ➤ \`${p}time Paris\` pour une ville\n╰──────────────────────` }, { quoted: msg });
    }
    try {
      const zones = (await axios.get("https://worldtimeapi.org/api/timezone", { timeout: 10000 })).data;
      const match = zones.find(z => z.toLowerCase().includes(city.toLowerCase()));
      if (!match) throw new Error(`Ville "${city}" introuvable.`);
      const d  = (await axios.get(`https://worldtimeapi.org/api/timezone/${match}`, { timeout: 10000 })).data;
      const dt = new Date(d.datetime);
      await sock.sendMessage(from, { text: `╭──「 🕒 *HEURE — ${match}* 」\n│  🕐 *Heure* : ${dt.toLocaleString("fr-FR")}\n│  🌍 *UTC*   : ${d.utc_offset}\n╰──────────────────────` }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .url — Raccourcir lien
  url: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const link = args[0];
    if (!link || !/^https?:\/\//i.test(link)) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}url https://example.com\``) }, { quoted: msg });
    try {
      const r     = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(link)}`, { timeout: 10000 });
      const short = r.data?.trim();
      await sock.sendMessage(from, { text: `╭──「 🔗 *URL RACCOURCIE* 」\n│  📎 ${link.slice(0,50)}...\n│  ✅ ${short}\n╰──────────────────────` }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .def — Définition
  def: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const word = args.join(" ").trim();
    if (!word) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}def intelligence\``) }, { quoted: msg });
    await sock.sendMessage(from, { text: `🔍 Définition de *${word}*...` }, { quoted: msg });
    try {
      const d = await g("/api/search/define", { term: word });
      const t = d?.result?.definition || d?.result?.meaning || d?.result;
      if (!t) throw new Error("Pas de définition.");
      await sock.sendMessage(from, { text: `╭──「 📖 *${word.toUpperCase()}* 」\n│\n│  ${t}\n│\n╰──────────────────────` }, { quoted: msg });
    } catch {
      try {
        const r    = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`, { timeout: 10000 });
        const line = r.data[0]?.meanings?.[0]?.definitions?.[0]?.definition || "Pas de définition.";
        await sock.sendMessage(from, { text: `╭──「 📖 *${word.toUpperCase()}* 」\n│\n│  ${line}\n│\n╰──────────────────────` }, { quoted: msg });
      } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
    }
  },

  // .news — Actualités
  news: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try {
      const r    = await axios.get(`https://newsapi.org/v2/top-headlines?country=fr&apiKey=${config.newsApiKey}`, { timeout: 10000 });
      const arts = (r.data?.articles || []).slice(0, 5);
      if (!arts.length) throw new Error("Aucune actualité.");
      let text = "╭──「 📰 *ACTUALITÉS* 」\n│\n";
      arts.forEach((a, i) => {
        text += `│  *${i+1}. ${a.title.slice(0, 60)}*\n│\n`;
      });
      text += "╰──────────────────────────────";
      await sock.sendMessage(from, { text }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
  },

  // .wiki — Wikipedia
  wiki: async (sock, msg, args) => {
    const from  = msg.key.remoteJid;
    const query = args.join(" ").trim();
    if (!query) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}wiki Paris\``) }, { quoted: msg });
    try {
      const d    = await g("/api/search/wikimedia", { title: query });
      const r    = d?.result;
      const text = r?.extract || r?.description || r?.summary;
      if (!text) throw new Error("Pas de résultat.");
      await sock.sendMessage(from, {
        text: `╭──「 📚 *WIKIPEDIA — ${query.toUpperCase()}* 」\n╰──────────────────────\n\n${text.slice(0, 600)}${text.length > 600 ? "..." : ""}\n\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬`
      }, { quoted: msg });
    } catch {
      try {
        const r = await axios.get(`https://fr.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`, { timeout: 10000 });
        const t = r.data?.extract?.slice(0, 600);
        await sock.sendMessage(from, { text: `╭──「 📚 *WIKIPEDIA* 」\n│  *${query}*\n╰──────────────────────\n\n${t}${t?.length >= 600 ? "..." : ""}` }, { quoted: msg });
      } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
    }
  },

  // .b64e — Encoder Base64
  b64e: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const text = args.join(" ").trim();
    if (!text) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}b64e Ton texte\``) }, { quoted: msg });
    try {
      const d = await g("/api/tools/ebase", { query: text });
      const r = d?.result?.base64 || d?.result;
      await sock.sendMessage(from, { text: `╭──「 🔐 *BASE64 ENCODÉ* 」\n│\n\`${r}\`\n│\n╰──────────────────────` }, { quoted: msg });
    } catch (e) {
      // Fallback local
      const enc = Buffer.from(text).toString("base64");
      await sock.sendMessage(from, { text: `╭──「 🔐 *BASE64* 」\n│  📝 ${text}\n│  ✅ \`${enc}\`\n╰──────────────────────` }, { quoted: msg });
    }
  },

  // .b64d — Décoder Base64
  b64d: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const code = args.join(" ").trim();
    if (!code) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}b64d SGVsbG8=\``) }, { quoted: msg });
    try {
      const dec = Buffer.from(code, "base64").toString("utf8");
      await sock.sendMessage(from, { text: `╭──「 🔓 *BASE64 DÉCODÉ* 」\n│  ✅ ${dec}\n╰──────────────────────` }, { quoted: msg });
    } catch (e) { await sock.sendMessage(from, { text: errMsg("Code invalide.") }, { quoted: msg }); }
  },

  // .bine — Encoder binaire
  bine: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const text = args.join(" ").trim();
    if (!text) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}bine Ton texte\``) }, { quoted: msg });
    try {
      const d = await g("/api/tools/ebinary", { query: text });
      const r = d?.result?.binary || d?.result;
      await sock.sendMessage(from, { text: `╭──「 🔢 *BINAIRE* 」\n│  📝 ${text}\n│\n\`${r}\`\n│\n╰──────────────────────` }, { quoted: msg });
    } catch {
      const bin = text.split("").map(c => c.charCodeAt(0).toString(2).padStart(8,"0")).join(" ");
      await sock.sendMessage(from, { text: `╭──「 🔢 *BINAIRE* 」\n│  📝 ${text}\n│  ✅ \`${bin}\`\n╰──────────────────────` }, { quoted: msg });
    }
  },

  // .bind — Décoder binaire
  bind: async (sock, msg, args) => {
    const from = msg.key.remoteJid;
    const code = args.join(" ").trim();
    if (!code) return sock.sendMessage(from, { text: errMsg(`Usage: \`${p}bind 01001000...\``) }, { quoted: msg });
    try {
      const dec = code.trim().split(/\s+/).map(b => String.fromCharCode(parseInt(b,2))).join("");
      await sock.sendMessage(from, { text: `╭──「 🔓 *BINAIRE DÉCODÉ* 」\n│  ✅ ${dec}\n╰──────────────────────` }, { quoted: msg });
    } catch { await sock.sendMessage(from, { text: errMsg("Code binaire invalide.") }, { quoted: msg }); }
  },

  // .fact — Fait aléatoire
  fact: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try {
      const d = await g("/api/fun/fact");
      const t = d?.result?.fact || d?.result;
      await sock.sendMessage(from, { text: `╭──「 ⚡ *FACT* 」\n│\n│  ${t}\n│\n╰──────────────────────` }, { quoted: msg });
    } catch {
      try {
        const r = await axios.get("https://uselessfacts.jsph.pl/random.json?language=en", { timeout: 8000 });
        await sock.sendMessage(from, { text: `╭──「 ⚡ *FACT* 」\n│\n│  ${r.data?.text}\n│\n╰──────────────────────` }, { quoted: msg });
      } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
    }
  },

  // .qt — Citation
  qt: async (sock, msg) => {
    const from = msg.key.remoteJid;
    try {
      const d = await g("/api/fun/quotes");
      const t = d?.result?.quote || d?.result;
      await sock.sendMessage(from, { text: `╭──「 💬 *CITATION* 」\n│\n│  _"${t}"_\n│\n╰──────────────────────` }, { quoted: msg });
    } catch {
      try {
        const r = await axios.get("https://zenquotes.io/api/random", { timeout: 8000 });
        const q = r.data?.[0]?.q, a = r.data?.[0]?.a;
        await sock.sendMessage(from, { text: `╭──「 💬 *CITATION* 」\n│\n│  _"${q}"_\n│  — *${a}*\n│\n╰──────────────────────` }, { quoted: msg });
      } catch (e) { await sock.sendMessage(from, { text: errMsg(e.message) }, { quoted: msg }); }
    }
  },
};

export default toolCommands;
