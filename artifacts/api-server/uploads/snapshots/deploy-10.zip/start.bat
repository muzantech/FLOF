@echo off
chcp 65001 >nul
title AXTERIS MD

echo.
echo  ╔══════════════════════════════════════╗
echo  ║        🤖  AXTERIS MD  v1.0.0        ║
echo  ╚══════════════════════════════════════╝
echo.

:: ── Vérifier node_modules ─────────────────────────
if not exist "node_modules" (
    echo  ❌ node_modules introuvable!
    echo  ➡️  Lance d'abord install.bat
    pause
    exit /b 1
)

:: ── Vérifier config ───────────────────────────────
if not exist "config.js" (
    echo  ❌ config.js introuvable!
    pause
    exit /b 1
)

echo  ✅ Démarrage d'Axteris MD...
echo.

:restart
node index.js

echo.
echo  ⚠️  Le bot s'est arrêté.
echo  🔄 Redémarrage dans 5 secondes... ^(Ctrl+C pour quitter^)
echo.
timeout /t 5 /nobreak >nul
goto restart
