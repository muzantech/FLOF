import os,http.server,socketserver
PORT=int(os.environ.get("SERVER_PORT",8080))
class H(http.server.SimpleHTTPRequestHandler):
  def do_GET(self):
    self.send_response(200)
    self.end_headers()
    self.wfile.write(b"FlyHost OK Python")
with socketserver.TCPServer(("",PORT),H) as h:
  print(f"Serving on {PORT}")
  h.serve_forever()