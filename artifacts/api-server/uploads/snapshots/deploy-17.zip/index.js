const http = require('http');
const port = parseInt(process.env.PORT || '3095');

const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(`<!DOCTYPE html>
<html>
<head><title>FlyHost Test App</title>
<style>body{font-family:system-ui;background:#09090b;color:#fafafa;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
.card{background:#18181b;border:1px solid #27272a;border-radius:1rem;padding:2rem;text-align:center;max-width:500px}
h1{color:#facc15}p{color:#a1a1aa}</style>
</head>
<body><div class="card">
<h1>⚡ FlyHost</h1>
<p>🎉 App déployée et accessible via le reverse proxy FlyHost !</p>
<p style="font-size:.85rem">Port: ${port} | Hôte: ${req.headers.host}</p>
<p style="margin-top:1rem;font-size:.75rem;color:#71717a">Déployée le ${new Date().toISOString()}</p>
</div></body></html>`);
});

server.listen(port, '0.0.0.0', () => {
  console.log('App running on port', port);
});